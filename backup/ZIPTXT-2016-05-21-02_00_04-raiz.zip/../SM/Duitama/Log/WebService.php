<?php

/*
  Se cambia el modo de acceso a la base de datos por un metodo singleton
 */
/* Incluimos el fichero de la clase Db */
require_once('db/Db.php');
/* Incluimos el fichero de la clase Conf */
require_once('db/Conf.php');
/* Incluimos la libreria que calcula el digito de verificación */
include '../libreria_digito_verificacion.php';

/* incluimos la librera para el envio de correos. */
require '../PHPMailerAutoload.php';

/* Creamos la instancia del objeto. Ya estamos conectados */
$db = Db::getInstance();

require_once('../lib/nusoap.php');

$server = new nusoap_server;
$server->configureWSDL('server', 'urn:server');
$server->wsdl->schemaTargetNamespace = 'urn:server';

$server->register('pollServer', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('clienteNuevo', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('terminarRutaServer', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('consignacion', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('noventa', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('recaudo', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('noRecaudos', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('pedidos', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('notasCredito', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('transferenciaAutoventa', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('transferenciaConsignacion', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('devoluciones', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('coordenadas', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('planeacionMes', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('planeacionDia', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('planeacionSmart', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');

function pollServer($value) {
    
}

/**
 * Metodo que me permite guardar la información correspondiente a las devoluciones.
 * @param type $value
 * @return string
 * @soap
 */
function devoluciones($value) {
    if ($value['value'] == 'INSERT_DEVOLUCIONES') {
        $db = Db::getInstance();

        $datos = json_decode(utf8_decode($value['datos']));
        $imei = $value['Imei'];
        $idSim = $value['IdSim'];
        $numeroCuenta = $value['NumeroCuenta'];
        $version = $value['Version'];
        $correo = 0;

        $manejador = fopen('Log/VN_DEVOLUCIONES.txt', 'a+');
        fputs($manejador, $value['datos'] . "\n");
        fputs($manejador, "Imei:" . $imei . "  IdSim: " . $idSim . "   NumeroCuenta:  " . $numeroCuenta . "    Version: " . $version . "\n");
        fclose($manejador);

        try {

            foreach ($datos->Devoluciones as $item) {

                $sql = "SELECT COUNT(*) AS Conteo FROM devoluciones WHERE CodAsesor='" . $item->CodAsesor . "' AND CodZonaVentas='" . $item->CodZonaVentas . "' AND CuentaCliente='" . $item->CuentaCliente . "' AND CodigoSitio='" . $item->CodigoSitio . "' AND CodigoMotivoDevolucion='" . $item->CodigoMotivoDevolucion . "' AND CuentaProveedor='" . $item->CuentaProveedor . "' AND IdDevolucionMaquina='" . $item->IdDevolucion . "' AND IdentificadorEnvio=0;";
                $stmt = $db->ejecutar($sql);
                $resultado = $db->obtener_fila($stmt, 0);
                $Conteo = $resultado['Conteo'];

                if ($Conteo == 0) {


                    $sql_encabezado = "INSERT INTO `devoluciones`(`CodAsesor`, `CodZonaVentas`, `CuentaCliente`, `CodigoMotivoDevolucion`, `CuentaProveedor`, `CodigoSitio`, `TotalDevolucion`, `ValorDevolucion`, `FechaDevolucion`, `HoraInicio`, `HoraFinal`, `Observacion`,`IdDevolucionMaquina`, `IdentificadorEnvio`, ArchivoXml, Autoriza, QuienAutoriza, FechaAutorizacion, HoraAutorizacion, CodigoCanal, Responsable,ExtraRuta,Ruta,Imei, Estado) VALUES ('" . $item->CodAsesor . "','" . $item->CodZonaVentas . "','" . $item->CuentaCliente . "','" . $item->CodigoMotivoDevolucion . "','" . $item->CuentaProveedor . "','" . $item->CodigoSitio . "','" . $item->TotalDevolucion . "','" . $item->ValorDevolucion . "',CURDATE(),'" . $item->HoraDigitado . "', CURTIME(), '" . $item->Observacion . "', " . $item->IdDevolucion . ", 0, '', '0', '', '0000-00-00', '00:00:00', (SELECT fcJerarquia01('" . $item->CodAsesor . "') AS canal), '" . $item->Identificacion . "','" . $item->ExtraRuta . "','" . $item->Ruta . "','" . $imei . "', 1);";
                    $db->ejecutar($sql_encabezado);

                    $id_devolucion = $db->lastID();

                    $manejador = fopen('Log/VN_INSERT_ENCABEZADO_DEVOLUCIONES.txt', 'a+');
                    fputs($manejador, $sql_encabezado);
                    fclose($manejador);


                    foreach ($item->Detalles as $itemDetalles) {


                        $sql_detalles = "INSERT INTO `descripciondevolucion`(`IdDevolucion`, `CodigoVariante`, `CodigoArticulo`, `NombreArticulo`, `CodigoUnidadMedida`, NombreUnidadMedida, `Cantidad`, `ValorUnitario`, `ValorBruto`, `Impoconsumo`, `ValorImpoconsumo`, `Iva`, `ValorIva`, `ValorTotalProducto`,Autoriza) VALUES (" . $id_devolucion . ",'" . $itemDetalles->CodVariante . "','" . $itemDetalles->CodigoArticulo . "','" . $itemDetalles->NombreArticulo . "','" . $itemDetalles->CodigoUnidadMedida . "','" . $itemDetalles->NombreUnidadMedida . "', " . $itemDetalles->Cantidad . "," . $itemDetalles->ValorUnitario . "," . $itemDetalles->ValorBruto . "," . $itemDetalles->Impoconsumo . "," . $itemDetalles->ValorImpoconsumo . "," . $itemDetalles->Iva . "," . $itemDetalles->ValorIva . "," . $itemDetalles->ValorTotalProducto . ",0)";
                        $db->ejecutar($sql_detalles);

                        $manejador = fopen('Log/VN_INSERT_DETALLE_DEVOLUCION.txt', 'a+');
                        fputs($manejador, $sql_detalles);
                        fclose($manejador);
                    }

                    envioCorreoDevolucion($id_devolucion);
                }
            }
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
            return "Error";
        }

        return "OK";
    }
}

function transferenciaConsignacion($value) {
    if ($value['value'] == 'INSERT_TRANSFERENCIA_CONSIGNACION') {
        $db = Db::getInstance();

        $datos = json_decode(utf8_decode($value['datos']));
        $imei = $value['Imei'];
        $idSim = $value['IdSim'];
        $numeroCuenta = $value['NumeroCuenta'];
        $version = $value['Version'];

        $manejador = fopen('Log/VN_TRANSFERENCIA_CONSIGNACION.txt', 'a+');
        fputs($manejador, $value['datos'] . "\n");
        fputs($manejador, "Imei:" . $imei . "  IdSim: " . $idSim . "   NumeroCuenta:  " . $numeroCuenta . "    Version:" . $version . "\n");
        fclose($manejador);

        try {

            foreach ($datos->Transferencia as $item) {

                $sql = "SELECT COUNT(*) AS Conteo FROM transferenciaconsignacion WHERE CodAsesor='" . $item->codAsesor . "' AND CodZonaVentas='" . $item->codZonaVentas . "' AND CuentaCliente='" . $item->CuentaCliente . "'  AND CodigoSitio='" . $item->CodigoSitio . "' AND CodigoAlmacen='" . $item->CodigoAlmacen . "' AND PedidoMaquina='" . $item->idTransferencia . "' AND IdentificadorEnvio=0;";
                $stmt = $db->ejecutar($sql);
                $resultado = $db->obtener_fila($stmt, 0);
                $Conteo = $resultado['Conteo'];

                if ($Conteo == 0) {
                    $sql_encabezado = "INSERT INTO `transferenciaconsignacion`(`CodAsesor`, `CodZonaVentas`, `CuentaCliente`, `CodigoSitio`, `CodigoAlmacen`, `FechaTransferencia`, `HoraDigitado`, `HoraEnviado`, `Estado`, `ArchivoXml`, `Web`, `PedidoMaquina`, `IdentificadorEnvio`, CodigoCanal, Responsable,ExtraRuta,Ruta,Imei) VALUES ('" . $item->codAsesor . "','" . $item->codZonaVentas . "','" . $item->CuentaCliente . "','" . $item->CodigoSitio . "','" . $item->CodigoAlmacen . "',CURDATE(),'" . $item->HoraDigitado . "',CURTIME(),'1','',0," . $item->idTransferencia . ", 0, (SELECT fcJerarquia01('" . $item->codAsesor . "') AS canal), '" . $item->Identificacion . "','" . $item->ExtraRuta . "','" . $item->Ruta . "','" . $imei . "');";
                    $db->ejecutar($sql_encabezado);

                    $id_trasferencia = $db->lastID();

                    $manejador = fopen('Log/' . $item->codZonaVentas . 'VN_TRANSFERENCIA_CONSIGNACION_ENCABEZADO.txt', 'a+');
                    fputs($manejador, $sql_detalles . "\n");
                    fclose($manejador);

                    foreach ($item->Detalles as $itemDetalles) {

                        $sqlImpue = "SELECT `NombreUnidad` FROM `unidadesdemedida` WHERE `CodigoUnidad`='" . $itemDetalles->CodigoUnidadMedida . "';";
                        $stmtImpue = $db->ejecutar($sqlImpue);
                        $resultadoImpu = $db->obtener_fila($stmtImpue, 0);
                        $nombreUnidadMedida = $resultadoImpu['NombreUnidad'];

                        $sql_detalles = "INSERT INTO `descripciontransferenciaconsignacion`(`IdTransferencia`,UnidadMedida, `CodVariante`, `CodigoArticulo`, `NombreArticulo`, 
                            `Cantidad`, `PedidoMaquina`, `IdentificadorEnvio`) VALUES (" . $id_trasferencia . ",'" . $nombreUnidadMedida . "', '" . $itemDetalles->CodVariante . "','" . $itemDetalles->CodigoArticulo . "','" . $itemDetalles->NombreArticulo . "'," . $itemDetalles->Cantidad . "," . $itemDetalles->IdTransferenciaDetalle . ",0)";
                        $db->ejecutar($sql_detalles);

                        $manejador = fopen('Log/' . 'VN_TRANSFERENCIA_CONSIGNACION_DETALLE.txt', 'a+');
                        fputs($manejador, $sql_detalles);
                        fclose($manejador);
                    }
                }

                //    transacciones($id_trasferencia, '8');
                enviarCorreoTransConsignacion($id_trasferencia);
            }
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
            return "Error";
        }
        return "OK";
    }
}

function transferenciaAutoventa($value) {
    if ($value['value'] == 'INSERT_TRANSFERENCIA_AUTOVENTA') {
        $db = Db::getInstance();

        $datos = json_decode(utf8_decode($value['datos']));
        $imei = $value['Imei'];
        $idSim = $value['IdSim'];
        $numeroCuenta = $value['NumeroCuenta'];
        $version = $value['Version'];

        $manejador = fopen('Log/VN_TRANSFERENCIA_AUTOVENTA.txt', 'a+');
        fputs($manejador, $value['datos'] . "\n");
        fputs($manejador, "Imei:" . $imei . "  IdSim: " . $idSim . "   NumeroCuenta:  " . $numeroCuenta . "    Version: " . $version . "\n");
        fclose($manejador);

        try {

            $id_transferencia = "";
            $codZonaVentas = "";
            $codZonaVentasTransferencia = "";
            $nombreAsesor = "";
            $contador_transferencias = "1";

            foreach ($datos->TransferenciaAutoventa as $item) {
//IdTransferencia
//CodAsesor
//CodZonaVentas
//CodZonaVentasTransferencia
//Hora
//Estado
//EstadoTerminado
//CodigoUbicacionOrigen
//CodigoUbicacionDestino
//identificacion

                $codZonaVentas = $item->CodZonaVentas;
                $sqlId = "SELECT COUNT(*) AS Conteo FROM transferenciaautoventa WHERE CodAsesor='" . $item->CodAsesor . "' AND CodZonaVentas='" . $item->CodZonaVentas . "' AND CodZonaVentasTransferencia='" . $item->CodZonaVentasTransferencia . "'  AND PedidoMaquina='" . $item->IdTransferencia . "' AND IdentificadorEnvio='0'; ";
                $stmtId = $db->ejecutar($sqlId);
                $resultadoId = $db->obtener_fila($stmtId, 0);
                $Conteo = $resultadoId['Conteo'];


                $sql_encabezado = "INSERT INTO `transferenciaautoventa`(`CodAsesor`, `CodZonaVentas`, `CodZonaVentasTransferencia`, `FechaTransferenciaAutoventa`, `HoraDigitado`, `HoraEnviado`, `Web`, `PedidoMaquina`, `IdentificadorEnvio`, ArchivoXml,CodigoCanal,Responsable,CodigoUbicacionOrigen,CodigoUbicacionDestino,Imei,Estado) VALUES ('" . $item->CodAsesor . "','" . $item->CodZonaVentas . "','" . $item->CodZonaVentasTransferencia . "',CURDATE(),'" . $item->Hora . "',CURTIME(),0," . $item->IdTransferencia . ",0, '',(SELECT fcJerarquia01('" . $item->CodAsesor . "') AS canal),'" . $item->identificacion . "','" . $item->CodigoUbicacionOrigen . "','" . $item->CodigoUbicacionDestino . "','" . $imei . "','0');";

                if ($Conteo == 0) {

                    $db->ejecutar($sql_encabezado);

                    $idTransferenciaAut == $db->lastID();

                    $manejador = fopen('Log/' . $item->CodZonaVentas . 'VN_INSERT_ENCABEZADO_TRANSFERENCIA_AUTOVENTA.txt', 'a+');
                    fputs($manejador, $sql_encabezado);
                    fclose($manejador);

                    $id_transferencia = $db->lastID();
                    $contador_transferencias = $id_transferencia;
                    $codZonaVentas = $item->CodZonaVentas;
                    $codZonaVentasTransferencia = $item->CodZonaVentasTransferencia;

                    $sql_asesores = "SELECT a.Nombre as Nombre FROM `asesorescomerciales` AS a INNER JOIN zonaventas AS z ON a.CodAsesor=z.CodAsesor WHERE z.CodZonaVentas='" . $item->CodZonaVentas . "'";
                    $stmtIdAS = $db->ejecutar($sql_asesores);
                    $resultadoIdAS = $db->obtener_fila($stmtIdAS, 0);
                    $nombreAsesor = $resultadoIdAS['Nombre'];

                    foreach ($item->Detalles as $itemDetalles) {
//IdTransferencia
//CodVariante
//CodigoArticulo
//NombreArticulo
//CodigoUnidadMedida
//NombreUnidadMedida
//Cantidad
//Lote
                        $sql_detalles = "INSERT INTO `descripciontransferenciaautoventa`(`IdTransferenciaAutoventa`, `CodVariante`, `CodigoArticulo`, `NombreArticulo`, `CodigoUnidadMedida`, `NombreUnidadMedida`, `Cantidad`, `Lote`, `PedidoMaquina`, `IdentificadorEnvio`,ValorUnitario,TotalPrecioNeto) VALUES (" . $id_transferencia . ",'" . $itemDetalles->CodVariante . "','" . $itemDetalles->CodigoArticulo . "','" . $itemDetalles->NombreArticulo . "','" . $itemDetalles->CodigoUnidadMedida . "','" . $itemDetalles->NombreUnidadMedida . "'," . $itemDetalles->Cantidad . ",'" . $itemDetalles->Lote . "', " . $itemDetalles->IdTransferencia . ",0,'" . $itemDetalles->valorUnitario . "','" . $itemDetalles->valorTotal . "')";




                        $db->ejecutar($sql_detalles);


                        //Sumamos el valor de las transferencias para actualizar el encabezado

                        $sqlSuma = "SELECT SUM(TotalPrecioNeto) AS Suma FROM descripciontransferenciaautoventa WHERE IdTransferenciaAutoventa='$id_transferencia'; ";
                        $sqlSuma = $db->ejecutar($sqlSuma);
                        $sqlSuma = $db->obtener_fila($sqlSuma, 0);
                        $sqlSuma = $sqlSuma['Suma'];

                        $sqlActualizar = "UPDATE transferenciaautoventa SET TotalTransferencia = '$sqlSuma' WHERE IdTransferenciaAutoventa = '$id_transferencia'";

                        $db->ejecutar($sqlActualizar);




                        // $sql_Transacciones = "INSERT INTO `transaccionesax`(`CodTipoDocumentoActivity`, `IdDocumento`, `CodigoAgencia`, `EstadoTransaccion`) VALUES ('3','$id_transferencia','002','0');";
                        //$db->ejecutar($sql_Transacciones);

                        $manejador = fopen('Log/' . $item->CodZonaVentas . 'VN_INSERT_DETALLE_TRANSFERAUTOVENTA.txt', 'a+');
                        fputs($manejador, $sql_detalles);
                        fclose($manejador);
                    }

                    $sqlMensaje = "INSERT INTO `mensajes`(`IdDestinatario`, `IdRemitente`, `FechaMensaje`, `HoraMensaje`, `Mensaje`, `Estado`) VALUES ('" . $codZonaVentasTransferencia . "','" . $codZonaVentas . "',CURDATE(),CURTIME(),'Se realizo a su de zona ventas " . $codZonaVentasTransferencia . " una transferencia de autoventa enviada por la zona de ventas " . $codZonaVentas . " asesor " . $nombreAsesor . "','');";
                    $db->ejecutar($sqlMensaje);
                } else {
                    $manejador = fopen('Log/' . $item->vendedor . 'Warning.txt', 'a+');
                    fputs($manejador, "No se pudo insertar datos duplicados: " . $sql_encabezado . "\n");
                    fclose($manejador);

                    return "NO-0";
                }

                if ($codZonaVentas == "11178") {
                    
                } else {
                    transacciones($idTransferenciaAut, '3');
                }
            }
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
            return "Error";
        }

        //  transacciones($idTransferenciaAut, '3');

        return "OK-" . $contador_transferencias;
    }
}

/**
 * Opción que me permite guarda los registros de notascreditos.
 * @param type $value
 * @return string
 * @soap
 */
function notasCredito($value) {
    if ($value['value'] == 'INSERT_NOTAS') {
        $db = Db::getInstance();

        $datos = json_decode(utf8_decode($value['datos']));
        $imei = $value['Imei'];
        $idSim = $value['IdSim'];
        $numeroCuenta = $value['NumeroCuenta'];
        $version = $value['Version'];

        $manejador = fopen('Log/VN_NOTAS_CREDITO.txt', 'a+');
        fputs($manejador, $value['datos'] . "\n");
        fputs($manejador, "Imei:" . $imei . "  IdSim: " . $idSim . "   NumeroCuenta:  " . $numeroCuenta . "    Version: " . $version . "\n");
        fclose($manejador);

        try {

            foreach ($datos->Notas as $item) {
//vendedor
//cliente
//concepto
//fabricante
//Responsable
//factura
//valor
//observacion
//estado
//idnota
//CodAsesor
//Ruta
//ExtraRuta
//identificacion

                $sqlId = "SELECT COUNT(*) AS Conteo FROM `notascredito` WHERE CodAsesor = '" . $item->CodAsesor . "' AND CodZonaVentas = '" . $item->vendedor . "' AND CuentaCliente = '" . $item->cliente . "' AND ResponsableNota = '" . $item->Responsable . "' AND Concepto = '" . $item->concepto . "' AND Fabricante = '" . $item->fabricante . "' AND Factura = '" . $item->factura . "' AND Valor = '" . $item->valor . "' AND Observacion = '" . $item->observacion . "'; ";
                $stmtId = $db->ejecutar($sqlId);
                $resultadoId = $db->obtener_fila($stmtId, 0);
                $Conteo = $resultadoId['Conteo'];


                $sqlDim = "SELECT `CodigoDimension` FROM `conceptosnotacredito` WHERE `CodigoConceptoNotaCredito` ='" . $item->concepto . "'; ";
                $stmtDim = $db->ejecutar($sqlDim);
                $resultadoDIm = $db->obtener_fila($stmtDim, 0);
                $codigoDimensio = $resultadoDIm['CodigoDimension'];


                $sql_detalles = "INSERT INTO `notascredito`(`CodAsesor`, `CodZonaVentas`, `CuentaCliente`, `ResponsableNota`, `Concepto`, `Fabricante`, `Factura`, `Valor`, `Observacion`, `Fecha`, `Hora`, `Autoriza`, `QuienAutoriza`, `EstadoCorreo`, `FechaAutorizacion`, `HoraAutorizacion`, `ArchivoXml`, `ObservacionCartera`, `Estado`, `Comentario`, `IdDinamica`, `ValorDinamica`, `Web`,CodigoCanal,Responsable,ExtraRuta,Ruta,Imei,CodigoDimension) VALUES ('" . $item->CodAsesor . "','" . $item->vendedor . "','" . $item->cliente . "','" . $item->Responsable . "','" . $item->concepto . "','" . $item->fabricante . "','" . $item->factura . "','" . $item->valor . "','" . $item->observacion . "',CURDATE(),CURTIME(),'0','','','','','','','1','','','','0',(SELECT fcJerarquia01('" . $item->CodAsesor . "') AS canal),'" . $item->identificacion . "','" . $item->ExtraRuta . "','" . $item->Ruta . "','" . $imei . "','" . $codigoDimensio . "');";

                if ($Conteo == 0) {

                    $sqValor = "SELECT SUM(Valor) AS valor FROM `notascredito` WHERE `CodAsesor`='" . $item->CodAsesor . "' AND `CodZonaVentas`='" . $item->vendedor . "' AND `CuentaCliente`='" . $item->cliente . "' AND `Factura`='" . $item->factura . "' AND `Autoriza`='0' AND `ArchivoXml`='';";
                    $stValor = $db->ejecutar($sqValor);
                    $res = $db->obtener_fila($stValor, 0);
                    $valorNotas = $res['valor'];


                    $sqSaldo = "SELECT SUM(ValorNetoArticulo) AS saldo FROM `facturasaldodetalle` WHERE NumeroFactura='" . $item->factura . "';";
                    $stSaldo = $db->ejecutar($sqSaldo);
                    $resS = $db->obtener_fila($stSaldo, 0);
                    $saldo = ceil($resS['saldo']);


                    $disponible = $saldo - $valorNotas;

                    if ($item->valor > $disponible) {
                        return "NoSaldo";
                    } else {

                        $db->ejecutar($sql_detalles);

                        $idNotas = $db->lastID();

                        //  transacciones($idNotas, '7');

                        $manejador = fopen('Log/' . $item->vendedor . 'VN_INSERT_NOTAS_CREDITO.txt', 'a+');
                        fputs($manejador, $sql_detalles . "\n");
                        fclose($manejador);
                    }
                } else {
                    $manejador = fopen('Log/' . $item->vendedor . 'Warning.txt', 'a+');
                    fputs($manejador, "No se pudo insertar datos duplicados: " . $sql_detalles . "\n");
                    fclose($manejador);
                    return "Error";
                }
                envioCorreoNotasCredito($idNotas);
            }

            foreach ($datos->Fotos as $item) {
//nombre
//cliente
//factura
//fecha
//hora
//estado
//usuario          

                $sqId = "SELECT MAX(IdNotaCredito) AS Max FROM `notascredito` WHERE `CodZonaVentas`='" . $item->usuario . "' AND `CuentaCliente`='" . $item->cliente . "' AND `Factura`='" . $item->factura . "' AND `Autoriza`='0' AND `ArchivoXml`='';";
                $stId = $db->ejecutar($sqId);
                $resS = $db->obtener_fila($stId, 0);
                $Max = $resS['Max'];

                $sql_detalles = "INSERT INTO `notascreditofoto`(IdNotaCredito,`Nombre`, `CodZonaVentas`, `CuentaCliente`, `Factura`, `Fecha`, `Hora`) VALUES ('" . $Max . "','" . $item->nombre . ".png','" . $item->usuario . "','" . $item->cliente . "','" . $item->factura . "','" . $item->fecha . "','" . $item->hora . "');";
                $db->ejecutar($sql_detalles);

                $manejador = fopen('Log/' . $item->usuario . 'VN_INSERT_NOTAFOTO.txt', 'a+');
                fputs($manejador, $sql_detalles);
                fclose($manejador);
            }
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
            return "Error";
        }

        return "OK";
    }
}

function pedidos($value) {
    if ($value['value'] == 'INSERT_PEDIDOS') {
        $db = Db::getInstance();

        $datos = json_decode(utf8_decode($value['datos']));
        $imei = $value['Imei'];
        $idSim = $value['IdSim'];
        $numeroCuenta = $value['NumeroCuenta'];
        $version = $value['Version'];
        $arrayPedidosVentaDirecta = array();

        $numeroFactura = 0;
        $correo = 0;
        $zonaVentas = "";

        $manejador = fopen('Log/VN_PEDIDOS.txt', 'a+');
        fputs($manejador, $value['datos'] . "\n");
        fputs($manejador, "Imei:" . $imei . "  IdSim: " . $idSim . "   NumeroCuenta:  " . $numeroCuenta . "    Version: " . $version . "\n");
        fclose($manejador);

        try {

            foreach ($datos->Pedidos as $itemEncabezado) {

// IdPedido
//Conjunto
//CodAsesor
//CodZonaVentas
//CuentaCliente
//CodGrupoVenta
//CodGrupoPrecios
//Ruta
//CodigoSitio
//CodigoAlmacen
//HoraDigitado
//FechaEntrega
//FormaPago
//Plazo
//TipoVenta
//ActividadEspecial
//Observacion
//NroFactura
//ValorPedido
//TotalPedido
//TotalValorIva
//TotalSubtotalBaseIva
//TotalValorImpoconsumo
//TotalValorDescuento
//Estado
//EstadoTerminado
//Extraruta
//Resolucion
//Prefijo
//identificacion
//

                $sql = "SELECT COUNT(*) AS Conteo FROM `pedidos` WHERE CodZonaVentas = '" . $itemEncabezado->CodZonaVentas . "' AND CuentaCliente = '" . $itemEncabezado->cliente . "' AND `PedidoMaquina`='" . $itemEncabezado->IdPedido . "'  AND IdentificadorEnvio='0' ;";
                $stmt = $db->ejecutar($sql);
                $resultado = $db->obtener_fila($stmt, 0);
                $Conteo = $resultado['Conteo'];

                $actividad = $itemEncabezado->ActividadEspecial;
                $IdentificadorPedido = $itemEncabezado->IdPedido;
                $estado = 0;
                if ($actividad == 1) {
                    $estado = 1;
                    $correo = 1;
                }

                $conjunto = "";
                if ($itemEncabezado->TipoVenta == "Preventa") {
                    $conjunto = "001";
                } else if ($itemEncabezado->TipoVenta == "Consignacion") {
                    $conjunto = "004";
                } else if ($itemEncabezado->TipoVenta == "Venta Directa") {
                    $conjunto = "003";
                } else if ($itemEncabezado->TipoVenta == "Autoventa") {
                    $conjunto = "002";
                }

                $sqlImpue = "SELECT `CodigoGrupodeImpuestos`,`CodigoZonaLogistica` FROM `clienteruta` WHERE `CuentaCliente` ='" . $itemEncabezado->CuentaCliente . "' AND `CodZonaVentas`='" . $itemEncabezado->CodZonaVentas . "';";
                $stmtImpue = $db->ejecutar($sqlImpue);
                $resultadoImpu = $db->obtener_fila($stmtImpue, 0);
                $codigoGrupoImpuesto = $resultadoImpu['CodigoGrupodeImpuestos'];
                $codigoZonaLogistica = $resultadoImpu['CodigoZonaLogistica'];

                $nroFactura2 = "";
                if ($itemEncabezado->NroFactura == 0) {
                    $nroFactura2 = "";
                } else {
                    $nroFactura2 = $itemEncabezado->NroFactura;
                }

                $identifica = "";
                if ($itemEncabezado->identificacion == 0) {
                    $identifica = "";
                } else {
                    $identifica = $itemEncabezado->identificacion;
                }

                $sql_detalles = "INSERT INTO `pedidos`( `Conjunto`, `CodAsesor`, `CodZonaVentas`, `CuentaCliente`, `CodGrupoVenta`, `CodGrupoPrecios`, `CodigoSitio`, `CodigoAlmacen`, `FechaPedido`, `HoraDigitado`, `HoraEnviado`, `FechaEntrega`, `FormaPago`, `Plazo`, `TipoVenta`, `ActividadEspecial`, `Observacion`, `NroFactura`, `ValorPedido`, `TotalPedido`, `TotalValorIva`, `TotalSubtotalBaseIva`, `TotalValorImpoconsumo`, `TotalValorDescuento`, `Estado`, `ArchivoXml`, `EstadoPedido`, `AutorizaDescuentoEspecial`, `Web`, `PedidoMaquina`, `IdentificadorEnvio`, `CodigoCanal`, `Responsable`, `ExtraRuta`, `Ruta`,Imei,CodigoGrupodeImpuestos,CodigoZonaLogistica,Resolucion,Prefijo) VALUES ('" . $conjunto . "','" . $itemEncabezado->CodAsesor . "','" . $itemEncabezado->CodZonaVentas . "','" . $itemEncabezado->CuentaCliente . "','" . $itemEncabezado->CodGrupoVenta . "','" . $itemEncabezado->CodGrupoPrecios . "','" . $itemEncabezado->CodigoSitio . "','" . $itemEncabezado->CodigoAlmacen . "',CURDATE(),'" . $itemEncabezado->HoraDigitado . "',CURTIME(),'" . $itemEncabezado->FechaEntrega . "','" . $itemEncabezado->FormaPago . "','" . $itemEncabezado->Plazo . "','" . $itemEncabezado->TipoVenta . "','" . $actividad . "','" . $itemEncabezado->Observacion . "','" . $nroFactura2 . "','" . $itemEncabezado->ValorPedido . "','" . $itemEncabezado->TotalPedido . "','" . $itemEncabezado->TotalValorIva . "','" . $itemEncabezado->TotalSubtotalBaseIva . "','" . $itemEncabezado->TotalValorImpoconsumo . "','" . $itemEncabezado->TotalValorDescuento . "','" . $estado . "','','0','0','0','" . $itemEncabezado->IdPedido . "','0',(SELECT fcJerarquia01('" . $itemEncabezado->CodAsesor . "') AS canal),'" . $identifica . "','" . $itemEncabezado->Extraruta . "','" . $itemEncabezado->Ruta . "','" . $imei . "','" . $codigoGrupoImpuesto . "','" . $codigoZonaLogistica . "','" . $itemEncabezado->Resolucion . "','" . $itemEncabezado->Prefijo . "');";

                if ($Conteo == 0) {

                    $db->ejecutar($sql_detalles);

                    $idPedidoFinal = $db->lastID();

                    if ($conjunto == "003") {
                        array_push($arrayPedidosVentaDirecta, $idPedidoFinal);
                    }


                    //$IdPedido = $idPedidoFinal;
                    $numeroFactura = $itemEncabezado->NroFactura;
                    $zonaVentas = $itemEncabezado->CodZonaVentas;
                    

                    $manejador = fopen('Log/' . $itemEncabezado->CodZonaVentas . 'VN_PEDIDO_ENCABEZADO.txt', 'a+');
                    fputs($manejador, $sql_detalles . "\n");
                    fclose($manejador);
                } else {
                    $manejador = fopen('Log/' . $itemEncabezado->CodZonaVentas . 'Warning.txt', 'a+');
                    fputs($manejador, "No se pudo insertar datos duplicados: " . $sql_detalles . "\n");
                    fclose($manejador);
                    return "Error";
                }


                foreach ($datos->Detalles as $item) {
//IdPedido  
//CodVariante
//CodigoArticulo
//NombreArticulo
//Cantidad
//ValorUnitario
//Iva
//Impoconsumo
//ValorUnitariImpoconsumo
//CodigoUnidadMedida
//Saldo
//SaldoLimite
//DsctoLinea
//DsctoMultiLinea
//DsctoEspecial
//DsctoEspecialAltipal
//DsctoEspecialProveedor
//ValorBruto
//ValorDsctoLinea
//ValorDsctoMultiLinea
//ValorDsctoEspecial
//ValorDescuentos
//BaseIva
//ValorIva
//TotalValorImpoconsumo
//PrecioNeto
//TotalPedido
//TotalDsctoLinea
//TotalDsctoMultiLinea
//TotalDsctoEspecial
//TotalBaseIva
//TotalValorIva
//Estado
//EstadoModificar
//Motivo
//Posicion
//IdAcuerdoPrecioVenta
//CodigoTipo
//CuentaProveedor
//CodLote
//IdAcuerdoPrecio2
//IdAcuerdoLinea2
//IdAcuerdoMultilinea2
//Factor
//CodAsesor
//CodZonaVentas
//CuentaCliente
//Kits   -> IdPedido,CodVariante,CodigoListaMateriales,CodigoArticuloComponente,Nombre,CodigoUnidadMedida,CodigoTipo,FijoDigitado,OpcionalDigitado,Cantidad,Estado,IdLista.
//Consultamos el id pedido
                    if ($IdentificadorPedido == $item->IdPedido) {

                        $IdPedido = "0";
                        $sqlId = "SELECT IdPedido FROM `pedidos` WHERE CodZonaVentas = '" . $item->CodZonaVentas . "' AND CuentaCliente = '" . $item->CuentaCliente . "' AND `PedidoMaquina`='" . $item->IdPedido . "'  AND Web='0' AND IdentificadorEnvio='0' ORDER BY IdPedido DESC; ";
                        $stmtId = $db->ejecutar($sqlId);
                        $resultadoId = $db->obtener_fila($stmtId, 0);
                        $IdPedido = $resultadoId['IdPedido'];


                        if ($IdPedido > 0) {
//            $sqlCon = "SELECT COUNT(*) AS Conteo FROM `descripcionpedido` WHERE IdPedido = '".$IdPedido."' AND CodVariante='".$item->CodVariante."'; ";
//            $stmtCon = $db->ejecutar($sqlCon);
//            $resultadoCon = $db->obtener_fila($stmtCon, 0);
//            $Conteo2 = $resultadoCon['Conteo'];
                            $Conteo2 = 0;

                            $sqlImpue = "SELECT `NombreUnidad` FROM `unidadesdemedida` WHERE `CodigoUnidad`='" . $item->CodigoUnidadMedida . "';";
                            $stmtImpue = $db->ejecutar($sqlImpue);
                            $resultadoImpu = $db->obtener_fila($stmtImpue, 0);
                            $nombreUnidadMedida = $resultadoImpu['NombreUnidad'];

                            $IdAcuerdoMultilinea2 = 0;
                            if (empty($item->IdAcuerdoMultilinea2)) {
                                $IdAcuerdoMultilinea2 = 0;
                            } else {
                                $IdAcuerdoMultilinea2 = $item->IdAcuerdoMultilinea2;
                            }

                            $IdAcuerdoLinea2 = 0;
                            if (empty($item->IdAcuerdoLinea2)) {
                                $IdAcuerdoLinea2 = 0;
                            } else {
                                $IdAcuerdoLinea2 = $item->IdAcuerdoLinea2;
                            }

                            if ($item->DsctoEspecial > 0) {


                                $sqlImpue = "SELECT ActividadEspecial FROM `pedidos` WHERE IdPedido = '$IdPedido';";
                                $stmtImpue = $db->ejecutar($sqlImpue);
                                $resultadoImpu = $db->obtener_fila($stmtImpue, 0);
                                $ActividadEspecial = $resultadoImpu['ActividadEspecial'];

                                if ($ActividadEspecial == 1) {
                                    $sqlUpdateEstado = "UPDATE `pedidos` SET  Estado ='2' WHERE IdPedido='" . $IdPedido . "';";
                                } else {
                                    $sqlUpdateEstado = "UPDATE `pedidos` SET  Estado ='1' WHERE IdPedido='" . $IdPedido . "';";
                                }


                                $db->ejecutar($sqlUpdateEstado);
                                $estado = 1;
                                $correo = 2;
                            }

                            $sql_detalles2 = "INSERT INTO `descripcionpedido`(`IdPedido`, `CodVariante`, `CodigoArticulo`, `NombreArticulo`, `CodigoTipo`, 
                        `Cantidad`, `ValorUnitario`, `Iva`, `Impoconsumo`, `CodigoUnidadMedida`,NombreUnidadMedida, `CuentaProveedor`, `Saldo`, `DsctoLinea`, 
                        `DsctoMultiLinea`, `DsctoEspecial`, `DsctoEspecialAltipal`, `DsctoEspecialProveedor`, `ValorBruto`, `ValorDsctoLinea`, `ValorDsctoMultiLinea`, 
                        `ValorDsctoEspecial`, `BaseIva`, `ValorIva`, `ValorImpoconsumo`, `TotalPrecioNeto`, `PedidoMaquina`, `IdentificadorEnvio`, `EstadoTerminacion`, `CodLote`,IdAcuerdoPrecioVenta,IdAcuerdoLinea,IdAcuerdoMultilinea,Factor) VALUES ('" . $IdPedido . "','" . $item->CodVariante . "','" . $item->CodigoArticulo . "','" . $item->NombreArticulo . "','" . $item->CodigoTipo . "','" . $item->Cantidad . "','" . $item->ValorUnitario . "','" . $item->Iva . "','" . $item->Impoconsumo . "','" . $item->CodigoUnidadMedida . "','" . $nombreUnidadMedida . "','" . $item->CuentaProveedor . "','" . $item->Saldo . "','" . $item->DsctoLinea . "','" . $item->DsctoMultiLinea . "','" . $item->DsctoEspecial . "','" . $item->DsctoEspecialAltipal . "','" . $item->DsctoEspecialProveedor . "','" . $item->ValorBruto . "','" . $item->TotalDsctoLinea . "','" . $item->TotalDsctoMultiLinea . "','" . $item->TotalDsctoEspecial . "','" . $item->TotalBaseIva . "','" . $item->TotalValorIva . "','" . $item->TotalValorImpoconsumo . "','" . $item->TotalPedido . "','" . $item->IdPedido . "','0','0','" . $item->CodLote . "','" . $item->IdAcuerdoPrecio2 . "','" . $IdAcuerdoLinea2 . "','" . $IdAcuerdoMultilinea2 . "','" . $item->Factor . "');";

                            if ($Conteo2 == 0) {
                                $db->ejecutar($sql_detalles2);

                                $idDetalle = $db->lastID();

                                if (($item->CodigoTipo == "KD") || ($item->CodigoTipo == "KV")) {
                                    $kits = $item->Kits;

                                    foreach ($kits as $itemkit) {
                                        $sqlCompo = "SELECT TotalPrecioVentaBaseVariante, CantidadComponente, NombreUnidadMedida FROM `listadematerialesdetalle` WHERE CodigoListaMateriales ='" . $itemkit->CodigoListaMateriales . "' AND CodigoVarianteComponente='" . $itemkit->CodigoArticuloComponente . "' AND Id = '" . $itemkit->IdLista . "';";
                                        $stmtCOmpo = $db->ejecutar($sqlCompo);
                                        $resultadCompo = $db->obtener_fila($stmtCOmpo, 0);
                                        $PrecioVentaBaseVariante = $resultadCompo['TotalPrecioVentaBaseVariante'];
                                        $cantidadComponenteKit = $resultadCompo['CantidadComponente'];
                                        $PrecioVentaBaseVarianteDividido = $PrecioVentaBaseVariante / $cantidadComponenteKit;
                                        $nombreUnidadMedidaKit = $resultadCompo['NombreUnidadMedida'];


                                        $sqlKit = "INSERT INTO `kitdescripcionpedido`(`IdDescripcionPedido`, `CodigoListaMateriales`, `CodigoArticuloComponente`, `Nombre`, `CodigoUnidadMedida`, `CodigoTipo`, `Fijo`, `Opcional`, `Cantidad`,PrecioVentaBaseVariante) VALUES ('" . $idDetalle . "','" . $itemkit->CodigoListaMateriales . "','" . $itemkit->CodigoArticuloComponente . "','" . $itemkit->Nombre . "','" . $nombreUnidadMedidaKit . "','" . $itemkit->CodigoTipo . "','" . $itemkit->FijoDigitado . "','" . $itemkit->OpcionalDigitado . "','" . $itemkit->Cantidad . "','" . $PrecioVentaBaseVarianteDividido . "');";
                                        $db->ejecutar($sqlKit);

                                        $manejador = fopen('Log/' . $item->CodZonaVentas . 'VN_INSERT_KIT.txt', 'a+');
                                        fputs($manejador, $sqlKit . "\n");
                                        fclose($manejador);
                                    }
                                }

                                $manejador = fopen('Log/' . $item->CodZonaVentas . 'VN_DESCRIPCION_PEDIDO.txt', 'a+');
                                fputs($manejador, $sql_detalles2 . "\n");
                                fclose($manejador);
                            } else {
                                $manejador = fopen('Log/' . $item->CodZonaVentas . 'Warning.txt', 'a+');
                                fputs($manejador, "No se pudo insertar datos duplicados: " . $sql_detalles2 . "\n");
                                fclose($manejador);
                                return "Error";
                            }


                            if ($numeroFactura != 0) {

                                $manejador = fopen('Log/NumeroFactura.txt', 'a+');
                                fputs($manejador, "Factura: " . $numeroFactura . "  Zonaventas: " . $zonaVentas . "\n");
                                fclose($manejador);

                                $client = new nusoap_client("http://altipal.datosmovil.info/SM/WebServiceLogin.php?wsdl");
                                $client->soap_defencoding = 'UTF-8';
                                $err = $client->getError();
                                if ($err) {
                                    echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
                                    echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->getDebug(), ENT_QUOTES) . '</pre>';
                                    exit();
                                }

                                $args = array('value' => 'Actualizar', 'zonaVentas' => $zonaVentas, 'numeroFactura' => $numeroFactura);
                                $client->call('resolucion', array($args));

                                if ($zonaVentas == "11178") {
                                    
                                } else {
                                    transacciones($IdPedido, '2');
                                }
                            }
                        } else {
                            $manejador = fopen('Log/' . $item->CodZonaVentas . 'Warning.txt', 'a+');
                            fputs($manejador, "Detalles no insertados falta de id: " . $sqlId . "\n");
                            fclose($manejador);
                            return "Error";
                        }
                    }
                }
           if ($estado == 1) {
            $sqlUpdateEstado = "UPDATE `pedidos` SET  Estado ='1' WHERE IdPedido='" . $IdPedido . "';";
        } else {
            if ($zonaVentas == "11178") {
                
            } else {
                transacciones($IdPedido, '1');
            }
        }
                
            }
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
            return "Error";
        }

        if ($correo == 1) {
            envioCorreoActividadEspecial($IdPedido);
        }
        if ($correo == 2) {
            envioCorreoDescuentoEspecial($IdPedido);
        }

        if (count($arrayPedidosVentaDirecta) > 0) {
            foreach ($arrayPedidosVentaDirecta as $key) {
                # code...

                $sql = "SELECT CuentaProveedor as cp,(SELECT NombreCuentaProveedor FROM `proveedores` WHERE CodigoCuentaProveedor = cp) AS nombrePro,(SELECT CodAgencia FROM `agencia`) as CodAgencia FROM `descripcionpedido` WHERE IdPedido = '$key' LIMIT 1";
                $stmt = $db->ejecutar($sql);
                $resultado = $db->obtener_fila($stmt, 0);
                $Conteo = $resultado['cp'];
                $nombrePro = $resultado['nombrePro'];
                $CodAgencia = $resultado['CodAgencia'];


                $client = new nusoap_client("http://altipal.datosmovil.info/SM/WebServiceLogin.php?wsdl");
                $client->soap_defencoding = 'UTF-8';
                $err = $client->getError(); /*                 * *Captura de errores** */
                if ($err) {
                    echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
                    echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->getDebug(), ENT_QUOTES) . '</pre>';
                    exit();
                }

                $args = array('value' => 'correoventadirecta', 'CuentaProveedor' => $Conteo, 'Agencia' => $CodAgencia, 'Proveedor' => $nombrePro);
                $return = $client->call('correoventadirecta', array($args));
            }
        }

        return "OK";
    }
}

function noRecaudos($value) {
    if ($value['value'] == 'INSERT_NORECAUDO') {
        $db = Db::getInstance();

        $datos = json_decode(utf8_decode($value['datos']));
        $imei = $value['Imei'];
        $idSim = $value['IdSim'];
        $numeroCuenta = $value['NumeroCuenta'];
        $version = $value['Version'];

        $manejador = fopen('Log/VN_NO_RECAUDO.txt', 'a+');
        fputs($manejador, $value['datos'] . "\n");
        fputs($manejador, "Imei:" . $imei . "  IdSim: " . $idSim . "   NumeroCuenta:  " . $numeroCuenta . "     Version:" . $version . "\n");
        fclose($manejador);

        try {

            $cont = 0;

            foreach ($datos->Encabezado as $item) {
//id_norecibo
//cliente
//fechainicio
//fechafinal
//concepto
//observacion
//Ruta
//ExtraRuta
//identificacion
//codasesor
//codZonaVentas            

                $sql = "SELECT COUNT(*) AS Conteo FROM `norecaudos` WHERE CodZonaVentas = '" . $item->codZonaVentas . "' AND CodAsesor = '" . $item->codasesor . "' AND `CuentaCliente`='" . $item->cliente . "' AND `Fecha` = CURDATE() AND `FechaProximaVisita` = '" . $item->fechafinal . "'  AND `CodMotivoGestion` = '" . $item->concepto . "' `Observacion` = '" . $item->observacion . "' ;";
                $stmt = $db->ejecutar($sql);
                $resultado = $db->obtener_fila($stmt, 0);
                $Conteo = $resultado['Conteo'];

                $sql_detalles = "INSERT INTO `norecaudos`(`CodZonaVentas`, `CodAsesor`, `CuentaCliente`, `Fecha`, `FechaProximaVisita`, `Hora`, `CodMotivoGestion`, `Observacion`, `Estado`,Web,CodigoCanal,Responsable,ExtraRuta,Ruta,Imei) VALUES ('" . $item->codZonaVentas . "','" . $item->codasesor . "','" . $item->cliente . "',CURDATE(),'" . $item->fechafinal . "',CURTIME(),'" . $item->concepto . "','" . $item->observacion . "','0','0',(SELECT fcJerarquia01('" . $item->codasesor . "') AS canal),'" . $item->identificacion . "','" . $item->ExtraRuta . "','" . $item->Ruta . "','" . $imei . "')";

                if ($Conteo == 0) {

                    $db->ejecutar($sql_detalles);
                    $idRecaudo = $db->lastID();
                    $manejador = fopen('Log/' . $item->codZonaVentas . 'VN_INSERT_NO_RECAUDO.txt', 'a+');
                    fputs($manejador, $sql_detalles . "\n");
                    fclose($manejador);
                } else {
                    $manejador = fopen('Log/' . $item->codZonaVentas . 'Warning.txt', 'a+');
                    fputs($manejador, "No se pudo insertar datos duplicados: " . $sql_detalles . "\n");
                    fclose($manejador);
                    return "Error";
                }
            }


            foreach ($datos->Detalles as $item) {
//idNorecibo
//factura
//estado
//cliente
//codasesor
//codZonaVentas

                $sqlId = "SELECT `Id` FROM `norecaudos` WHERE `CodZonaVentas`='" . $item->codZonaVentas . "' AND `CodAsesor`='" . $item->codasesor . "' AND `CuentaCliente`='" . $item->cliente . "' AND Estado='0' AND Web='0' AND Fecha=CURDATE() ORDER BY Id DESC LIMIT 1; ";
                $stmtId = $db->ejecutar($sqlId);
                $resultadoId = $db->obtener_fila($stmtId, 0);
                $Id = $resultadoId['Id'];

                $sql_insert = "INSERT INTO `norecaudosdetalle`(`IdNoCaudo`, `Factura`) VALUES ('" . $Id . "','" . $item->factura . "');";
                if ($Id > 0) {

                    $db->ejecutar($sql_insert);

                    $manejador = fopen('Log/' . $item->codZonaVentas . 'VN_INSERT_NO_RECAUDO_DETALLE.txt', 'a+');
                    fputs($manejador, $sql_insert . "\n");
                    fclose($manejador);

                    if ($item->codZonaVentas == "11178") {
                        
                    } else {
                        transacciones($Id, '4');
                    }
                } else {
                    $manejador = fopen('Log/' . $item->codZonaVentas . 'Warning.txt', 'a+');
                    fputs($manejador, "No se encontro id relacion: " . $sql_insert . "\n");
                    fclose($manejador);
                    return "Error";
                }
            }
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
            return "Error";
        }

        return "OK";
    }
}

/**
 * Permite guardar los datos correspondientes a los recaudos.
 * @param type $value
 * @return string
 * @soap
 */
function recaudo($value) {

    if ($value['value'] == 'INSERT_RECAUDOS2') {
        $db = Db::getInstance();

        $datos = jsonDecode(utf8_decode($value['datos']));
        $imei = $value['Imei'];
        $idSim = $value['IdSim'];
        $numeroCuenta = $value['NumeroCuenta'];
        $version = $value['Version'];

        $zonaVenta12 = "";

        $manejador = fopen('Log/VN_RECAUDOS.txt', 'a+');
        fputs($manejador, $value['datos'] . "\n");
        fputs($manejador, "Imei:" . $imei . "  IdSim: " . $idSim . "   NumeroCuenta:  " . $numeroCuenta . "    Version:" . $version . "\n");
        fclose($manejador);

        try {

            foreach ($datos->Recaudos as $item) {
// idRecibo
//provisonal
//codAsesor
//zonaVentas
//cliente
//valorAbono
//estado
//identificacion
//ruta
//extraRuta

                $zonaVenta12 = $item->zonaVentas;
                $sql = "SELECT COUNT(*) AS Conteo FROM `reciboscaja` WHERE ZonaVenta = '" . $item->zonaVentas . "' AND CuentaCliente = '" . $item->cliente . "' AND Provisional = '" . $item->provisonal . "' AND `ReciboMaquina`='" . $item->idRecibo . "' ;";
                $stmt = $db->ejecutar($sql);
                $resultado = $db->obtener_fila($stmt, 0);
                $Conteo = $resultado['Conteo'];


                $sql_detalles = "INSERT INTO `reciboscaja`(`CodAsesor`, `ZonaVenta`, `CuentaCliente`, `Fecha`, `Hora`, `Provisional`, `Estado`, `ArchivoXml`, `IdentificadorEnvio`, `ReciboMaquina`, `Web`, `CodigoCanal`, `Responsable`, `ExtraRuta`, `Ruta`,Imei) VALUES ('" . $item->codAsesor . "','" . $item->zonaVentas . "','" . $item->cliente . "',CURDATE(),CURTIME(),'" . $item->provisonal . "','0','','0','" . $item->idRecibo . "','0',(SELECT fcJerarquia01('" . $item->codAsesor . "') AS canal),'" . $item->identificacion . "','" . $item->extraRuta . "','" . $item->ruta . "','" . $imei . "');";

                if ($Conteo == 0) {

                    $db->ejecutar($sql_detalles);
                    $idRecaudo = $db->lastID();

                    foreach ($item->Detalles as $itemDetalle) {
//idRecibo
//provisional
//factura
//valor
//motivo
//estadoTerminado
//ZonaVentaFactura
//Descuento
//ValorFactura
//SaldoFactura
//codAsesor
//zonaVentas
//cliente
//CuentaCliente
//Consultamos el id recibo de caja
                        $sqlId = "SELECT Id FROM `reciboscaja` WHERE CodAsesor='" . $itemDetalle->codAsesor . "' AND ZonaVenta = '" . $itemDetalle->zonaVentas . "' AND CuentaCliente = '" . $itemDetalle->cliente . "' AND Provisional = '" . $itemDetalle->provisional . "' AND ReciboMaquina='" . $itemDetalle->idRecibo . "'  AND Web='0' AND Estado='0'; ";
                        $stmtId = $db->ejecutar($sqlId);
                        $resultadoId = $db->obtener_fila($stmtId, 0);
                        $IdReciboCaja = $resultadoId['Id'];

                        $sqlCon = "SELECT COUNT(*) AS Conteo FROM `reciboscajafacturas` WHERE IdReciboCaja = '" . $IdReciboCaja . "' AND NumeroFactura = '" . $itemDetalle->factura . "' AND ValorAbono = '" . $itemDetalle->valor . "' AND CodMotivoSaldo = '" . $itemDetalle->motivo . "'; ";
                        $stmtCon = $db->ejecutar($sqlCon);
                        $resultadoCon = $db->obtener_fila($stmtCon, 0);
                        $Conteo2 = $resultadoCon['Conteo'];

                        $sql_detalles = "INSERT INTO `reciboscajafacturas`(`IdReciboCaja`,ZonaVentaFactura, `NumeroFactura`, `ValorAbono`, DtoProntoPago,`CodMotivoSaldo`,ValorFactura,SaldoFactura,CuentaCliente) VALUES ('" . $IdReciboCaja . "','" . $itemDetalle->ZonaVentaFactura . "','" . $itemDetalle->factura . "','" . $itemDetalle->valor . "','" . $itemDetalle->Descuento . "','" . $itemDetalle->motivo . "','" . $itemDetalle->ValorFactura . "','" . $itemDetalle->SaldoFactura . "','" . $itemDetalle->CuentaCliente . "');";

                        if ($Conteo2 == 0) {
                            $db->ejecutar($sql_detalles);

                            $manejador = fopen('Log/' . $itemDetalle->zonaVentas . 'VN_RECAUDOFACTURA.txt', 'a+');
                            fputs($manejador, $sql_detalles . "\n");
                            fclose($manejador);
                        } else {
                            $manejador = fopen('Log/' . $itemDetalle->zonaVentas . 'Warning.txt', 'a+');
                            fputs($manejador, "No se pudo insertar datos duplicados: " . $sql_detalles . "\n");
                            fclose($manejador);
                            return "Error";
                        }
                    }

                    foreach ($item->DetallesEfectivo as $itemEfe) {
//factura
//idRecibo
//valor
//codAsesor
//zonaVentas
//cliente
//provisonal
//Consultamos el id recibo de caja
                        $sqlId = "SELECT Id FROM `reciboscaja` WHERE CodAsesor='" . $itemEfe->codAsesor . "' AND ZonaVenta = '" . $itemEfe->zonaVentas . "' AND CuentaCliente = '" . $itemEfe->cliente . "' AND Provisional = '" . $itemEfe->provisonal . "' AND ReciboMaquina='" . $itemEfe->idRecibo . "'  AND Web='0' AND Estado='0'; ";
                        $stmtId = $db->ejecutar($sqlId);
                        $resultadoId = $db->obtener_fila($stmtId, 0);
                        $IdReciboCaja = $resultadoId['Id'];

                        $sqlIdFac = "SELECT Id FROM `reciboscajafacturas` WHERE IdReciboCaja='" . $IdReciboCaja . "' AND NumeroFactura = '" . $itemEfe->factura . "'; ";
                        $stmtIdFac = $db->ejecutar($sqlIdFac);
                        $resultadoIdFac = $db->obtener_fila($stmtIdFac, 0);
                        $IdReciboCajaFactura = $resultadoIdFac['Id'];

                        $sqconE = "SELECT COUNT(*) AS Conteo FROM `recibosefectivo` WHERE `IdReciboCajaFacturas` = '" . $IdReciboCajaFactura . "' AND `Valor` = '" . $itemEfe->valor . "'; ";
                        $stmE = $db->ejecutar($sqconE);
                        $resultadoE = $db->obtener_fila($stmE, 0);
                        $Conteo3 = $resultadoE['Conteo'];

                        $sql_detalles = "INSERT INTO `recibosefectivo`(`IdReciboCajaFacturas`, `Valor`,ValorTotal) VALUES ('" . $IdReciboCajaFactura . "','" . $itemEfe->valor . "','" . $itemEfe->ValorTotal . "');";

                        if ($Conteo3 == 0) {
                            $db->ejecutar($sql_detalles);

                            $manejador = fopen('Log/' . $itemEfe->zonaVentas . 'VN_RECAUDO_EFECTIVO.txt', 'a+');
                            fputs($manejador, $sql_detalles . "\n");
                            fclose($manejador);
                        } else {
                            $manejador = fopen('Log/' . $itemEfe->zonaVentas . 'Warning.txt', 'a+');
                            fputs($manejador, "No se pudo insertar datos duplicados: " . $sql_detalles . "\n");
                            fclose($manejador);
                            return "Error";
                        }
                    }

                    foreach ($item->DetallesConsignacion as $itemCons) {
//idRecibo
//factura
//numero
//banco
//cuenta
//fecha
//valor
//valorTotal
//codAsesor
//zonaVentas
//cliente
//provisonal
                        $sqlId = "SELECT Id FROM `reciboscaja` WHERE CodAsesor='" . $itemCons->codAsesor . "' AND ZonaVenta = '" . $itemCons->zonaVentas . "' AND CuentaCliente = '" . $itemCons->cliente . "' AND Provisional = '" . $itemCons->provisonal . "' AND ReciboMaquina='" . $itemCons->idRecibo . "'  AND Web='0' AND Estado='0'; ";
                        $stmtId = $db->ejecutar($sqlId);
                        $resultadoId = $db->obtener_fila($stmtId, 0);
                        $IdReciboCaja = $resultadoId['Id'];

                        $sqlIdFac = "SELECT Id FROM `reciboscajafacturas` WHERE IdReciboCaja='" . $IdReciboCaja . "' AND NumeroFactura = '" . $itemCons->factura . "'; ";
                        $stmtIdFac = $db->ejecutar($sqlIdFac);
                        $resultadoIdFac = $db->obtener_fila($stmtIdFac, 0);
                        $IdReciboCajaFactura = $resultadoIdFac['Id'];

                        $sqconE = "SELECT COUNT(*) AS Conteo FROM `recibosefectivoconsignacion` WHERE IdReciboCajaFacturas = '" . $IdReciboCajaFactura . "' AND NroConsignacionEfectivo = '" . $itemCons->numero . "' AND CodBanco = '" . $itemCons->banco . "' AND CodCuentaBancaria = '" . $itemCons->cuenta . "' AND Fecha = '" . $itemCons->fecha . "' AND Valor = '" . $itemCons->valor . "'; ";
                        $stmE = $db->ejecutar($sqconE);
                        $resultadoE = $db->obtener_fila($stmE, 0);
                        $Conteo4 = $resultadoE['Conteo'];

                        $sql_detalles = "INSERT INTO `recibosefectivoconsignacion`(`IdReciboCajaFacturas`, `NroConsignacionEfectivo`, `CodBanco`, `CodCuentaBancaria`, `Fecha`, `Valor`,ValorTotal) VALUES ('" . $IdReciboCajaFactura . "','" . $itemCons->numero . "','" . $itemCons->banco . "','" . $itemCons->cuenta . "','" . $itemCons->fecha . "','" . $itemCons->valor . "','" . $itemCons->valorTotal . "');";

                        if ($Conteo4 == 0) {
                            $db->ejecutar($sql_detalles);

                            $manejador = fopen('Log/' . $itemCons->zonaVentas . 'VN_RECAUDOSCONSIGNACION.txt', 'a+');
                            fputs($manejador, $sql_detalles . "\n");
                            fclose($manejador);
                        } else {
                            $manejador = fopen('Log/' . $itemCons->zonaVentas . 'Warning.txt', 'a+');
                            fputs($manejador, "No se pudo insertar datos duplicados: " . $sql_detalles . "\n");
                            fclose($manejador);
                            return "Error";
                        }
                    }

                    $guardarChequePosfechado = 0;
                    foreach ($item->DetallesCheque as $itemChe) {
//idRecibo
//factura
//numero
//banco
//cuenta
//fecha
//valor
//girado
//otro
//posfechado
//valorTotal
//codAsesor
//zonaVentas
//cliente
//provisonal
//Consultamos el id recibo de caja
                        $sqlId = "SELECT Id FROM `reciboscaja` WHERE CodAsesor='" . $itemChe->codAsesor . "' AND ZonaVenta = '" . $itemChe->zonaVentas . "' AND CuentaCliente = '" . $itemChe->cliente . "' AND Provisional = '" . $itemChe->provisonal . "' AND ReciboMaquina='" . $itemChe->idRecibo . "'  AND Web='0' AND Estado='0'; ";
                        $stmtId = $db->ejecutar($sqlId);
                        $resultadoId = $db->obtener_fila($stmtId, 0);
                        $IdReciboCaja = $resultadoId['Id'];

                        $sqlIdFac = "SELECT Id FROM `reciboscajafacturas` WHERE IdReciboCaja='" . $IdReciboCaja . "' AND NumeroFactura = '" . $itemChe->factura . "'; ";
                        $stmtIdFac = $db->ejecutar($sqlIdFac);
                        $resultadoIdFac = $db->obtener_fila($stmtIdFac, 0);
                        $IdReciboCajaFactura = $resultadoIdFac['Id'];

                        $sqconE = "SELECT COUNT(*) AS Conteo FROM `reciboscheque` WHERE IdReciboCajaFacturas = '" . $IdReciboCajaFactura . "' AND NroCheque = '" . $itemChe->numero . "' AND CodBanco = '" . $itemChe->banco . "' AND CuentaCheque = '" . $itemChe->cuenta . "' AND Valor = '" . $itemChe->valor . "' AND Fecha = '" . $itemChe->fecha . "' AND Girado='" . $itemChe->girado . "' AND Otro='" . $itemChe->otro . "'; ";
                        $stmE = $db->ejecutar($sqconE);
                        $resultadoE = $db->obtener_fila($stmE, 0);
                        $Conteo5 = $resultadoE['Conteo'];

                        if ($itemChe->posfechado == 1) {
                            $guardarChequePosfechado = 1;
                        }

                        $sql_detalles = "INSERT INTO `reciboscheque`( `IdReciboCajaFacturas`, `NroCheque`, `CodBanco`, `CuentaCheque`, `Fecha`,Girado,Otro, `Valor`,Posfechado,ValorTotal) VALUES ('" . $IdReciboCajaFactura . "','" . $itemChe->numero . "','" . $itemChe->banco . "','" . $itemChe->cuenta . "','" . $itemChe->fecha . "','" . $itemChe->girado . "','" . $itemChe->otro . "','" . $itemChe->valor . "','" . $itemChe->posfechado . "','" . $itemChe->valorTotal . "');";

                        if ($Conteo5 == 0) {

                            $db->ejecutar($sql_detalles);

                            $manejador = fopen('Log/' . $itemChe->zonaVentas . 'VN_RECUDOSCHEQUES.txt', 'a+');
                            fputs($manejador, $sql_detalles . "\n");
                            fclose($manejador);
                        } else {
                            $manejador = fopen('Log/' . $itemChe->zonaVentas . 'Warning.txt', 'a+');
                            fputs($manejador, "No se pudo insertar datos duplicados: " . $sql_detalles . "\n");
                            fclose($manejador);
                            return "Error";
                        }
                    }

                    if ($guardarChequePosfechado >= 1) {
                        $sql = "UPDATE `reciboscaja` SET `EstadoChequePosfechado`='0' WHERE `Id`='" . $idRecaudo . "';";
                        $db->ejecutar($sql);

                        if ($zonaVenta12 == "11178") {
                            
                        } else {
                            transacciones($idRecaudo, '12');
                        }
                    }


                    foreach ($item->DetallesChequeConsig as $itemCheCons) {
//idRecibo
//factura
//numero
//banco
//cuenta
//fecha
//numeroCheque
//fechaCheque
//bancoCheque
//cuentaCheque
//valorCheque
//valorTotal
//codAsesor
//zonaVentas
//cliente
//provisonal
//Consultamos el id recibo de caja			
                        $sqlId = "SELECT Id FROM `reciboscaja` WHERE CodAsesor='" . $itemCheCons->codAsesor . "' AND ZonaVenta = '" . $itemCheCons->zonaVentas . "' AND CuentaCliente = '" . $itemCheCons->cliente . "' AND Provisional = '" . $itemCheCons->provisonal . "' AND ReciboMaquina='" . $itemCheCons->idRecibo . "'  AND Web='0' AND Estado='0'; ";
                        $stmtId = $db->ejecutar($sqlId);
                        $resultadoId = $db->obtener_fila($stmtId, 0);
                        $IdReciboCaja = $resultadoId['Id'];

                        $sqlIdFac = "SELECT Id FROM `reciboscajafacturas` WHERE IdReciboCaja='" . $IdReciboCaja . "' AND NumeroFactura = '" . $itemCheCons->factura . "'; ";
                        $stmtIdFac = $db->ejecutar($sqlIdFac);
                        $resultadoIdFac = $db->obtener_fila($stmtIdFac, 0);
                        $IdReciboCajaFactura = $resultadoIdFac['Id'];

                        $sqconE = "SELECT COUNT(*) AS Conteo FROM `reciboschequeconsignacion` WHERE IdReciboCajaFacturas = '" . $IdReciboCajaFactura . "' AND NroConsignacionCheque = '" . $itemCheCons->numero . "' AND CodBanco = '" . $itemCheCons->banco . "' AND CodCuentaBancaria = '" . $itemCheCons->cuenta . "' AND Fecha = '" . $itemCheCons->fecha . "'; ";
                        $stmE = $db->ejecutar($sqconE);
                        $resultadoE = $db->obtener_fila($stmE, 0);
                        $Conteo6 = 0;

                        $sql_detalles = "INSERT INTO `reciboschequeconsignacion`(`IdReciboCajaFacturas`, `NroConsignacionCheque`, `CodBanco`, `CodCuentaBancaria`, `Fecha`) VALUES ('" . $IdReciboCajaFactura . "','" . $itemCheCons->numero . "','" . $itemCheCons->banco . "','" . $itemCheCons->cuenta . "','" . $itemCheCons->fecha . "');";

                        if ($Conteo6 == 0) {

                            $db->ejecutar($sql_detalles);

                            $manejador = fopen('Log/' . $itemCheCons->zonaVentas . 'VN_RECAUDO_CHEQUECONSIGNACION1.txt', 'a+');
                            fputs($manejador, $sql_detalles . "\n");
                            fclose($manejador);
                        } else {
                            $manejador = fopen('Log/' . $itemCheCons->zonaVentas . 'Warning.txt', 'a+');
                            fputs($manejador, "No se pudo insertar datos duplicados: " . $sql_detalles . "\n");
                            fclose($manejador);
                            return "Error";
                        }

                        $sqcondd = "SELECT Id FROM `reciboschequeconsignacion` WHERE IdReciboCajaFacturas = '" . $IdReciboCajaFactura . "' AND NroConsignacionCheque = '" . $itemCheCons->numero . "' AND CodBanco = '" . $itemCheCons->banco . "' AND CodCuentaBancaria = '" . $itemCheCons->cuenta . "' AND Fecha = '" . $itemCheCons->fecha . "'; ";
                        $stmdd = $db->ejecutar($sqcondd);
                        $resultadodd = $db->obtener_fila($stmdd, 0);
                        $IdreciboschequeConsignacion = $resultadodd['Id'];


                        $sqconDER = "SELECT COUNT(*) AS Conteo FROM `reciboschequeconsignaciondetalle` WHERE `IdRecibosChequeConsignacion` = '" . $IdreciboschequeConsignacion . "' AND `NroChequeConsignacion` = '" . $itemCheCons->numeroCheque . "' AND `CodBanco` = '" . $itemCheCons->bancoCheque . "' AND `CuentaBancaria` = '" . $itemCheCons->cuentaCheque . "' AND `Fecha` = '" . $itemCheCons->fechaCheque . "' AND `Valor` = '" . $itemCheCons->valorCheque . "'; ";
                        $stmDER = $db->ejecutar($sqconDER);
                        $resultadoDER = $db->obtener_fila($stmDER, 0);
                        $Conteo7 = $resultadoDER['Conteo'];

                        $sql_detallesDetalle = "INSERT INTO `reciboschequeconsignaciondetalle`(`IdRecibosChequeConsignacion`, `NroChequeConsignacion`, `CodBanco`, `CuentaBancaria`, `Fecha`, `Valor`,ValorTotal) VALUES ('" . $IdreciboschequeConsignacion . "','" . $itemCheCons->numeroCheque . "','" . $itemCheCons->bancoCheque . "','" . $itemCheCons->cuentaCheque . "','" . $itemCheCons->fechaCheque . "','" . $itemCheCons->valorCheque . "','" . $itemCheCons->valorTotal . "');";

                        if ($Conteo7 == 0) {

                            $db->ejecutar($sql_detallesDetalle);

                            $manejador = fopen('Log/' . $itemCheCons->zonaVentas . 'VN_RECAUDO_CHEQUECONSIGNACION2.txt', 'a+');
                            fputs($manejador, $sql_detallesDetalle . "\n");
                            fclose($manejador);
                        } else {
                            $manejador = fopen('Log/' . $itemCheCons->zonaVentas . 'Warning.txt', 'a+');
                            fputs($manejador, "No se pudo insertar datos duplicados: " . $sql_detallesDetalle . "\n");
                            fclose($manejador);
                            return "Error";
                        }
                    }



                    if ($zonaVenta12 == "11178") {
                        
                    } else {
                        transacciones($idRecaudo, '11');
                    }

                    $manejador = fopen('Log/' . $item->zonaVentas . 'VN_RECAUDO_ENCABEZADO.txt', 'a+');
                    fputs($manejador, $sql_detalles . "\n");
                    fclose($manejador);
                } else {
                    $manejador = fopen('Log/' . $item->zonaVentas . 'Warning.txt', 'a+');
                    fputs($manejador, "No se pudo insertar datos duplicados: " . $sql_detalles . "\n");
                    fclose($manejador);
                    return "Error";
                }
            }
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
            return "Error";
        }
        return "OK";
    }
}

function noventa($value) {
    if ($value['value'] == 'INSERT_NOVENTA') {
        $db = Db::getInstance();

        $datos = json_decode(utf8_decode($value['datos']));
        $imei = $value['Imei'];
        $idSim = $value['IdSim'];
        $numeroCuenta = $value['NumeroCuenta'];
        $version = $value['Version'];

        $manejador = fopen('Log/VN_CONSIGNACIONES.txt', 'a+');
        fputs($manejador, $value['datos'] . "\n");
        fputs($manejador, "Imei:" . $imei . "  IdSim: " . $idSim . "   NumeroCuenta:  " . $numeroCuenta . "    Version:" . $version . "\n");
        fclose($manejador);

        try {

            foreach ($datos->NoVentas as $item) {
                $sql = "SELECT COUNT(1) as numero FROM noventas WHERE CodAsesor='" . $item->CodAsesor . "' AND CodZonaVentas='" . $item->CodZonaVentas . "' AND CuentaCliente='" . $item->CuentaCliente . "' AND IdentificadorEnvio=0 AND FechaNoVenta=CURDATE();";
                $stmt = $db->ejecutar($sql);
                $resultado = $db->obtener_fila($stmt, 0);
                $Conteo = $resultado['numero'];

                $sql_insert = "INSERT INTO `noventas`(`CodAsesor`, `CodZonaVentas`, `CuentaCliente`, `FechaNoVenta`, `HoraNoVenta`, `CodMotivoNoVenta`, `IdentificadorEnvio`, `EstadoXml`, `Web`, Responsable, CodigoCanal,Imei) VALUES ('" . $item->CodAsesor . "','" . $item->CodZonaVentas . "','" . $item->CuentaCliente . "',CURDATE(),CURTIME(),'" . $item->CodMotivoNoVenta . "',0,'',0, '" . $item->Identificacion . "', (SELECT fcJerarquia01('" . $item->CodAsesor . "') AS canal),'" . $imei . "');";

                if ($Conteo == 0) {

                    $db->ejecutar($sql_insert);

                    $idNoventa = $db->lastID();

                    $manejador = fopen('Log/' . 'VN_INSERT_NO_VENTA.txt', 'a+');
                    fputs($manejador, $sql_insert);
                    fclose($manejador);
                } else {
                    $manejador = fopen('Log/' . $item->usuarioco . 'Warning.txt', 'a+');
                    fputs($manejador, "No se pudo insertar datos duplicados: " . $sql_detalles . "\n");
                    fclose($manejador);
                    return "Error";
                }

                // transacciones($idNoventa, '10');
            }
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
            return "Error";
        }
        return "OK";
    }
}

function consignacion($value) {
    if ($value['value'] == 'INSERT_CONSIGNACION') {
        $db = Db::getInstance();

        $datos = json_decode(utf8_decode($value['datos']));
        $usuarioco = $value['usuarioco'];
        $codasesor = $value['codasesor'];
        $imei = $value['Imei'];
        $idSim = $value['IdSim'];
        $numeroCuenta = $value['NumeroCuenta'];
        $version = $value['Version'];

        $manejador = fopen('Log/VN_CONSIGNACIONES.txt', 'a+');
        fputs($manejador, $value['datos'] . "\n");
        fputs($manejador, "Imei:" . $imei . "  IdSim: " . $idSim . "   NumeroCuenta:  " . $numeroCuenta . "    Version: " . $version . "\n");
        fclose($manejador);

        try {

            foreach ($datos->DatosConsignacion as $item) {
                $sql = "SELECT COUNT(*) AS Conteo FROM `consignacionesvendedor` WHERE CodZonaVentas = '" . $item->usuarioco . "' AND ValorConsignadoEfectivo = '" . $item->valor_efectivo11 . "' AND ValorConsignadoCheque = '" . $item->valor_cheque11 . "' AND `CuentaConsignacion`='" . $item->cuenta . "' AND NroConsignacion = '" . $item->numero . "';";
                $stmt = $db->ejecutar($sql);
                $resultado = $db->obtener_fila($stmt, 0);
                $Conteo = $resultado['Conteo'];


                $sql3 = "SELECT IdentificadorBanco FROM `bancos` WHERE CodBanco = '" . $item->banco . "';";
                $stmt3 = $db->ejecutar($sql3);
                $resultado3 = $db->obtener_fila($stmt3, 0);
                $iden_banco = $resultado3['IdentificadorBanco'];

                $valorEfectivo = $item->valor_efectivo11;
                $valorCheque = $item->valor_cheque11;

                $valorEfectivo = str_replace(",", ".", $item->valor_efectivo11);
                $valorCheque = str_replace(",", ".", $item->valor_cheque11);

                $sql_detalles = "INSERT INTO `consignacionesvendedor`(`CodZonaVentas`, `CodAsesor`, `FechaConsignacion`, `HoraConsignacion`, " .
                        "`NroConsignacion`, `Banco`, `CuentaConsignacion`, `FechaConsignacionVendedor`, `ValorConsignadoEfectivo`, `ValorConsignadoCheque`," .
                        " `Oficina`, `Ciudad`, `Estado`, `IdentificadorEnvio`, `ArchivoXml`, `Web`,IdentificadorBanco,CodigoCanal,Responsable,Imei) VALUES ('" . $item->usuarioco .
                        "','" . $item->codasesor . "',CURDATE(),CURTIME(),'" . $item->numero . "','" . $item->banco . "','" . $item->cuenta . "','" . $item->fecha .
                        "','" . $valorEfectivo . "','" . $valorCheque . "','" . $item->oficina . "','" . $item->ciudad .
                        "','0','0','','0','" . $iden_banco . "',(SELECT fcJerarquia01('" . $item->codasesor . "') AS canal),'" . $item->identificacion . "','" . $imei . "');";

                $sql3 = "SELECT MAX(IdConsignacion) AS Max FROM `consignacionesvendedor`;";
                $stmt3 = $db->ejecutar($sql3);
                $resultado3 = $db->obtener_fila($stmt3, 0);
                $MaxId = $resultado3['Max'];

                if ($Conteo == 0) {

                    $db->ejecutar($sql_detalles);
                    $idConsignacionVende = $db->lastID();

                    $sql3 = "SELECT MAX(IdConsignacion) AS Max FROM `consignacionesvendedor`;";
                    $stmt3 = $db->ejecutar($sql3);
                    $resultado3 = $db->obtener_fila($stmt3, 0);
                    $Agencia = $resultado3['Max'];


                    // $sql_Transacciones = "INSERT INTO `transaccionesax`(`CodTipoDocumentoActivity`, `IdDocumento`, `CodigoAgencia`, `EstadoTransaccion`) VALUES ('5','$MaxId','002','0');";
                    //$idConsignacionVende = $db->lastID();

                    $manejador = fopen('Log/' . $item->usuarioco . 'VN_INSERT_CONSIGNACION.txt', 'a+');
                    fputs($manejador, $sql_detalles);
                    fclose($manejador);
                } else {
                    $manejador = fopen('Log/' . $item->usuarioco . 'Warning.txt', 'a+');
                    fputs($manejador, "No se pudo insertar datos duplicados: " . $sql_detalles . "\n");
                    fclose($manejador);
                    return "Error";
                }
                if ($item->usuarioco == "11178") {
                    
                } else {

                    transacciones($idConsignacionVende, '5');
                }
            }
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
            return "Error";
        }

        return "OK";
    }
}

function clienteNuevo($value) {

    if ($value['value'] == 'INSERT_CLIENTE_NUEVO') {
        $db = Db::getInstance();

        $datosCliente = jsonDecode(utf8_decode($value['cliente']));
        $datosEncuestaSenior = jsonDecode(utf8_decode($value['encuesta']));
        $zona = $value['zona'];
        $asesor = $value['asesor'];
        $responsable = $value['identificacion'];
        $imei = $value['Imei'];
        $idSim = $value['IdSim'];
        $numeroCuenta = $value['NumeroCuenta'];
        $version = $value['Version'];
        $RutaSeleccionada = $value['RutaSeleccionada'];

        $manejador = fopen('Log/VN_CLIENTE_NUEVO.txt', 'a+');
        fputs($manejador, $value['cliente'] . "\n");
        fputs($manejador, $value['encuesta'] . "\n");
        fputs($manejador, "Asesor: " . $asesor . "   Zona: " . $zona . "    Identificacion: " . $responsable . " \n");
        fputs($manejador, "Imei:" . $imei . "  IdSim: " . $idSim . "   NumeroCuenta:  " . $numeroCuenta . "    Version: " . $version . "\n");
        fclose($manejador);

        try {

            foreach ($datosCliente->DatoCliente as $item) {
                //CuentaCliente
                //TipoDocumento
                //Identificacion
                //RazonSocial
                //PrimerNombre
                //SegundoNombre
                //PrimerApellido
                //SegundoApellido
                //Ciiu
                //Establecimiento
                //Departamento
                //Ciudad
                //Barrio
                //OtroBarrio
                //Direccion
                //Telefono
                //TelefonoMovil
                //CorreoElectronico
                //Ruta->Frecuencia,NumeroVisita,Hora,Minutos


                $numeroVisita = "";
                $posicion = "";
                foreach ($item->Ruta as $itemRuta) {
                    $numeroVisita = $itemRuta->NumeroVisita;
                    $posicion = $itemRuta->Hora . ':' . $itemRuta->Minutos;
                }

                $digitoVerificacion = "";
                if ($item->TipoDocumento == "001") {
                    $digitoVerificacion = calcular_digito($item->Identificacion);
                }

                $razonSocial = "";
                if ($item->RazonSocial == "0") {
                    $razonSocial = "";
                } else {
                    $razonSocial = $item->RazonSocial;
                }

                $correoElectonico = "";
                if ($item->CorreoElectronico == "0") {
                    $correoElectonico = "";
                } else {
                    $correoElectonico = $item->CorreoElectronico;
                }

                $primerNombre = "";
                if ($item->PrimerNombre == "0") {
                    $primerNombre = "";
                } else {
                    $primerNombre = $item->PrimerNombre;
                }

                $segundoNombre = "";
                if ($item->SegundoNombre == "0") {
                    $segundoNombre = "";
                } else {
                    $segundoNombre = $item->SegundoNombre;
                }

                $primerApellido = "";
                if ($item->PrimerApellido == "0") {
                    $primerApellido = "";
                } else {
                    $primerApellido = $item->PrimerApellido;
                }

                $segundoApellido = "";
                if ($item->SegundoApellido == "0") {
                    $segundoApellido = "";
                } else {
                    $segundoApellido = $item->SegundoApellido;
                }

                $codBarrio = "";

                if (empty($item->Barrio)) {
                    $codBarrio = explode("-", $item->OtroBarrio);
                    $codBarrio = $codBarrio[0];
                } else {
                    $codBarrio = $item->Barrio;
                }

                if ($RutaSeleccionada > 0 && $RutaSeleccionada < 7) {

                    $SemanaRuta = "R1";
                } else if ($RutaSeleccionada > 6 && $RutaSeleccionada < 13) {
                    $SemanaRuta = "R2";
                } else if ($RutaSeleccionada > 12 && $RutaSeleccionada < 19) {
                    $SemanaRuta = "R3";
                } else if ($RutaSeleccionada > 18 && $RutaSeleccionada < 25) {
                    $SemanaRuta = "R4";
                }


                //$ConsultarZonaLogistica = "SELECT CodigoZonaLogistica FROM `clienteruta` WHERE NumeroVisita = '$numeroVisita' AND CodZonaVentas = '$zona' GROUP BY CodigoZonaLogistica; ";
                $ConsultarZonaLogistica = "SELECT CodigoZonaLogistica FROM `clienteruta` cr INNER JOIN frecuenciavisita f ON cr.`NumeroVisita` = f.NumeroVisita WHERE " . $SemanaRuta . " = '" . $RutaSeleccionada . "' AND cr.CodZonaVentas = '$zona' GROUP BY CodigoZonaLogistica ORDER BY `cr`.`CodigoZonaLogistica` DESC;";


                $stmtConsultarZonaLogistica = $db->ejecutar($ConsultarZonaLogistica);
                $resultadoConsultarZonaLogisica = $db->obtener_fila($stmtConsultarZonaLogistica, 0);
                $zonaLogistica = $resultadoConsultarZonaLogisica['CodigoZonaLogistica'];
                if ($zonaLogistica == null || $zonaLogistica == '') {
                    $zonaLogistica = '000';
                }

                $sql_detalles = "INSERT INTO `clientenuevo`( `CodZonaVentas`, `CodAsesor`, `CuentaCliente`, `Identificacion`, `DigitoVerificacion`, `CodTipoDocumento`, 
                    `Nombre`, `RazonSocial`, `Establecimiento`, `CodigoCiuu`, `PrimerNombre`, `SegundoNombre`, `PrimerApellido`, `SegundoApellido`, `Direccion`, `CodBarrio`, 
                    `OtroBarrio`, `Telefono`, `TelefonoMovil`, `Email`, `CodCadenadeEmpresa`, `NumeroVisita`, `Posicion`, ZonaLogistica,CodigoPostal,DireccionEstandar,
                     `FechaRegistro`, `HoraRegistro`, `Estado`, `Generado`, `Enviado`, `ArchivoXml`, `IdentificadorEnvio`, `CodigoCanal`, `Responsable`, `Imei`,NombreCanal) VALUES ('" . $zona . "','" . $asesor .
                        "','" . $item->CuentaCliente . "','" . $item->Identificacion . "','" . $digitoVerificacion . "','" . $item->TipoDocumento . "','" . strtoupper($primerNombre) .
                        "  " . strtoupper($primerApellido) . "','" . strtoupper($razonSocial) . "','" . strtoupper($item->Establecimiento) . "','" . $item->Ciiu . "','" . strtoupper($primerNombre) .
                        "','" . strtoupper($segundoNombre) . "','" . strtoupper($primerApellido) . "','" . strtoupper($segundoApellido) . "','" . strtoupper($item->Direccion) . "','" . $codBarrio .
                        "','','" . $item->Telefono . "','" . $item->TelefonoMovil . "','" . $correoElectonico . "','Pendiente','" . $numeroVisita . "','" . $posicion . "','" . $zonaLogistica . "','','',CURDATE(),CURTIME(),'','0','0','','0',
                       (SELECT fcJerarquia01('" . $asesor . "') AS canal),'" . $responsable . "','" . $imei . "',(SELECT `NombreCanal` FROM `jerarquiacomercial` WHERE NumeroIdentidad='" . $asesor . "'));";
                $db->ejecutar($sql_detalles);

                $idClienteN = $db->lastID();

                /*  $sql_transaccionesAx = "INSERT INTO `transaccionesax`(`CodTipoDocumentoActivity`, `IdDocumento`, `CodigoAgencia`, `EstadoTransaccion`) VALUES ('9','" . $idClienteN . "','" . $codAgencia . "',0)";
                  $db->ejecutar($sql_transaccionesAx); */
                $manejador = fopen('Log/' . $zona . 'VN_INSERT_CLIENTE_NUEVO.txt', 'a+');
                fputs($manejador, $sql_detalles . "\n");
                fclose($manejador);


                foreach ($datosEncuestaSenior->Encuesta as $item) {
                    //IdTipoEncuesta
                    //CuentaCliente
                    //CodAsesor
                    //Fecha
                    //Hora
                    //Detalles->Respuesta,Encuesta,IdPregunta,Consecutivo,Texto
                    //

              $sqlEncuesta = "INSERT INTO `encuesta`( `IdTipoEncuesta`, `CuentaCliente`, `CodAsesor`, `Fecha`, `Hora`) VALUES ('" . $item->IdTipoEncuesta . "','" . $item->CuentaCliente . "','" . $item->CodAsesor . "',CURDATE(),CURTIME());";

                    $manejador = fopen('Log/' . $zona . 'VN_INSERT_ENCUESTA.txt', 'a+');
                    fputs($manejador, $sqlEncuesta . "\n");
                    fclose($manejador);

                    $db->ejecutar($sqlEncuesta);

                    $idEncuesta = $db->lastID();

                    $manejador = fopen('Log/' . $zona . 'VN_INSERT_ENCUESTA.txt', 'a+');
                    fputs($manejador, "id_Encuesta:" . $idEncuesta . "\n");
                    fclose($manejador);

                    $mayor = 0;
                    $idPre = "";
                    foreach ($item->Detalles as $itemDetalle) {
                        $sql = "INSERT INTO `encuestadetalle`( `IdEncuesta`, `IdPreguntaEncuesta`, `IdRespuestaEncuesta`, `ValorRespuesta`) VALUES ('" . $idEncuesta . "','" . $itemDetalle->IdPregunta . "','" . $itemDetalle->Respuesta . "','" . $itemDetalle->Texto . "');";

                        $manejador = fopen('Log/' . $zona . 'VN_INSERT_ENCUESTA_Detalle.txt', 'a+');
                        fputs($manejador, $sql . "\n");
                        fclose($manejador);

                        $db->ejecutar($sql);

                        if ($itemDetalle->Consecutivo > $mayor) {
                            $mayor = $itemDetalle->Consecutivo;
                            $idPre = $itemDetalle->Respuesta;
                        }
                    }


                    $client = new nusoap_client("http://altipal.datosmovil.info/SM/WebServiceLogin.php?wsdl");
                    $client->soap_defencoding = 'UTF-8';
                    $err = $client->getError(); /*                     * *Captura de errores** */
                    if ($err) {
                        echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
                        echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->getDebug(), ENT_QUOTES) . '</pre>';
                        exit();
                    }

                    $args = array('value' => 'respuestasegmentacion', 'idPre' => $idPre);
                    $IdCodigoSegmentacion = $client->call('respuestasegmentacion', array($args));


                    $updatCodigoCadena = "UPDATE clientenuevo SET CodCadenadeEmpresa='" . $IdCodigoSegmentacion . "' WHERE Id='" . $idClienteN . "'; ";
                    $db->ejecutar($updatCodigoCadena);
                }

                //if ($zona == "11178") {
                //} else {

                If ($idClienteN == '0' || $idClienteN == null || $idClienteN == '') {
                    
                } else {
                    transacciones($idClienteN, '9');
                }
                // }
                return "OK";
            }
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
            return "Error";
        }
    }
}

function coordenadas($value) {
    if ($value['value'] == 'INSERT_COORDENADAS') {
        $db = Db::getInstance();

        $datos = json_decode(utf8_decode($value['datos']));
        $imei = $value['Imei'];
        $idSim = $value['IdSim'];
        $numeroCuenta = $value['NumeroCuenta'];
        $version = $value['Version'];

        $manejador = fopen('Log/VN_COORDENADAS.txt', 'a+');
        fputs($manejador, $value['datos'] . "\n");
        fputs($manejador, "Imei:" . $imei . "  IdSim: " . $idSim . "   NumeroCuenta:  " . $numeroCuenta . "     Version: " . $version . "\n");
        fclose($manejador);

        try {

            foreach ($datos->Coordenadas as $item) {
//CuentaCliente
//IdDocumento
//Origen
//Longitud
//Latitud
//identificacion
//codasesor
//codZonaVentas

                $sqlId = "SELECT COUNT(*) AS Conteo FROM `coordenadas` WHERE CuentaCliente = '" . $item->CuentaCliente . "' AND IdDocumento = '" . $item->IdDocumento . "' AND Origen = '" . $item->Origen . "' AND Longitud = '" . $item->Longitud . "' AND Latitud = '" . $item->Latitud . "' AND Fecha = CURDATE() AND CodZonaVentas = '" . $item->codZonaVentas . "'; ";
                $stmtId = $db->ejecutar($sqlId);
                $resultadoId = $db->obtener_fila($stmtId, 0);
                $conteo = $resultadoId['Conteo'];

                if ($conteo == 0) {

                    if ($item->Origen != '') {
                        $sql = "INSERT INTO `coordenadas`(`CuentaCliente`, `IdDocumento`, `Origen`, `Longitud`, `Latitud`, `Fecha`, `Hora`, `CodZonaVentas`, `CodAsesor`) VALUES ('" . $item->CuentaCliente . "','" . $item->IdDocumento . "','" . $item->Origen . "','" . $item->Longitud . "','" . $item->Latitud . "',CURDATE(),CURTIME(),'" . $item->codZonaVentas . "','" . $item->codasesor . "');";
                        $db->ejecutar($sql);

                        //$idCoordenada = $db->lastID();

                        if ($item->Origen == '3') {

                            $sqlCons = "SELECT `Id` FROM `clientenuevo` WHERE `CodZonaVentas`='" . $item->codZonaVentas . "' AND `Identificacion` ='" . $item->CuentaCliente . "' AND `FechaRegistro` = CURDATE() AND `Latitud` IS NULL AND `Longitud` IS NULL ORDER BY Id DESC LIMIT 1;";
                            $stCons = $db->ejecutar($sqlCons);
                            $resDatos = $db->obtener_fila($stCons, 0);
                            $IdClienteNuevo = $resDatos['Id'];

                            $sqlUpdate = "UPDATE `clientenuevo` SET `Latitud`='" . $item->Latitud . "',`Longitud`='" . $item->Longitud . "' WHERE Id='" . $IdClienteNuevo . "'; ";
                            $db->ejecutar($sqlUpdate);

                            $manejador = fopen('Log/' . $item->codZonaVentas . 'VN_UPDATE_COORDENADAS.txt', 'a+');
                            fputs($manejador, $sqlUpdate . "\n");
                            fclose($manejador);
                        }
                    }

                    $manejador = fopen('Log/' . $item->codZonaVentas . 'VN_INSERT_COORDENADAS.txt', 'a+');
                    fputs($manejador, $sql . "\n");
                    fclose($manejador);
                } else {
                    $manejador = fopen('Log/' . $item->codZonaVentas . 'Warning.txt', 'a+');
                    fputs($manejador, "No se pudo insertar datos duplicados: " . $sql_detalles . "\n");
                    fclose($manejador);
                    return "Error";
                }
            }
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
            return "Error";
        }

        return "OK";
    }
}

function planeacionMes($value) {
    if ($value['value'] == 'INSERT_PLANEACION') {
        $db = Db::getInstance();

        $datos = json_decode(utf8_decode($value['datos']));
        $imei = $value['Imei'];
        $idSim = $value['IdSim'];
        $numeroCuenta = $value['NumeroCuenta'];
        $version = $value['Version'];

        $manejador = fopen('Log/VN_PLANEACION_MES.txt', 'a+');
        fputs($manejador, $value['datos'] . "\n");
        fputs($manejador, "Imei:" . $imei . "  IdSim: " . $idSim . "   NumeroCuenta:  " . $numeroCuenta . "     Version: " . $version . "\n");
        fclose($manejador);

        try {

            $idPlaneacionArray = array();
            $contador = 0;

            foreach ($datos->PlaneacionMes as $item) {
//IdPlaneacionMesDetalle
//IdPlaneacionMes
//Mes
//Ano
//CuentaCliente
//Valor
//Estado
//identificacion
//codasesor
//codZonaVentas

                if ($item->IdPlaneacionMes == 0) {
                    $sqlId = "SELECT COUNT(1) AS Conteo FROM `planeacionmes` WHERE `Mes`='" . $item->Mes . "' AND `CodZonaVentas` ='" . $item->codZonaVentas . "' AND Ano=YEAR(CURDATE()) ; ";
                    $stmtId = $db->ejecutar($sqlId);
                    $resultadoId = $db->obtener_fila($stmtId, 0);
                    $conteo = $resultadoId['Conteo'];

                    if ($conteo == 0) {
                        $sql = "INSERT INTO `planeacionmes`(`CodZonaVentas`, `CodAsesor`, `Mes`, `Ano`, `ValorPlaneacion`, `FechaRegistro`, `HoraRegistro`) VALUES ('" . $item->codZonaVentas . "','" . $item->codasesor . "','" . $item->Mes . "',YEAR(CURDATE()),'0',CURDATE(),CURTIME());";
                        $db->ejecutar($sql);

                        $idPlaneacion = $db->lastID();

                        array_push($idPlaneacionArray, $item->IdPlaneacionMes);

                        $sqlId = "SELECT COUNT(1) AS Conteo FROM `planeacionmesdetalle` WHERE `IdPlaneacionMes`='" . $idPlaneacion . "' AND `CuentaCliente` ='" . $item->CuentaCliente . "'; ";
                        $stmtId = $db->ejecutar($sqlId);
                        $resultadoId = $db->obtener_fila($stmtId, 0);
                        $conteo = $resultadoId['Conteo'];
                        if ($conteo == 0) {
                            $sql = "INSERT INTO `planeacionmesdetalle`(`IdPlaneacionMes`, `CuentaCliente`, `Valor`, `Fecha`, `Hora`) VALUES ('" . $idPlaneacion . "','" . $item->CuentaCliente . "','" . $item->Valor . "',CURDATE(),CURTIME());";
                            $db->ejecutar($sql);
                            $manejador = fopen('Log/' . $item->codZonaVentas . 'VN_PLANEACION_DETALLE_INSERT.txt', 'a+');
                            fputs($manejador, $sql . "\n");
                            fclose($manejador);
                        } else {
                            $sql = "UPDATE `planeacionmesdetalle` SET `Valor`='" . $item->Valor . "',`Fecha`=CURDATE(),`Hora`= CURTIME() WHERE `IdPlaneacionMes`='" . $idPlaneacion . "' AND `CuentaCliente` ='" . $item->CuentaCliente . "';";
                            $db->ejecutar($sql);
                            $manejador = fopen('Log/' . $item->codZonaVentas . 'VN_PLANEACION_DETALLE_UPDATE.txt', 'a+');
                            fputs($manejador, $sql . "\n");
                            fclose($manejador);
                        }
                    } else {
                        $sqlEE = "SELECT IdPlaneacionMes FROM `planeacionmes` WHERE `Mes`='" . $item->Mes . "' AND `CodZonaVentas` ='" . $item->codZonaVentas . "' AND Ano=YEAR(CURDATE()) ; ";
                        $stRed = $db->ejecutar($sqlEE);
                        $resultadFRD = $db->obtener_fila($stRed, 0);
                        $idPlaneacion = $resultadFRD['IdPlaneacionMes'];


                        array_push($idPlaneacionArray, $item->IdPlaneacionMes);

                        $sqlId = "SELECT COUNT(1) AS Conteo FROM `planeacionmesdetalle` WHERE `IdPlaneacionMes`='" . $idPlaneacion . "' AND `CuentaCliente` ='" . $item->CuentaCliente . "'; ";
                        $stmtId = $db->ejecutar($sqlId);
                        $resultadoId = $db->obtener_fila($stmtId, 0);
                        $conteo = $resultadoId['Conteo'];
                        if ($conteo == 0) {
                            $sql = "INSERT INTO `planeacionmesdetalle`(`IdPlaneacionMes`, `CuentaCliente`, `Valor`, `Fecha`, `Hora`) VALUES ('" . $idPlaneacion . "','" . $item->CuentaCliente . "','" . $item->Valor . "',CURDATE(),CURTIME());";
                            $db->ejecutar($sql);
                            $manejador = fopen('Log/' . $item->codZonaVentas . 'VN_PLANEACION_DETALLE_INSERT.txt', 'a+');
                            fputs($manejador, $sql . "\n");
                            fclose($manejador);
                        } else {
                            $sql = "UPDATE `planeacionmesdetalle` SET `Valor`='" . $item->Valor . "',`Fecha`=CURDATE(),`Hora`= CURTIME() WHERE `IdPlaneacionMes`='" . $idPlaneacion . "' AND `CuentaCliente` ='" . $item->CuentaCliente . "';";
                            $db->ejecutar($sql);
                            $manejador = fopen('Log/' . $item->codZonaVentas . 'VN_PLANEACION_DETALLE_UPDATE.txt', 'a+');
                            fputs($manejador, $sql . "\n");
                            fclose($manejador);
                        }
                    }
                } else {
                    array_push($idPlaneacionArray, $item->IdPlaneacionMes);
                    $sqlId = "SELECT COUNT(1) AS Conteo FROM `planeacionmesdetalle` WHERE `IdPlaneacionMes`='" . $item->IdPlaneacionMes . "' AND `CuentaCliente` ='" . $item->CuentaCliente . "'; ";
                    $stmtId = $db->ejecutar($sqlId);
                    $resultadoId = $db->obtener_fila($stmtId, 0);
                    $conteo = $resultadoId['Conteo'];
                    if ($conteo == 0) {
                        $sql = "INSERT INTO `planeacionmesdetalle`(`IdPlaneacionMes`, `CuentaCliente`, `Valor`, `Fecha`, `Hora`) VALUES ('" . $item->IdPlaneacionMes . "','" . $item->CuentaCliente . "','" . $item->Valor . "',CURDATE(),CURTIME());";
                        $db->ejecutar($sql);
                        $manejador = fopen('Log/' . $item->codZonaVentas . 'VN_PLANEACION_DETALLE_INSERT.txt', 'a+');
                        fputs($manejador, $sql . "\n");
                        fclose($manejador);
                    } else {
                        $sql = "UPDATE `planeacionmesdetalle` SET `Valor`='" . $item->Valor . "',`Fecha`=CURDATE(),`Hora`= CURTIME() WHERE `IdPlaneacionMes`='" . $item->IdPlaneacionMes . "' AND `CuentaCliente` ='" . $item->CuentaCliente . "';";
                        $db->ejecutar($sql);
                        $manejador = fopen('Log/' . $item->codZonaVentas . 'VN_PLANEACION_DETALLE_UPDATE.txt', 'a+');
                        fputs($manejador, $sql . "\n");
                        fclose($manejador);
                    }
                }
                $contador++;
            }

            $idPlaneacionArray = array_unique($idPlaneacionArray);

            foreach ($idPlaneacionArray as $id) {
                try {
                    $sqProce = "CALL pcPlaneacionMes01(" . $id . "); ";
                    $db->ejecutar($sqProce);
                } catch (Exception $ex) {
                    $manejador = fopen('Log/Warning.txt', 'a+');
                    fputs($manejador, $ex->getMessage() . "\n");
                    fclose($manejador);
                    return "Error";
                }
            }
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
            return "Error";
        }
        return "OK";
    }
}

function planeacionDia($value) {
    if ($value['value'] == 'INSERT_PLANEACION_DIA') {
        $db = Db::getInstance();

        $datos = json_decode(utf8_decode($value['datos']));
        $imei = $value['Imei'];
        $idSim = $value['IdSim'];
        $numeroCuenta = $value['NumeroCuenta'];
        $version = $value['Version'];

        $manejador = fopen('Log/VN_PLANEACION_DIA.txt', 'a+');
        fputs($manejador, $value['datos'] . "\n");
        fputs($manejador, "Imei:" . $imei . "  IdSim: " . $idSim . "   NumeroCuenta:  " . $numeroCuenta . "     Version: " . $version . "\n");
        fclose($manejador);

        try {

            foreach ($datos->PlaneacionDia as $item) {
//cedula_cliente
//id_producto
//valor
//estado
//identificacion
//codasesor
//codZonaVentas

                $sqlId = "SELECT COUNT(1) AS Conteo FROM `planeaciondia` WHERE `Fecha`=CURDATE() AND `CodZonaVentas` ='" . $item->codZonaVentas . "' AND CuentaCliente='" . $item->cedula_cliente . "' AND CodigoVariante='" . $item->id_producto . "'; ";
                $stmtId = $db->ejecutar($sqlId);
                $resultadoId = $db->obtener_fila($stmtId, 0);
                $conteo = $resultadoId['Conteo'];

                $sql = "INSERT INTO `planeaciondia`(`CodZonaVentas`, `CodAsesor`, `CuentaCliente`, `CodigoVariante`, `Cantidad`, `Fecha`, `Hora`) VALUES ('" . $item->codZonaVentas . "','" . $item->codasesor . "','" . $item->cedula_cliente . "','" . $item->id_producto . "','" . $item->valor . "',CURDATE(),CURTIME());";
                if ($conteo == 0) {
                    $db->ejecutar($sql);
                    $manejador = fopen('Log/' . $item->codZonaVentas . 'INSERT_PLANEACION_DIA.txt', 'a+');
                    fputs($manejador, $sql . "\n");
                    fclose($manejador);

                    $idPlaneacion = $db->lastID();
                } else {
                    $manejador = fopen('Log/Warning.txt', 'a+');
                    fputs($manejador, "Duplicate: " . $sql . "\n");
                    fclose($manejador);
                    return "Error";
                }
            }
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
            return "Error";
        }

        return "OK";
    }
}

function planeacionSmart($value) {
    if ($value['value'] == 'INSERT_PLANEACION_SMART') {
        $db = Db::getInstance();

        $datos = json_decode(utf8_decode($value['datos']));
        $imei = $value['Imei'];
        $idSim = $value['IdSim'];
        $numeroCuenta = $value['NumeroCuenta'];
        $version = $value['Version'];

        $manejador = fopen('Log/VN_PLANEACION_SMART.txt', 'a+');
        fputs($manejador, $value['datos'] . "\n");
        fputs($manejador, "Imei:" . $imei . "  IdSim: " . $idSim . "   NumeroCuenta:  " . $numeroCuenta . "     Version: " . $version . "\n");
        fclose($manejador);

        try {

            $idPlaneacionSmart = "0";
            foreach ($datos->PlaneacionSmart as $item) {
//IdPlaneacion
//CuentaCliente
//Objetivo
//FechaInicio
//FechaFin
//Cumplio
//MotivoNoCumplio
//Estado
//EstadoRevision
//Tipo
//identificacion
//codasesor
//codZonaVentas

                if ($item->Tipo == "UPDATE") {
                    $sql = "UPDATE `planeacionsmart` SET `Activas`='0' WHERE  VALUES IdPlaneacion='" . $item->IdPlaneacion . "'; ";
                    $db->ejecutar($sql);
                }

                $sqlId = "SELECT COUNT(1) AS conteo FROM `planeacionsmart` WHERE `CodZonaVentas`='" . $item->codZonaVentas . "' AND `CuentaCliente`='" . $item->cedula_cliente . "' AND `FechaRegistro`=CURDATE() AND `Objetivo`='" . $item->Objetivo . "'; ";
                $stmtId = $db->ejecutar($sqlId);
                $resultadoId = $db->obtener_fila($stmtId, 0);
                $conteo = $resultadoId['conteo'];

                $sql = "INSERT INTO `planeacionsmart` (`CodZonaVentas`, `CodAsesor`, `CuentaCliente`, `Objetivo`, `FechaRegistro`, `HoraRegistro`, `Activas`, `FechaInicio`, `FechaFin`, `Cumplio`, `MotivoNoCumplimiento`) VALUES ('" . $item->codZonaVentas . "','" . $item->codasesor . "','" . $item->CuentaCliente . "','" . $item->Objetivo . "',CURDATE(),CURTIME(),'1','" . $item->FechaInicio . "','" . $item->FechaFin . "','0','');";
                if ($conteo == 0) {
                    $db->ejecutar($sql);
                    $idPlaneacionSmart = $db->lastID();

                    $manejador = fopen('Log/' . $item->codZonaVentas . 'INSERT_PLANEACION_SMART.txt', 'a+');
                    fputs($manejador, $sql . "\n");
                    fclose($manejador);
                } else {
                    $manejador = fopen('Log/Warning.txt', 'a+');
                    fputs($manejador, "Duplicate: " . $sql . "\n");
                    fclose($manejador);
                    return "Error";
                }
            }
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
            return "Error";
        }
        return $idPlaneacionSmart;
    }
}

function terminarRutaServer($value) {
    $db = Db::getInstance();

    if ($value['value'] == 'TerminarRuta') {
        $pedido = $value['pedido'];
        $novisita = $value['novisita'];
        $devolucion = $value['devolucion'];
        $cliente_nuevo = $value['cliente_nuevo'];
        $recaudos = $value['recaudos'];
        $consignacion = $value['consignacion'];
        $zonaVentas = $value['zonaVentas'];

        $contador_pedidos = 0;
        $contador_novisita = 0;
        $contador_devolucion = 0;
        $contador_cliente_nuevo = 0;
        $contador_recaudod = 0;
        $contador_consig_vendedor = 0;

        $sql2 = "SELECT COUNT(IdPedido) AS cuantospedidos FROM pedidos WHERE IdentificadorEnvio='0' AND CodZonaVentas='" . $zonaVentas . "';";
        $stmt2 = $db->ejecutar($sql2);
        $resultado2 = $db->obtener_fila($stmt2, 0);
        $contador_pedidos = $resultado2['cuantospedidos'];

        $sql4 = "SELECT COUNT(*) AS cuantos FROM noventas WHERE IdentificadorEnvio='0' AND  CodZonaVentas='" . $zonaVentas . "';";
        $stmt4 = $db->ejecutar($sql4);
        $resultado4 = $db->obtener_fila($stmt4, 0);
        $contador_novisita = $resultado4['cuantos'];

        $sql5 = "SELECT COUNT(IdDevolucion) AS cuantos FROM devoluciones WHERE IdentificadorEnvio='0' AND CodZonaVentas='" . $zonaVentas . "';";
        $stmt5 = $db->ejecutar($sql5);
        $resultado5 = $db->obtener_fila($stmt5, 0);
        $contador_devolucion = $resultado5['cuantos'];

        $sql7 = "SELECT COUNT(Id) AS cuantos FROM clientenuevo WHERE IdentificadorEnvio='0' AND CodZonaVentas='" . $zonaVentas . "';";
        $stmt7 = $db->ejecutar($sql7);
        $resultado7 = $db->obtener_fila($stmt7, 0);
        $contador_cliente_nuevo = $resultado7['cuantos'];

        $sql22 = "SELECT COUNT(Id) AS cuantos FROM reciboscaja WHERE IdentificadorEnvio='0' AND ZonaVenta='" . $zonaVentas . "';";
        $stmt22 = $db->ejecutar($sql22);
        $resultado22 = $db->obtener_fila($stmt22, 0);
        $contador_recaudod = $resultado22['cuantos'];

        $sql33 = "SELECT COUNT(IdConsignacion) AS cuantos FROM consignacionesvendedor WHERE IdentificadorEnvio='0' AND  CodZonaVentas='" . $zonaVentas . "';";
        $stmt33 = $db->ejecutar($sql33);
        $resultado33 = $db->obtener_fila($stmt33, 0);
        $contador_consig_vendedor = $resultado33['cuantos'];

///////////////////////////////////

        $manejador = fopen('Log/' . $zonaVentas . 'FINAL.txt', 'a+');
        fputs($manejador, "Fecha: " . date("Y-m-d H:i:s") . "\n");
        fputs($manejador, "# PEDIDOS: " . $pedido . " ---> contador: " . $contador_pedidos . "\n");
        fputs($manejador, "# NO VISITA: " . $novisita . " ---> contador: " . $contador_novisita . "\n");
        fputs($manejador, "# DEVOLUCIONES: " . $devolucion . " ---> contador: " . $contador_devolucion . "\n");
        fputs($manejador, "# CLIENTES NUEVOS: " . $cliente_nuevo . " ---> contador: " . $contador_cliente_nuevo . "\n");
        fputs($manejador, "# RECAUDOS: " . $recaudos . " ---> contador: " . $contador_recaudod . "\n");
        fputs($manejador, "# CONSIGANCIONES: " . $consignacion . " ---> contador: " . $contador_consig_vendedor . "\n");
        fputs($manejador, "VENDEDOR: " . $zonaVentas . "\n");
        fclose($manejador);


        $horaActual = date('H:i:s');
        $nuevaHora = strtotime('+5 second', strtotime($horaActual));
        $nuevaHora = date('H:i:s', $nuevaHora);

        $sqlMensajes = "SELECT COUNT(*) AS count FROM `mensajes` WHERE IdRemitente='" . $zonaVentas . "' AND FechaMensaje=CURDATE() AND HoraMensaje>(SELECT MAX(HoraMensaje) FROM mensajes WHERE IdRemitente='" . $zonaVentas . "' AND FechaMensaje=CURDATE()) AND HoraMensaje<'" . $nuevaHora . "' ORDER BY HoraMensaje DESC LIMIT 1; ";
        $stmtMensajes = $db->ejecutar($sqlMensajes);
        $resultadoMe = $db->obtener_fila($stmtMensajes, 0);
        $count_hora_mensaje = $resultadoMe['count'];


        if ($contador_pedidos == $pedido) {
            if ($contador_devolucion == $devolucion) {
                if ($contador_cliente_nuevo == $cliente_nuevo) {
                    if ($contador_recaudod == $recaudos) {
                        if ($contador_consig_vendedor == $consignacion) {

                            $manejador = fopen('Log/' . $zonaVentas . 'FINAL.txt', 'a+');
                            fputs($manejador, "RESPUESTA: " . "OK" . "\n");
                            fclose($manejador);

                            if ($count_hora_mensaje > 0) {
                                return "NO";
                            } else {

                                $sqlPedido = "UPDATE `pedidos` SET IdentificadorEnvio='1',FechaTerminacion = CURDATE(),HoraTerminacion = CURTIME() WHERE IdentificadorEnvio='0' AND CodZonaVentas='" . $zonaVentas . "'; ";
                                $db->ejecutar($sqlPedido);
                                $sqlNoventa = "UPDATE `noventas` SET IdentificadorEnvio='1' WHERE IdentificadorEnvio='0' AND CodZonaVentas='" . $zonaVentas . "'; ";
                                $db->ejecutar($sqlNoventa);
                                $sqltransferenciaautoventa = "UPDATE `transferenciaautoventa` SET IdentificadorEnvio='1',FechaTerminacion=CURDATE(),HoraTerminacion = CURTIME() WHERE IdentificadorEnvio='0' AND CodZonaVentas='" . $zonaVentas . "'; ";
                                $db->ejecutar($sqltransferenciaautoventa);
                                $sqlDevoluciones = "UPDATE `devoluciones` SET IdentificadorEnvio='1' WHERE IdentificadorEnvio='0' AND CodZonaVentas='" . $zonaVentas . "'; ";
                                $db->ejecutar($sqlDevoluciones);
                                $sqlClienteNew = "UPDATE `clientenuevo` SET IdentificadorEnvio='1' WHERE IdentificadorEnvio='0' AND CodZonaVentas='" . $zonaVentas . "'; ";
                                $db->ejecutar($sqlClienteNew);
                                $sqlRecibo = "UPDATE `reciboscaja` SET IdentificadorEnvio='1' WHERE IdentificadorEnvio='0' AND ZonaVenta='" . $zonaVentas . "'; ";
                                $db->ejecutar($sqlRecibo);
                                $sqlConsignacion = "UPDATE `consignacionesvendedor` SET IdentificadorEnvio='1' WHERE IdentificadorEnvio='0' AND CodZonaVentas='" . $zonaVentas . "'; ";
                                $db->ejecutar($sqlConsignacion);

                                return "OK";
                            }
                        } else {
                            $contado_correo = $contado_correo + 1;
                        }
                    } else {
                        $contado_correo = $contado_correo + 1;
                    }
                } else {
                    $contado_correo = $contado_correo + 1;
                }
            } else {
                $contado_correo = $contado_correo + 1;
            }
        } else {
            $contado_correo = $contado_correo + 1;
        }

        if ($contado_correo > 0) {

            $nombre_serer = $_SERVER["SERVER_NAME"];

            $cuerpo = '';
            $cuerpo = $cuerpo . '
	<html>
	<head>
	<title>Correo</title>
	</head>
	<body>			
	<div>
	<table border="0" cellpadding="0" cellspacing="0" width="700">
	<TR><td>PROBLEMA PARA TERMINAR RUTA</td></TR>
	<TR><td>Zona ventas: ' . $zonaVentas . '</td></TR>
	<TR><td colspan="4">Se tiene problema en la terminacion de ruta en el sitio:' . $nombre_serer . '  . </td></TR>
	<TR><td>&nbsp;</td></TR>
	</table>
	</div>
	</body>
	</html>';

            $contacto = "soporte@activity.com.co";

            $nombresitio = "PROBLEMA PARA TERMINAR RUTA";

            $headers = "MIME-Version: 1.0\r\n";
            $headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
            $headers .= "From: ACTIVITY <lgarcia@activity.com.co>\r\n";

//      mail($contacto, "$nombresitio", $cuerpo, $headers);

            return "NO";
        }
    }
}

/**
 * Metodos para funcionamiento interno y validaciones.
 */
function transacciones($id, $modulo) {

    try {
        $db = Db::getInstance();

        $sqProce = "SELECT fcTransacciones01(" . $id . "," . $modulo . "); ";
        $db->ejecutar($sqProce);
        return "OK";
    } catch (Exception $e) {
        $manejador = fopen('Log/WarningTransaccionAx.txt', 'a+');
        fputs($manejador, $e->getMessage() . "\n");
        fclose($manejador);
        return "Error";
    }
}

function jsonDecode($datos) {
    $array = json_decode($datos);
    return $array;
}

function envioCorreoDescuentoEspecial($idPedido) {
    $db = Db::getInstance();

    $sqlAgencia = "SELECT CodAgencia,Nombre FROM agencia;";
    $stAgencia = $db->ejecutar($sqlAgencia);
    $resulAgencia = $db->obtener_fila($stAgencia, 0);
    $agencia = $resulAgencia['CodAgencia'];
    $nombreAgencia = $resulAgencia['Nombre'];

    // Altipal
    $sql = "SELECT p.IdPedido,p.CodZonaVentas,p.CuentaCliente,p.CodGrupoVenta FROM `pedidos` AS p INNER JOIN descripcionpedido AS dp ON p.IdPedido = dp.IdPedido WHERE p.IdPedido ='" . $idPedido . "' AND dp.DsctoEspecial>0 AND dp.DsctoEspecialAltipal>0 GROUP BY p.IdPedido;";
    $stmt = $db->ejecutar($sql);
    $resultado = $db->obtener_fila($stmt, 0);
    $CodGrupoVenta = $resultado['CodGrupoVenta'];

    $clientCanal = new nusoap_client("http://altipal.datosmovil.info/SM/WebServiceLogin.php?wsdl");
    $clientCanal->soap_defencoding = 'UTF-8';
    $err = $clientCanal->getError();
    if ($err) {
        echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
        echo '<h2>Debug</h2><pre>' . htmlspecialchars($clientCanal->getDebug(), ENT_QUOTES) . '</pre>';
        exit();
    }

    $args = array('value' => 'Especial', 'GrupoVenta' => $CodGrupoVenta, 'Proveedor' => '', 'Agencia' => $agencia, 'NombreAgencia' => $nombreAgencia);
    $clientCanal->call('correoDescuentoEspecial', array($args));


    // Proveedor
    $sql2 = "SELECT p.IdPedido,p.CodZonaVentas,p.CuentaCliente,p.CodGrupoVenta,dp.CuentaProveedor FROM `pedidos` AS p INNER JOIN descripcionpedido AS dp ON p.IdPedido = dp.IdPedido WHERE p.IdPedido ='" . $idPedido . "' AND dp.DsctoEspecial>0 AND dp.DsctoEspecialProveedor>0 GROUP BY dp.CuentaProveedor;";
    $stmt2 = $db->ejecutar($sql2);
    while ($row = $db->obtener_fila($stmt2, 0)) {
        $CodGrupoVenta = $row['CodGrupoVenta'];
        $cuentaProveedor = $row['CuentaProveedor'];

        $clientCanal = new nusoap_client("http://altipal.datosmovil.info/SM/WebServiceLogin.php?wsdl");
        $clientCanal->soap_defencoding = 'UTF-8';
        $err = $clientCanal->getError();
        if ($err) {
            echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
            echo '<h2>Debug</h2><pre>' . htmlspecialchars($clientCanal->getDebug(), ENT_QUOTES) . '</pre>';
            exit();
        }

        $args = array('value' => 'Especial', 'GrupoVenta' => $CodGrupoVenta, 'Proveedor' => $cuentaProveedor, 'Agencia' => $agencia, 'NombreAgencia' => $nombreAgencia);
        $clientCanal->call('correoDescuentoEspecial', array($args));
    }
}

function envioCorreoActividadEspecial($idPedido) {
    $db = Db::getInstance();

    $sqlAgencia = "SELECT CodAgencia,Nombre FROM agencia;";
    $stAgencia = $db->ejecutar($sqlAgencia);
    $resulAgencia = $db->obtener_fila($stAgencia, 0);
    $agencia = $resulAgencia['CodAgencia'];
    $nombreAgencia = $resulAgencia['Nombre'];

    // Altipal
    $sql = "SELECT p.IdPedido,p.CodZonaVentas,p.CuentaCliente,p.CodGrupoVenta FROM `pedidos` AS p WHERE p.IdPedido ='" . $idPedido . "' AND p.ActividadEspecial >0 GROUP BY p.IdPedido;";
    $stmt = $db->ejecutar($sql);
    $resultado = $db->obtener_fila($stmt, 0);
    $CodGrupoVenta = $resultado['CodGrupoVenta'];

    $clientCanal = new nusoap_client("http://altipal.datosmovil.info/SM/WebServiceLogin.php?wsdl");
    $clientCanal->soap_defencoding = 'UTF-8';
    $err = $clientCanal->getError();
    if ($err) {
        echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
        echo '<h2>Debug</h2><pre>' . htmlspecialchars($clientCanal->getDebug(), ENT_QUOTES) . '</pre>';
        exit();
    }

    $args = array('value' => 'Actividad', 'GrupoVenta' => $CodGrupoVenta, 'Agencia' => $agencia, 'NombreAgencia' => $nombreAgencia);
    $clientCanal->call('correoActividadEspecial', array($args));
}

function envioCorreoNotasCredito($idNotaCredito) {
    $db = Db::getInstance();

    $sqlAgencia = "SELECT CodAgencia,Nombre FROM agencia;";
    $stAgencia = $db->ejecutar($sqlAgencia);
    $resulAgencia = $db->obtener_fila($stAgencia, 0);
    $agencia = $resulAgencia['CodAgencia'];
    $nombreAgencia = $resulAgencia['Nombre'];

    $sql = "SELECT z.CodigoGrupoVentas,n.Concepto FROM `notascredito` AS n INNER JOIN zonaventas AS z ON n.`CodZonaVentas` = z.CodZonaVentas WHERE n.IdNotaCredito ='" . $idNotaCredito . "';";
    $stmt = $db->ejecutar($sql);
    $resultado = $db->obtener_fila($stmt, 0);
    $CodGrupoVenta = $resultado['CodigoGrupoVentas'];
    $Concepto = $resultado['Concepto'];

    $clientCanal = new nusoap_client("http://altipal.datosmovil.info/SM/WebServiceLogin.php?wsdl");
    $clientCanal->soap_defencoding = 'UTF-8';
    $err = $clientCanal->getError();
    if ($err) {
        echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
        echo '<h2>Debug</h2><pre>' . htmlspecialchars($clientCanal->getDebug(), ENT_QUOTES) . '</pre>';
        exit();
    }

    $args = array('value' => 'Nota', 'GrupoVenta' => $CodGrupoVenta, 'Agencia' => $agencia, 'NombreAgencia' => $nombreAgencia, 'Concepto' => $Concepto);
    $clientCanal->call('correoNotaCredito', array($args));
}

function enviarCorreoTransConsignacion($idTrans) {
    $db = Db::getInstance();

    $sqlAgencia = "SELECT CodAgencia,Nombre FROM agencia;";
    $stAgencia = $db->ejecutar($sqlAgencia);
    $resulAgencia = $db->obtener_fila($stAgencia, 0);
    $agencia = $resulAgencia['CodAgencia'];
    $nombreAgencia = $resulAgencia['Nombre'];

    $sql = "SELECT z.CodigoGrupoVentas FROM `transferenciaconsignacion` AS t INNER JOIN zonaventas AS z ON t.CodZonaVentas = z.CodZonaVentas WHERE t.IdTransferencia = '" . $idTrans . "';";
    $stmt = $db->ejecutar($sql);
    $resultado = $db->obtener_fila($stmt, 0);
    $CodGrupoVenta = $resultado['CodigoGrupoVentas'];

    $clientCanal = new nusoap_client("http://altipal.datosmovil.info/SM/WebServiceLogin.php?wsdl");
    $clientCanal->soap_defencoding = 'UTF-8';
    $err = $clientCanal->getError();
    if ($err) {
        echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
        echo '<h2>Debug</h2><pre>' . htmlspecialchars($clientCanal->getDebug(), ENT_QUOTES) . '</pre>';
        exit();
    }

    $args = array('value' => 'Transferencia', 'GrupoVenta' => $CodGrupoVenta, 'Agencia' => $agencia, 'NombreAgencia' => $nombreAgencia);
    $clientCanal->call('correoTransferenciaConsignacion', array($args));
}

function envioCorreoDevolucion($idDevolucion) {
    $db = Db::getInstance();

    $sqlAgencia = "SELECT CodAgencia,Nombre FROM agencia;";
    $stAgencia = $db->ejecutar($sqlAgencia);
    $resulAgencia = $db->obtener_fila($stAgencia, 0);
    $agencia = $resulAgencia['CodAgencia'];
    $nombreAgencia = $resulAgencia['Nombre'];

    $sql = "SELECT z.CodigoGrupoVentas FROM `devoluciones` AS d INNER JOIN zonaventas AS z ON d.`CodZonaVentas`=z.`CodZonaVentas` WHERE d.`IdDevolucion` ='" . $idDevolucion . "';";
    $stmt = $db->ejecutar($sql);
    $resultado = $db->obtener_fila($stmt, 0);
    $CodGrupoVenta = $resultado['CodigoGrupoVentas'];

    $clientCanal = new nusoap_client("http://altipal.datosmovil.info/SM/WebServiceLogin.php?wsdl");
    $clientCanal->soap_defencoding = 'UTF-8';
    $err = $clientCanal->getError();
    if ($err) {
        echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
        echo '<h2>Debug</h2><pre>' . htmlspecialchars($clientCanal->getDebug(), ENT_QUOTES) . '</pre>';
        exit();
    }

    $args = array('value' => 'Devolucion', 'GrupoVenta' => $CodGrupoVenta, 'Agencia' => $agencia, 'NombreAgencia' => $nombreAgencia);
    $clientCanal->call('correoDevolucion', array($args));
}

function reemplaceCaracteres($string) {
    $string = trim($string);

    $string = str_replace(
            array('á', 'à', 'ä', 'â', 'ª', '�?', 'À', 'Â', 'Ä'), array('a', 'a', 'a', 'a', 'a', 'A', 'A', 'A', 'A'), $string
    );

    $string = str_replace(
            array('é', 'è', 'ë', 'ê', 'É', 'È', 'Ê', 'Ë'), array('e', 'e', 'e', 'e', 'E', 'E', 'E', 'E'), $string
    );

    $string = str_replace(
            array('í', 'ì', 'ï', 'î', '�?', 'Ì', '�?', 'Î'), array('i', 'i', 'i', 'i', 'I', 'I', 'I', 'I'), $string
    );

    $string = str_replace(
            array('ó', 'ò', 'ö', 'ô', 'Ó', 'Ò', 'Ö', 'Ô'), array('o', 'o', 'o', 'o', 'O', 'O', 'O', 'O'), $string
    );

    $string = str_replace(
            array('ú', 'ù', 'ü', 'û', 'Ú', 'Ù', 'Û', 'Ü'), array('u', 'u', 'u', 'u', 'U', 'U', 'U', 'U'), $string
    );

    $string = str_replace(
            array('ñ', 'Ñ', 'ç', 'Ç'), array('n', 'N', 'c', 'C',), $string
    );

    return $string;
}

$HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '';
$server->service($HTTP_RAW_POST_DATA);
?>