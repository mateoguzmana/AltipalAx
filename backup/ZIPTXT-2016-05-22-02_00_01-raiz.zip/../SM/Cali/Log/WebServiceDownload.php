<?php
header('Content-Type: text/html; charset=utf-8');
/*
  Se cambia el modo de acceso a la base de datos por un metodo singleton
 */
/* Incluimos el fichero de la clase Db */
require_once('db/Db.php');
/* Incluimos el fichero de la clase Conf */
require_once('db/Conf.php');
/* Creamos la instancia del objeto. Ya estamos conectados */
$db = Db::getInstance();

/* Al parecer intentan utilizar un sistema SOAP pero no lo he verificado */
require_once('../lib/nusoap.php');
header("Content-Type: text / xml; charset = UTF-8 \ r \ n");
$server = new nusoap_server;

$server->configureWSDL('server', 'urn:server');

$server->wsdl->schemaTargetNamespace = 'urn:server';

$server->soap_defencoding = 'UTF-8';
$server->decode_utf8 = false;

$server->register('pollServer', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('facturasServer', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('consultarClienteNuevo', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('mensajesServer', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('conexionServer', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('transaccionesFactura', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('asesoresRelacion', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('relacionTranfereciaAutoventa', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('downloadExtra', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('verificarFechaActualizacion', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');
$server->register('verificartransferencia', array('value' => 'xsd:string'), array('return' => 'xsd:string'), $domain, $domain . '#pollServer');

/**
 * Metodo de descarga de informacion, actualización de datos.
 * @param String $value
 * @return Json
 * @soap
 */
function pollServer($value) {

if(!is_array($value))
    {
         $datos = $value;
        $value = array();
        $datos = explode(",",$datos);
        $acum;
        foreach($datos as $row):
            $datosPar = explode("=>",$row);
            array_push($value[$datosPar[0]] = $datosPar[1],  $datosPar[1]);
        endforeach;
    }
    
    //Logueo preventa - Autoventa
    if ($value['value'] == 'llenar_logueo') {
        
        $db = Db::getInstance();

        $usuario = trim($value['usuario']);
        $contrasena = trim($value['contrasena']);
        $version = trim($value['version']);

        $respuesta = "NO";
        $nombre = "";

        $sql = "SELECT COUNT(*) AS Conteo FROM `asesorescomerciales` AS a INNER JOIN zonaventas AS z ON a.CodAsesor=z.CodAsesor WHERE z.CodZonaVentas='" . $usuario . "' AND a.Clave='" . $contrasena . "';";
        /* Ejecutamos la query */
        $stmt = $db->ejecutar($sql);
        /* Obtenemos los resultados */
        $resultado = $db->obtener_fila($stmt, 0);
        $prod = $resultado['Conteo'];

        if ($prod > 0) {

            $sqlU = "SELECT a.Nombre,a.NuevaVersion,z.FechaRetiro,z.CodAsesor,ag.Id FROM `asesorescomerciales` AS a INNER JOIN zonaventas AS z ON a.CodAsesor=z.CodAsesor INNER JOIN agencia AS ag ON ag.CodAgencia=a.Agencia WHERE z.CodZonaVentas='" . $usuario . "' AND a.Clave='" . $contrasena . "';";
            $stmtU = $db->ejecutar($sqlU);
            $resultadoU = $db->obtener_fila($stmtU, 0);
            $nueva_version = $resultadoU['NuevaVersion'];
            $nombre = $resultadoU['Nombre'];
            $fechaRetiro = $resultadoU['FechaRetiro'];
            $codigoAsesor = $resultadoU['CodAsesor'];
            $agencia = $resultadoU['Id'];
            $identificacion = '';

            /*             * ******* * */
            $client = new nusoap_client("http://altipal.datosmovil.info/SM/WebServiceLogin.php?wsdl");
            $client->soap_defencoding = 'UTF-8';
            $err = $client->getError(); /*             * *Captura de errores** */
            if ($err) {
                echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
                echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->getDebug(), ENT_QUOTES) . '</pre>';
                exit();
            }

            $args = array('value' => 'Jerarquia', 'identificacion' => $codigoAsesor);
            $return = $client->call('pollServer', array($args));

            $respuestaJerar = "0";
            $nombreJera = "";
            $datos = json_decode($return);
            foreach ($datos->Jerarquia as $item) {
                $respuestaJerar = $item->respuesta;
                $nombreJera = $item->nombre;
            }
            /*             * ************** */

            if ($respuestaJerar > 0) {

                if (empty($nueva_version)) {
                    $sqlVe = "SELECT MAX(NuevaVersion) AS max FROM `asesorescomerciales`";
                    $stmtVe = $db->ejecutar($sqlVe);
                    $resultadoVe = $db->obtener_fila($stmtVe, 0);
                    $max_version = $resultadoVe['max'];
                    $nueva_version = '0';
                    if (empty($max_version)) {
                        $max_version = '0';
                    }

                    $sql = "UPDATE `asesorescomerciales` SET `NuevaVersion`='" . $max_version . "' WHERE CodAsesor='" . $codigoAsesor . "' AND Clave='" . $contrasena . "'; ";
                    $stmt = $db->ejecutar($sql);
                }

                if ($nueva_version > $version) {
                    $respuesta = "ACTUALIZA";
                } else {
                    $sqlAd = "UPDATE `asesorescomerciales` SET `Version`='" . $version . "',`FechaVersion`= CURDATE(),`HoraVersion`= CURTIME() WHERE CodAsesor='" . $codigoAsesor . "' AND Clave='" . $contrasena . "';";
                    $db->ejecutar($sqlAd);

                    if (($fechaRetiro == '') || ($fechaRetiro == '0000-00-00')) {
                        $respuesta = "OK";
                    } else {
                        $respuesta = "Identificate";
                    }
                }
            } else {
                $sqlZona = "SELECT COUNT(*) AS Conteo FROM zonaventas  WHERE CodZonaVentas='" . $usuario . ";";
                /* Ejecutamos la query */
                $stmtZona = $db->ejecutar($sqlZona);
                /* Obtenemos los resultados */
                $resultadoZona = $db->obtener_fila($stmtZona, 0);
                $prodZona = $resultadoZona['Conteo'];

                if ($prodZona > 0) {
                    $respuesta = "NO";
                    $nombre = "N/A";
                } else {
                    $respuesta = "NN";
                    $nombre = "N/A";
                }
            }
        } else {
            $sqlZona = "SELECT COUNT(*) AS Conteo FROM zonaventas  WHERE CodZonaVentas='" . $usuario . ";";
            /* Ejecutamos la query */
            $stmtZona = $db->ejecutar($sqlZona);
            /* Obtenemos los resultados */
            $resultadoZona = $db->obtener_fila($stmtZona, 0);
            $prodZona = $resultadoZona['Conteo'];

            if ($prodZona > 0) {
                $respuesta = "NO";
                $nombre = "N/A";
            } else {
                $respuesta = "NN";
                $nombre = "N/A";
            }
        }

        $json = array(
            'respuesta' => $respuesta,
            'cedula' => $usuario,
            'nombre' => $nombre,
            'contrasena' => $contrasena,
            'identificacion' => $identificacion,
            'agencia' => $agencia
        );

        $datos = array();
        array_push($datos, $json);
        $subArray = array('Login' => $datos);
        return json_encode($subArray);
    }


    //Logueo Focalizados
    if ($value['value'] == 'llenar_logueoFocalizados') {
        $db = Db::getInstance();

        $usuario = trim($value['usuario']);
        $contrasena = trim($value['contrasena']);
        $version = trim($value['version']);

        $respuesta = "NO";
        $nombre = "";

        $sql = "SELECT COUNT(*) AS Conteo FROM `asesorescomerciales` AS a INNER JOIN zonaventas AS z ON a.CodAsesor=z.CodAsesor INNER JOIN zonaventaalmacen AS za ON za.CodZonaVentas = z.CodZonaVentas WHERE z.CodZonaVentas='" . $usuario . "' AND a.Clave='" . $contrasena . "' AND za.Focalizado = 'verdadero';";
        /* Ejecutamos la query */
        $stmt = $db->ejecutar($sql);
        /* Obtenemos los resultados */
        $resultado = $db->obtener_fila($stmt, 0);
        $prod = $resultado['Conteo'];

        if ($prod > 0) {

            $sqlU = "SELECT a.Nombre,a.NuevaVersion,z.FechaRetiro,z.CodAsesor,ag.Id FROM `asesorescomerciales` AS a INNER JOIN zonaventas AS z ON a.CodAsesor=z.CodAsesor INNER JOIN agencia AS ag ON ag.CodAgencia=a.Agencia WHERE z.CodZonaVentas='" . $usuario . "' AND a.Clave='" . $contrasena . "';";
            $stmtU = $db->ejecutar($sqlU);
            $resultadoU = $db->obtener_fila($stmtU, 0);
            $nueva_version = $resultadoU['NuevaVersion'];
            $nombre = $resultadoU['Nombre'];
            $fechaRetiro = $resultadoU['FechaRetiro'];
            $codigoAsesor = $resultadoU['CodAsesor'];
            $agencia = $resultadoU['Id'];
            $identificacion = '';

            /*             * ******* * */
            $client = new nusoap_client("http://altipal.datosmovil.info/SM/WebServiceLogin.php?wsdl");
            $client->soap_defencoding = 'UTF-8';
            $err = $client->getError(); /*             * *Captura de errores** */
            if ($err) {
                echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
                echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->getDebug(), ENT_QUOTES) . '</pre>';
                exit();
            }

            $args = array('value' => 'Jerarquia', 'identificacion' => $codigoAsesor);
            $return = $client->call('pollServer', array($args));

            $respuestaJerar = "0";
            $nombreJera = "";
            $datos = json_decode($return);
            foreach ($datos->Jerarquia as $item) {
                $respuestaJerar = $item->respuesta;
                $nombreJera = $item->nombre;
            }
            /*             * ************** */

            if ($respuestaJerar > 0) {

                if (empty($nueva_version)) {
                    $sqlVe = "SELECT MAX(NuevaVersion) AS max FROM `asesorescomerciales`";
                    $stmtVe = $db->ejecutar($sqlVe);
                    $resultadoVe = $db->obtener_fila($stmtVe, 0);
                    $max_version = $resultadoVe['max'];
                    $nueva_version = '0';
                    if (empty($max_version)) {
                        $max_version = '0';
                    }

                    $sql = "UPDATE `asesorescomerciales` SET `NuevaVersion`='" . $max_version . "' WHERE CodAsesor='" . $codigoAsesor . "' AND Clave='" . $contrasena . "'; ";
                    $stmt = $db->ejecutar($sql);
                }

                if ($nueva_version > $version) {
                    $respuesta = "ACTUALIZA";
                } else {
                    $sqlAd = "UPDATE `asesorescomerciales` SET `Version`='" . $version . "',`FechaVersion`= CURDATE(),`HoraVersion`= CURTIME() WHERE CodAsesor='" . $codigoAsesor . "' AND Clave='" . $contrasena . "';";
                    $db->ejecutar($sqlAd);

                    if (($fechaRetiro == '') || ($fechaRetiro == '0000-00-00')) {
                        $respuesta = "OK";
                    } else {
                        $respuesta = "Identificate";
                    }
                }
            } else {
                $sqlZona = "SELECT COUNT(*) AS Conteo FROM zonaventas  WHERE CodZonaVentas='" . $usuario . ";";
                /* Ejecutamos la query */
                $stmtZona = $db->ejecutar($sqlZona);
                /* Obtenemos los resultados */
                $resultadoZona = $db->obtener_fila($stmtZona, 0);
                $prodZona = $resultadoZona['Conteo'];

                if ($prodZona > 0) {
                    $respuesta = "NO";
                    $nombre = "N/A";
                } else {
                    $respuesta = "NN";
                    $nombre = "N/A";
                }
            }
        } else {
            $sqlZona = "SELECT COUNT(*) AS Conteo FROM zonaventas  WHERE CodZonaVentas='" . $usuario . ";";
            /* Ejecutamos la query */
            $stmtZona = $db->ejecutar($sqlZona);
            /* Obtenemos los resultados */
            $resultadoZona = $db->obtener_fila($stmtZona, 0);
            $prodZona = $resultadoZona['Conteo'];

            if ($prodZona > 0) {
                $respuesta = "NO";
                $nombre = "N/A";
            } else {
                $respuesta = "NN";
                $nombre = "N/A";
            }
        }

        $json = array(
            'respuesta' => $respuesta,
            'cedula' => $usuario,
            'nombre' => $nombre,
            'contrasena' => $contrasena,
            'identificacion' => $identificacion,
            'agencia' => $agencia
        );

        $datos = array();
        array_push($datos, $json);
        $subArray = array('Login' => $datos);
        return json_encode($subArray);
    }


    if ($value['value'] == 'IDENTIFICAR') {
        $db = Db::getInstance();

        $identificacion = trim($value['identificacion']);
        $usuario = trim($value['usuario']);
        $contrasena = trim($value['contrasena']);

        $respuesta = "NO";
        $nombre = "";

        /*         * ******* * */
        $client = new nusoap_client("http://altipal.datosmovil.info/SM/WebServiceLogin.php?wsdl");
        $client->soap_defencoding = 'UTF-8';
        $err = $client->getError(); /*         * *Captura de errores** */
        if ($err) {
            echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
            echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->getDebug(), ENT_QUOTES) . '</pre>';
            exit();
        }

        $args = array('value' => 'Jerarquia', 'identificacion' => $identificacion);
        $return = $client->call('pollServer', array($args));

        $respuestaJerar = "0";
        $nombreJera = "";
        $datos = json_decode($return);
        foreach ($datos->Jerarquia as $item) {
            $respuestaJerar = $item->respuesta;
            $nombreJera = $item->nombre;
        }
        /*         * ************** */

        if ($respuestaJerar > 0) {

            $nombre = $nombreJera;

            $sqlG = "SELECT ag.Id FROM `zonaventas` AS z INNER JOIN asesorescomerciales AS a ON z.CodAsesor=a.CodAsesor INNER JOIN agencia AS ag ON ag.CodAgencia=a.Agencia WHERE z.CodZonaVentas='" . $usuario . "'; ";
            $stmtG = $db->ejecutar($sqlG);
            $resultadoG = $db->obtener_fila($stmtG, 0);
            $agencia = $resultadoG['Id'];

            $respuesta = "OK";
        } else {
            $respuesta = "NO";
            $nombre = "N/A";
        }

        $json = array(
            'respuesta' => $respuesta,
            'cedula' => $usuario,
            'nombre' => $nombre,
            'contrasena' => $contrasena,
            'identificacion' => $identificacion,
            'agencia' => $agencia
        );

        $datos = array();
        array_push($datos, $json);
        $subArray = array('Login' => $datos);
        return json_encode($subArray);
    }


    if ($value['value'] == 'LLENAR_DESCARGA') {
        $db = Db::getInstance();
        $usuario = trim($value['datos']);

        //USUARIO
        $datosUsuario = array();
        $sql = "SELECT a.CodAsesor,a.Cedula,a.Clave,a.Nombre,a.Telefono,a.TelefonoMovilPersonal,a.TelefonoMovilEmpresarial,a.CorreoElectronico,a.Direccion,a.Imagen,a.InfoActivity,z.CodZonaVentas,z.NombreZonadeVentas,z.CodigoGrupoVentas, z.Transferencia 
                    FROM `asesorescomerciales` AS a 
                    INNER JOIN zonaventas AS z ON a.CodAsesor=z.CodAsesor 
                    WHERE z.CodZonaVentas='" . $usuario . "'; ";
        $rs_cltes = $db->ejecutar($sql);
        if ($rs_cltes) {
            while ($col_cltes = $db->obtener_fila($rs_cltes, 0)) {
                $json = array(
                    'cod_asesor' => $col_cltes['CodAsesor'],
                    'cedula' => $col_cltes['Cedula'],
                    'clave' => $col_cltes['Clave'],
                    'nombre' => $col_cltes['Nombre'],
                    'telefono' => $col_cltes['Telefono'],
                    'telefono_movil_personal' => $col_cltes['TelefonoMovilPersonal'],
                    'telefono_movil_empresarial' => $col_cltes['TelefonoMovilEmpresarial'],
                    'email' => $col_cltes['CorreoElectronico'],
                    'direccion' => $col_cltes['Direccion'],
                    'imagen' => $col_cltes['Imagen'],
                    'transferencia' => trim(strtoupper($col_cltes['Transferencia'])),
                    'info_activity' => $col_cltes['InfoActivity'],
                    'cod_zona_ventas' => $col_cltes['CodZonaVentas'],
                    'nombre_zona_ventas' => $col_cltes['NombreZonadeVentas'],
                    'codigo_grupo_ventas' => $col_cltes['CodigoGrupoVentas']
                );
                array_push($datosUsuario, $json);
            }
        }


        //Grupo ventas
        $datosGrupoV = array();
        $sqlGv = "SELECT g.codigoGrupoVentas,g.NombreGrupoVentas,g.DiasPPNivel1,g.DiasPPNivel2,g.PermitirModificarPrecio,g.PermitirModificarDescuentoLinea,g.PermitirModifiarDescuentoMultiLinea,g.PermitirModificarDescuentoEspecialAltipal,g.PermitirModificarDescuentoEspecialProveedor,g.AplicaDescuentoPP,g.AplicaContado 
                        FROM `gruposventas` AS g 
                        INNER JOIN zonaventas AS z ON g.CodigoGrupoVentas=z.CodigoGrupoVentas 
                        WHERE z.CodZonaVentas='" . $usuario . "'; ";
        $rs_cltesGv = $db->ejecutar($sqlGv);
        if ($rs_cltesGv) {
            while ($col_cltesGv = $db->obtener_fila($rs_cltesGv, 0)) {

                $json = array(
                    'codigo_grupo_ventas' => $col_cltesGv['codigoGrupoVentas'],
                    'nombre_grupo_ventas' => $col_cltesGv['NombreGrupoVentas'],
                    'dias_pp1' => $col_cltesGv['DiasPPNivel1'],
                    'dias_pp2' => $col_cltesGv['DiasPPNivel2'],
                    'permite_modificar_precio' => strtoupper($col_cltesGv['PermitirModificarPrecio']),
                    'permite_modificar_descuento_linea' => strtoupper($col_cltesGv['PermitirModificarDescuentoLinea']),
                    'permite_modificar_descuento_multilinea' => strtoupper($col_cltesGv['PermitirModifiarDescuentoMultiLinea']),
                    'permite_modificar_descuento_especial_altipal' => strtoupper($col_cltesGv['PermitirModificarDescuentoEspecialAltipal']),
                    'permite_modificar_descuento_especial_proveedor' => strtoupper($col_cltesGv['PermitirModificarDescuentoEspecialProveedor']),
                    'aplica_descuento_pp' => strtoupper($col_cltesGv['AplicaDescuentoPP']),
                    'aplica_contado' => strtoupper($col_cltesGv['AplicaContado'])
                );
                array_push($datosGrupoV, $json);
            }
        }

        //ZonaAlmacen
        $datosZonaAlma = array();
        $sqlZonaAlma = "SELECT z.Id,z.CodZonaVentas,z.CodigoUbicacion,z.Preventa,z.Autoventa,z.Consignacion,z.VentaDirecta,z.Focalizado,z.CodigoSitio,s.Nombre AS NombreSitio,z.CodigoAlmacen,a.Nombre AS NombreAlmacen,z.Agencia 
                                    FROM `zonaventaalmacen` AS z 
                                    INNER JOIN sitios AS s ON z.CodigoSitio=s.CodSitio 
                                    INNER JOIN almacenes AS a ON z.CodigoAlmacen=a.CodigoAlmacen 
                                        WHERE z.CodZonaVentas='" . $usuario . "' GROUP BY z.Id; ";
        $rs_cltesZonaAlma = $db->ejecutar($sqlZonaAlma);
        if ($rs_cltesZonaAlma) {
            while ($colAlma = $db->obtener_fila($rs_cltesZonaAlma, 0)) {
                $json = array(
                    'Id' => $colAlma['Id'],
                    'CodZonaVentas' => $colAlma['CodZonaVentas'],
                    'CodigoUbicacion' => $colAlma['CodigoUbicacion'],
                    'Preventa' => strtoupper($colAlma['Preventa']),
                    'Autoventa' => strtoupper($colAlma['Autoventa']),
                    'Consignacion' => strtoupper($colAlma['Consignacion']),
                    'VentaDirecta' => strtoupper($colAlma['VentaDirecta']),
                    'Focalizado' => strtoupper($colAlma['Focalizado']),
                    'CodigoSitio' => $colAlma['CodigoSitio'],
                    'NombreSitio' => $colAlma['NombreSitio'],
                    'CodigoAlmacen' => $colAlma['CodigoAlmacen'],
                    'NombreAlmacen' => $colAlma['NombreAlmacen'],
                    'Agencia' => $colAlma['Agencia']
                );
                array_push($datosZonaAlma, $json);
            }
        }


        //Operaciones de conversion
        $datosOperacion = array();
        $sqlOperacion = "SELECT * FROM `operacionesunidades` ORDER BY Id; ";
        $rs_cltesOperacion = $db->ejecutar($sqlOperacion);
        if ($rs_cltesOperacion) {
            while ($colOperacion = $db->obtener_fila($rs_cltesOperacion, 0)) {
                $json = array(
                    'Id' => $colOperacion['Id'],
                    'CodigoDesde' => $colOperacion['CodigoDesde'],
                    'CodigoHasta' => $colOperacion['CodigoHasta'],
                    'Operacion' => $colOperacion['Operacion']
                );
                array_push($datosOperacion, $json);
            }
        }


        //Frecuencia
        $datosFrecuencia = array();
        $sqlFr = "SELECT * FROM `frecuenciavisita` ORDER BY NumeroVisita; ";
        $rs_cltesFr = $db->ejecutar($sqlFr);
        if ($rs_cltesFr) {
            while ($col_cltesFr = $db->obtener_fila($rs_cltesFr, 0)) {

                $json = array(
                    'numero_visita' => $col_cltesFr['NumeroVisita'],
                    'cod_frecuencia' => $col_cltesFr['CodFrecuencia'],
                    'r1' => $col_cltesFr['R1'],
                    'r2' => $col_cltesFr['R2'],
                    'r3' => $col_cltesFr['R3'],
                    'r4' => $col_cltesFr['R4']
                );
                array_push($datosFrecuencia, $json);
            }
        }


        //Codigo CIIU 
        $datosCiiu = array();
        $sqlciiu = "SELECT * FROM `ciiu`; ";
        $rs_cltesciiu = $db->ejecutar($sqlciiu);
        if ($rs_cltesciiu) {
            while ($col_cltesGv = $db->obtener_fila($rs_cltesciiu, 0)) {
                $json = array(
                    'CodigoCIIU' => $col_cltesGv['CodigoCIIU'],
                    'NombreCIIU' => $col_cltesGv['NombreCIIU']
                );
                array_push($datosCiiu, $json);
            }
        }


        //Bancos
        $datosBancos = array();
        $sqlBancos = "SELECT * FROM `bancos` WHERE `IdentificadorBanco` <> '' ; ";
        $rs_Bancos = $db->ejecutar($sqlBancos);
        if ($rs_Bancos) {
            while ($colBancos = $db->obtener_fila($rs_Bancos, 0)) {
                $json = array(
                    'Codigo' => $colBancos['CodBanco'],
                    'Nombre' => $colBancos['Nombre'],
                    'Identificador' => $colBancos['IdentificadorBanco']
                );
                array_push($datosBancos, $json);
            }
        }



        //Cuentas
        $datosCuentas = array();
        $sqlCuentas = "SELECT * FROM `cuentasbancarias`; ";
        $rs_Cuentas = $db->ejecutar($sqlCuentas);
        if ($rs_Cuentas) {
            while ($colCuentass = $db->obtener_fila($rs_Cuentas, 0)) {

                $json = array(
                    'CodigoBanco' => $colCuentass['CodBanco'],
                    'CodCuentaBancaria' => $colCuentass['CodCuentaBancaria'],
                    'Nombre' => $colCuentass['NombreCuentaBancaria']
                );
                array_push($datosCuentas, $json);
            }
        }



        //motivossaldo
        $datosMotivos = array();
        $sqlMotivos = "SELECT * FROM `motivossaldo`; ";
        $rs_Motivos = $db->ejecutar($sqlMotivos);
        if ($rs_Motivos) {
            while ($colMotivos = $db->obtener_fila($rs_Motivos, 0)) {
                $json = array(
                    'CodMotivoSaldo' => $colMotivos['CodMotivoSaldo'],
                    'Nombre' => $colMotivos['Nombre']
                );
                array_push($datosMotivos, $json);
            }
        }



        //motivosgestiondecobros
        $datosMotivosGestion = array();
        $sqlMotivos = "SELECT * FROM `motivosgestiondecobros`; ";
        $rs_Motivos = $db->ejecutar($sqlMotivos);
        if ($rs_Motivos) {
            while ($colMotivos = $db->obtener_fila($rs_Motivos, 0)) {
                $json = array(
                    'CodMotivoSaldo' => $colMotivos['CodMotivoGestion'],
                    'Nombre' => $colMotivos['Nombre']
                );
                array_push($datosMotivosGestion, $json);
            }
        }


        //motivosDevoluciones
        $datosMotivosDevolucion = array();
        $datosMotivosDevolucionArticulo = array();
        $sqlMotivos = "SELECT * FROM `motivosdevolucionproveedor`; ";
        $rs_Motivos = $db->ejecutar($sqlMotivos);
        if ($rs_Motivos) {
            while ($colMotivos = $db->obtener_fila($rs_Motivos, 0)) {
                $json = array(
                    'CodigoMotivoDevolucion' => $colMotivos['CodigoMotivoDevolucion'],
                    'CodigoGrupoMotivoDevolucion' => $colMotivos['CodigoGrupoMotivoDevolucion'],
                    'NombreMotivoDevolucion' => $colMotivos['NombreMotivoDevolucion'],
                    'CuentaProveedor' => $colMotivos['CuentaProveedor']
                );
                array_push($datosMotivosDevolucion, $json);

                $sqlMotivosArticulo = "SELECT * FROM motivosdevolucionproveedorarticulo WHERE CodigoMotivoDevolucion='" . $colMotivos['CodigoMotivoDevolucion'] . "' AND CuentaProveedor='" . $colMotivos['CuentaProveedor'] . "';";
                $rs_motivosArticulo = $db->ejecutar($sqlMotivosArticulo);
                while ($colMotivosArticulo = $db->obtener_fila($rs_motivosArticulo, 0)) {
                    $jsonArticulo = array(
                        'CodigoMotivoDevolucion' => $colMotivosArticulo['CodigoMotivoDevolucion'],
                        'CodigoArticulo' => $colMotivosArticulo['CodigoArticulo'],
                        'CuentaProveedor' => $colMotivosArticulo['CuentaProveedor']
                    );
                    array_push($datosMotivosDevolucionArticulo, $jsonArticulo);
                }
            }
        }



        //Proveedores
        $datosProveedores = array();
        $sqlProveedores = "SELECT * FROM proveedores;";
        $rs_proveedores = $db->ejecutar($sqlProveedores);
        if ($rs_proveedores) {
            while ($colProveedores = $db->obtener_fila($rs_proveedores, 0)) {
                $json = array(
                    'CodigoCuentaProveedor' => $colProveedores['CodigoCuentaProveedor'],
                    'NombreCuentaProveedor' => $colProveedores['NombreCuentaProveedor']
                );
                array_push($datosProveedores, $json);
            }
        }

        //responsablenota
        $datosresponsablenota = array();
        $sqlresponsablenota = "SELECT * FROM `responsablenota` WHERE Interfaz <>0; ";
        $rs_responsablenota = $db->ejecutar($sqlresponsablenota);
        if ($rs_responsablenota) {
            while ($colresponsablenota = $db->obtener_fila($rs_responsablenota, 0)) {
                $json = array(
                    'Interfaz' => $colresponsablenota['Interfaz'],
                    'Descripcion' => $colresponsablenota['Descripcion']
                );
                array_push($datosresponsablenota, $json);
            }
        }


        //Concepto Nota Credito
        $datosconceptosnotacredito = array();
        $sqlconceptosnotacredito = "SELECT * FROM `conceptosnotacredito`";
        $rs_conceptosnotacredito = $db->ejecutar($sqlconceptosnotacredito);
        if ($rs_conceptosnotacredito) {
            while ($colconceptosnotacredito = $db->obtener_fila($rs_conceptosnotacredito, 0)) {
                $json = array(
                    'Id' => $colconceptosnotacredito['Id'],
                    'CodigoConceptoNotaCredito' => $colconceptosnotacredito['CodigoConceptoNotaCredito'],
                    'NombreConceptoNotaCredito' => $colconceptosnotacredito['NombreConceptoNotaCredito'],
                    'Interfaz' => $colconceptosnotacredito['Interfaz']
                );
                array_push($datosconceptosnotacredito, $json);
            }
        }




        //MotivoNoVenta
        $datosMotivosNoVenta = array();
        $sqlMotivoNoVentas = "SELECT CodMotivoNoVenta, Nombre FROM motivosnoventa";
        $rsMotivosNoVenta = $db->ejecutar($sqlMotivoNoVentas);
        if ($rsMotivosNoVenta) {
            while ($colMotivoNoVenta = $db->obtener_fila($rsMotivosNoVenta, 0)) {
                $json = array(
                    'CodMotivoNoVenta' => $colMotivoNoVenta['CodMotivoNoVenta'],
                    'Nombre' => $colMotivoNoVenta['Nombre']
                );
                array_push($datosMotivosNoVenta, $json);
            }
        }



        //TipoDocumento
        $datosTipoDocumento = array();
        $sqlTipoDocumento = "SELECT * FROM tipodocumento";
        $rsTipoDocumento = $db->ejecutar($sqlTipoDocumento);
        if ($rsTipoDocumento) {
            while ($colTipoDocumento = $db->obtener_fila($rsTipoDocumento, 0)) {
                $json = array(
                    'Codigo' => $colTipoDocumento['Codigo'],
                    'Nombre' => $colTipoDocumento['Nombre']
                );
                array_push($datosTipoDocumento, $json);
            }
        }

        //Datos Impresion
        $datosImpresion = array();
        $sqlImpre = "SELECT * FROM datosimpresion";
        $rsImpre = $db->ejecutar($sqlImpre);
        if ($rsImpre) {
            while ($colTImpre = $db->obtener_fila($rsImpre, 0)) {
                $json = array(
                    'Id' => $colTImpre['Id'],
                    'Nit' => $colTImpre['Nit'],
                    'Sucursal' => $colTImpre['Sucursal'],
                    'Telefono' => $colTImpre['Telefono'],
                    'Fax' => $colTImpre['Fax'],
                    'NombreEmpresa' => $colTImpre['NombreEmpresa']
                );
                array_push($datosImpresion, $json);
            }
        }

        //Bancos Globales
        $client = new nusoap_client("http://altipal.datosmovil.info/SM/WebServiceLogin.php?wsdl");
        $client->soap_defencoding = 'UTF-8';
        $err = $client->getError();
        if ($err) {
            echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
            echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->getDebug(), ENT_QUOTES) . '</pre>';
            exit();
        }

        $args = array('value' => '');
        $devolver = $client->call('bancosCheques', array($args));
        $devolver = json_decode($devolver);


        //condicionespago
        $datosCondiciones = array();
        $sqlCondiciones = "SELECT * FROM `condicionespago` WHERE (Dias>0 OR Descripcion='Contado') ORDER BY `condicionespago`.`Dias` ASC; ";
        $rs_cltesCondiciones = $db->ejecutar($sqlCondiciones);
        if ($rs_cltesCondiciones) {
            while ($colCondiciones = $db->obtener_fila($rs_cltesCondiciones, 0)) {
                $json = array(
                    'CodigoCondicionPago' => $colCondiciones['CodigoCondicionPago'],
                    'Descripcion' => $colCondiciones['Descripcion'],
                    'Dias' => $colCondiciones['Dias']
                );
                array_push($datosCondiciones, $json);
            }
        }



        //Rangos Facturacion
        $sqlCOn = "SELECT COUNT(*) AS Cuantos FROM `zonaventaalmacen` WHERE CodZonaVentas='" . $usuario . "' AND (Autoventa='Verdadero' OR Autoventa='verdadero');";
        $stmtCon = $db->ejecutar($sqlCOn);
        $resultadoCon = $db->obtener_fila($stmtCon, 0);
        $cuantos = $resultadoCon['Cuantos'];

        $resolucion = array();
        if ($cuantos > 0) {
            $client = new nusoap_client("http://altipal.datosmovil.info/SM/WebServiceLogin.php?wsdl");
            $client->soap_defencoding = 'UTF-8';
            $err = $client->getError();
            if ($err) {
                echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
                echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->getDebug(), ENT_QUOTES) . '</pre>';
                exit();
            }

            $args = array('value' => 'resolu', 'zonaVentas' => $usuario);
            $resolucion = $client->call('resolucion', array($args));
            // $devolver = json_decode($devolver);
            $resolucion = json_decode($resolucion);

            $manejador = fopen('Log/CuantosZonaVenta.txt', 'a+');
            fputs($manejador, $resolucion . "\n");
            fclose($manejador);
        }


        $configuracionImpresion = array();
        if ($cuantos > 0) {
            $sqlIMpr = "SELECT * FROM `configuracion` WHERE Id='1'; ";
            $rs_clteIMpres = $db->ejecutar($sqlIMpr);
            if ($rs_clteIMpres) {
                while ($rs_cltesIm = $db->obtener_fila($rs_clteIMpres, 0)) {

                    $json = array(
                        'Id' => $rs_cltesIm['Id'],
                        'NombreCiudad' => $rs_cltesIm['NombreCiudad'],
                        'NombreEmpresa' => $rs_cltesIm['NombreEmpresa'],
                        'NombreSucursal' => $rs_cltesIm['NombreSucursal'],
                        'NitSucursal' => $rs_cltesIm['NitSucursal'],
                        'Direccion1Sucursal' => $rs_cltesIm['Direccion1Sucursal'],
                        'Direccion2Sucursal' => $rs_cltesIm['Direccion2Sucursal'],
                        'Direccion3Sucursal' => $rs_cltesIm['Direccion3Sucursal'],
                        'TelefonoSucursal' => $rs_cltesIm['TelefonoSucursal'],
                        'FaxSucursal' => $rs_cltesIm['FaxSucursal'],
                        'TelefonoServicioCliente' => $rs_cltesIm['TelefonoServicioCliente'],
                        'Resolucion1Contribuyentes' => $rs_cltesIm['Resolucion1Contribuyentes'],
                        'Resolucion2Contribuyentes' => $rs_cltesIm['Resolucion2Contribuyentes'],
                        'Resolucion1Retenedores' => $rs_cltesIm['Resolucion1Retenedores'],
                        'Resolucion2Retenedores' => $rs_cltesIm['Resolucion2Retenedores'],
                        'Resolucion1Dian' => $rs_cltesIm['Resolucion1Dian'],
                        'Resolucion2Dian' => $rs_cltesIm['Resolucion2Dian'],
                        'Resolucion3Dian' => $rs_cltesIm['Resolucion3Dian'],
                        'Resolucion4Dian' => $rs_cltesIm['Resolucion4Dian'],
                        'TextoPieFactura1' => $rs_cltesIm['TextoPieFactura1'],
                        'TextoPieFactura2' => $rs_cltesIm['TextoPieFactura2'],
                        'TextoPieFactura3' => $rs_cltesIm['TextoPieFactura3'],
                        'TextoPieFactura4' => $rs_cltesIm['TextoPieFactura4'],
                        'TextoPieFactura5' => $rs_cltesIm['TextoPieFactura5'],
                        'TextoPieFactura6' => $rs_cltesIm['TextoPieFactura6'],
                        'TextoPieFactura7' => $rs_cltesIm['TextoPieFactura7'],
                        'TextoPieFactura8' => $rs_cltesIm['TextoPieFactura8'],
                        'TextoPieFactura9' => $rs_cltesIm['TextoPieFactura9'],
                        'TextoPieFactura10' => $rs_cltesIm['TextoPieFactura10']
                    );
                    array_push($configuracionImpresion, $json);
                }
            }
        }

        //Tipovias
        $datosTipoVia = array();
        $sqlTipoVia = "SELECT * FROM `tipovia` ORDER BY `Tipo`;";
        $rsTipoV = $db->ejecutar($sqlTipoVia);
        if ($rsTipoV) {
            while ($colTipoV = $db->obtener_fila($rsTipoV, 0)) {
                $json = array(
                    'Tipo' => $colTipoV['Tipo'],
                    'Descripcion' => $colTipoV['Descripcion']
                );
                array_push($datosTipoVia, $json);
            }
        }

        //Complementos
        $datosTipoComplemento = array();
        $sqlTipoComple = "SELECT * FROM `tipoviacomplemento` ORDER BY Tipo;";
        $rsTComple = $db->ejecutar($sqlTipoComple);
        if ($rsTComple) {
            while ($colComple = $db->obtener_fila($rsTComple, 0)) {
                $json = array(
                    'Tipo' => $colComple['Tipo'],
                    'Descripcion' => $colComple['Descripcion']
                );
                array_push($datosTipoComplemento, $json);
            }
        }
        
                 //Fecha Actualizacion
        $fechaActualizacionInfo = array();        
        $sqlTipoComple = "SELECT * FROM `fechaactualizaciones` WHERE CodZonaVentas = '".$usuario."'";
        $rsTComple = $db->ejecutar($sqlTipoComple);
        if ($rsTComple) {
            while ($colComple = $db->obtener_fila($rsTComple, 0)) {
                $json = array(
                    'CodZonaVentas' => $colComple['CodZonaVentas'],
                    'FechaComparacion' => $colComple['FechaComparacion'],
                    'HoraComparacion' => $colComple['HoraComparacion'],
                    'estado' => "1",
                );
                array_push($fechaActualizacionInfo, $json);
            }
        } 
        

        //Malla de activacion

        $datosMallaActivacion = array();
        $sqlTipoComple = "SELECT * FROM `mallaactivacion` WHERE CodZonaVentas = '$usuario'";
        $rsTComple = $db->ejecutar($sqlTipoComple);
        if ($rsTComple) {
            while ($colComple = $db->obtener_fila($rsTComple, 0)) {
                $json = array(
                    'Id' => $colComple['Id'],
                    'DiasHabiles' => $colComple['DiasHabiles'],
                    'DiasTranscurridos' => $colComple['DiasTranscurridos'],
                    'Mes' => $colComple['Mes'],
                    'Annio' => $colComple['Año'],
                    'CodAgencia' => $colComple['CodAgencia'],
                    'NombreAgencia' => $colComple['NombreAgencia'],
                    'CodZonaVentas' => $colComple['CodZonaVentas']
                );
                array_push($datosMallaActivacion, $json);
            }
        }

         //Malla de activacion detalle

        $datosMallaActivacionDetalle = array();
        $sqlTipoComple = "SELECT * FROM `mallaactivaciondetalle` WHERE IdMallaActivacion IN(SELECT DISTINCT(Id) FROM `mallaactivacion` WHERE CodZonaVentas = '$usuario')";
        $rsTComple = $db->ejecutar($sqlTipoComple);
        if ($rsTComple) {
            while ($colComple = $db->obtener_fila($rsTComple, 0)) {
                $json = array(
                    'Id' => $colComple['Id'],
                    'IdMallaActivacion' => $colComple['IdMallaActivacion'],
                    'Tipo' => $colComple['Tipo'],
                    'Presupuestado' => $colComple['Presupuestado'],
                    'CuentaCliente' => $colComple['CuentaCliente'],
                    'NombreCliente' => $colComple['NombreCliente'],
                    'Ejecutado' => $colComple['Ejecutado'],
                    'Cumplimiento' => $colComple['Cumplimiento']
                );
                array_push($datosMallaActivacionDetalle , $json);
            }
        }
	 $sqlUpdateFechaActualizacion = "INSERT INTO `logactualizaciones`(`CodigoZonaVenta`, `FechaActualizacion`, `HoraActualizacion`, `Estado`) VALUES ('". $usuario . "',CURDATE(),CURTIME(),'1');";      
         $db->ejecutar($sqlUpdateFechaActualizacion);
        
        $subArray = array('Usuario' => $datosUsuario,
            'GrupoVentas' => $datosGrupoV,
            'ZonaAlmacen' => $datosZonaAlma,
            'OperacionConversion' => $datosOperacion,
            'Frecuencia' => $datosFrecuencia,
            'Ciiu' => $datosCiiu,
            'Bancos' => $datosBancos,
            'Cuentas' => $datosCuentas,
            'MotivosSaldo' => $datosMotivos,
            'MotivosGestion' => $datosMotivosGestion,
            'MotivosDevolucion' => $datosMotivosDevolucion,
            'MotivosDevolucionArticulo' => $datosMotivosDevolucionArticulo,
            'Proveedores' => $datosProveedores,
            'ResponsableNota' => $datosresponsablenota,
            'ConceptosNotaCredito' => $datosconceptosnotacredito,
            'MotivosNoVenta' => $datosMotivosNoVenta,
            'TipoDocumento' => $datosTipoDocumento,
            'DatosImpresion' => $datosImpresion,
            'bancosCheques' => $devolver,
            'condicionesPago' => $datosCondiciones,
            'Resolucion' => $resolucion,
            'ConfiguracionImpresion' => $configuracionImpresion,
            'TipoVia' => $datosTipoVia,
            'TipoViaComplemento' => $datosTipoComplemento,
            'datosMallaActivacion' => $datosMallaActivacion,
            'datosMallaActivacionDetalle' => $datosMallaActivacionDetalle,
            'fechaActualizacionInfo' => $fechaActualizacionInfo);
        return json_encode($subArray);
        
        
        
    }

    if ($value['value'] == 'LLENAR_DESCARGA_2') {
    
      $db = Db::getInstance();
        $usuario = trim($value['datos']);

        //Portafolio
        $datosPortafolio = array();
        $sqlPo = "SELECT p.Id,p.CodigoGrupoVentas,p.CodigoVariante,p.CodigoArticulo,p.NombreArticulo,p.CodigoCaracteristica1,p.CodigoCaracteristica2,p.CodigoTipo,tp.Nombre AS NombreTipo,p.CodigoMarca,p.CodigoGrupoCategoria,p.CodigoGrupoDescuentoLinea,p.CodigoGrupoDescuentoMultiLinea,p.CodigoGrupodeImpuestos,p.PorcentajedeIVA,p.ValorIMPOCONSUMO,p.CuentaProveedor,p.DctoPPNivel1,p.DctoPPNivel2,p.IdentificadorProductoNuevo,(SELECT COUNT(1) FROM variantesinactivas AS ina WHERE ina.CodigoVariante=p.CodigoVariante AND ina.CodigoSitio =  'EMPTY' AND ina.CodigoAlmacen =  'EMPTY' ) AS existe,(SELECT NombreCuentaProveedor FROM `proveedores` WHERE CodigoCuentaProveedor = CuentaProveedor) as fabricante,(SELECT IdPrincipal FROM `jerarquiaarticulos` WHERE Nombre = CodigoGrupoCategoria) as grupo,(SELECT MAX(PrecioVenta) FROM `acuerdoscomercialesprecioventa` WHERE CodigoVariante = p.CodigoVariante) as max_val
FROM `portafolio` AS p 
INNER JOIN zonaventas AS z ON p.CodigoGrupoVentas=z.CodigoGrupoVentas 
LEFT JOIN tipoproducto AS tp ON tp.CodigoTipoProducto = p.CodigoTipo
WHERE z.CodZonaVentas='" . $usuario . "' 
GROUP BY p.CodigoVariante,p.CodigoArticulo HAVING existe=0; ";
        $rs_cltesPo = $db->ejecutar($sqlPo);
        if ($rs_cltesPo) {
            while ($colPo = $db->obtener_fila($rs_cltesPo, 0)) {

                $caracteristica2 = trim(str_replace("N/A", "", $colPo['CodigoCaracteristica2']));
                $caracteristica2 = trim(str_replace("null", "", $caracteristica2));
                $codigoTipoArticulo = $colPo['CodigoTipo'];
                $verificarExistencia = 1;
                if($codigoTipoArticulo == KD || $codigoTipoArticulo == KV){
                   $codigoVarianteKit = $colPo['CodigoVariante'];
                   $sqlListaKit = "SELECT lmd.`CodigoVarianteComponente` FROM `listadematerialesdetalle` lmd INNER JOIN listademateriales lm ON lmd.`CodigoListaMateriales` = lm.CodigoListaMateriales WHERE lm.`CodigoVarianteKit` = '" . $codigoVarianteKit . "';";
                   $rsListaKit = $db->ejecutar($sqlListaKit);
                
                while ($colListaKit = $db->obtener_fila($rsListaKit, 0)) {
                    $codigoVarianteComponente = $colListaKit['CodigoVarianteComponente'];
                    
                    $sqlKit = "SELECT COUNT(*) AS Conteo FROM `portafolio` WHERE `CodigoVariante` = '" . $codigoVarianteComponente . "';";
                    $stmtKit = $db->ejecutar($sqlKit);
                    $resultadoKit = $db->obtener_fila($stmtKit, 0);
                    $ConteoKit = $resultadoKit['Conteo'];
                      
                    if($ConteoKit==0){
                      $verificarExistencia = 0;
                       
                    }
                    
                }
                
                    
                    
                }
                
               /* if(!empty($colPo['fabricante']))
                {*/
                if($verificarExistencia == 1){
                $json = array(
                    'Id' => $colPo['Id'],
                    'CodigoGrupoVentas' => $colPo['CodigoGrupoVentas'],
                    'CodigoVariante' => $colPo['CodigoVariante'],
                    'CodigoArticulo' => $colPo['CodigoArticulo'],
                    'NombreArticulo' => $colPo['NombreArticulo'],
                    'CodigoCaracteristica1' => $colPo['CodigoCaracteristica1'],
                    'CodigoCaracteristica2' => $caracteristica2,
                    'CodigoTipo' => $colPo['CodigoTipo'],
                    'NombreTipo' => $colPo['NombreTipo'],
                    'CodigoMarca' => $colPo['CodigoMarca'],
                    'CodigoGrupoCategoria' => $colPo['CodigoGrupoCategoria'],
                    'CodigoGrupoDescuentoLinea' => $colPo['CodigoGrupoDescuentoLinea'],
                    'CodigoGrupoDescuentoMultiLinea' => $colPo['CodigoGrupoDescuentoMultiLinea'],
                    'CodigoGrupodeImpuestos' => $colPo['CodigoGrupodeImpuestos'],
                    'PorcentajedeIVA' => $colPo['PorcentajedeIVA'],
                    'ValorIMPOCONSUMO' => $colPo['ValorIMPOCONSUMO'],
                    'CuentaProveedor' => $colPo['CuentaProveedor'],
                    'DctoPPNivel1' => $colPo['DctoPPNivel1'],
                    'DctoPPNivel2' => $colPo['DctoPPNivel2'],
                    'IdentificadorProductoNuevo' => $colPo['IdentificadorProductoNuevo'],
                    'fabricante' => $colPo['fabricante'],
                    'grupo' => $colPo['grupo'],
                    'max_val' => $colPo['max_val']
                );
                array_push($datosPortafolio, $json);
           // }
                }
            }
        }

        $subArray = array('Portafolio' => $datosPortafolio);
        
	 $sqlUpdateFechaActualizacion = "INSERT INTO `logactualizaciones`(`CodigoZonaVenta`, `FechaActualizacion`, `HoraActualizacion`, `Estado`) VALUES ('". $usuario . "',CURDATE(),CURTIME(),'2');";      
         $db->ejecutar($sqlUpdateFechaActualizacion);
        

        return json_encode($subArray);
    
    }

    if ($value['value'] == 'LLENAR_DESCARGA_3') {
        $db = Db::getInstance();
        $usuario = trim($value['datos']);

        //SaldoInventarioPreventa
        $datosSaldoPreventa = array();
        $sqlSaldoPreventa = "SELECT sa.* FROM `saldosinventariopreventa` AS sa 
                                        INNER JOIN zonaventaalmacen AS z ON z.CodigoSitio=sa.CodigoSitio AND z.CodigoAlmacen=sa.CodigoAlmacen 
                                        WHERE z.CodZonaVentas='" . $usuario . "' GROUP BY sa.Id; ";
        $rs_cltesSaldoPreventa = $db->ejecutar($sqlSaldoPreventa);
        if ($rs_cltesSaldoPreventa) {
            while ($colSaldoPreventa = $db->obtener_fila($rs_cltesSaldoPreventa, 0)) {
                $json = array(
                    'Id' => $colSaldoPreventa['Id'],
                    'CodigoSitio' => $colSaldoPreventa['CodigoSitio'],
                    'CodigoAlmacen' => $colSaldoPreventa['CodigoAlmacen'],
                    'CodigoVariante' => $colSaldoPreventa['CodigoVariante'],
                    'CodigoArticulo' => $colSaldoPreventa['CodigoArticulo'],
                    'CodigoTipo' => $colSaldoPreventa['CodigoTipo'],
                    'Disponible' => $colSaldoPreventa['Disponible'],
                    'CodigoUnidadMedida' => $colSaldoPreventa['CodigoUnidadMedida'],
                    'NombreUnidadMedida' => $colSaldoPreventa['NombreUnidadMedida']
                );
                array_push($datosSaldoPreventa, $json);
            }
        }

        //SaldoInventarioAutoVenta
        $datosSaldoAutoVenta = array();
        $sqlSaldoAutoventa = "SELECT sa.* FROM `saldosinventarioautoventayconsignacion` AS sa INNER JOIN zonaventaalmacen AS z ON z.CodigoSitio=sa.CodigoSitio AND z.CodigoAlmacen=sa.CodigoAlmacen AND z.CodigoUbicacion=sa.CodigoUbicacion WHERE z.CodZonaVentas='" . $usuario . "' AND sa.LoteArticulo<>'NULL' AND sa.LoteArticulo<>''  AND sa.Disponible > 0  GROUP BY sa.CodigoSitio,sa.CodigoAlmacen,sa.CodigoVariante,sa.LoteArticulo; ";
        $rs_cltesSaldoAutoVenta = $db->ejecutar($sqlSaldoAutoventa);
        if ($rs_cltesSaldoAutoVenta) {
            while ($colSaldoAutoVenta = $db->obtener_fila($rs_cltesSaldoAutoVenta, 0)) {
                $json = array(
                    'Id' => $colSaldoAutoVenta['Id'],
                    'CodigoSitio' => $colSaldoAutoVenta['CodigoSitio'],
                    'CodigoAlmacen' => $colSaldoAutoVenta['CodigoAlmacen'],
                    'CodigoUbicacion' => $colSaldoAutoVenta['CodigoUbicacion'],
                    'CodigoVariante' => $colSaldoAutoVenta['CodigoVariante'],
                    'CodigoArticulo' => $colSaldoAutoVenta['CodigoArticulo'],
                    'LoteArticulo' => $colSaldoAutoVenta['LoteArticulo'],
                    'CodigoTipo' => $colSaldoAutoVenta['CodigoTipo'],
                    'CodigoUnidadMedida' => $colSaldoAutoVenta['CodigoUnidadMedida'],
                    'NombreUnidadMedida' => $colSaldoAutoVenta['NombreUnidadMedida'],
                    'Disponible' => $colSaldoAutoVenta['Disponible']
                );
                array_push($datosSaldoAutoVenta, $json);
            }
        }

        $subArray = array('SaldoPreventa' => $datosSaldoPreventa,
            'SaldoAutoventa' => $datosSaldoAutoVenta);

	 $sqlUpdateFechaActualizacion = "INSERT INTO `logactualizaciones`(`CodigoZonaVenta`, `FechaActualizacion`, `HoraActualizacion`, `Estado`) VALUES ('". $usuario . "',CURDATE(),CURTIME(),'3');";      
         $db->ejecutar($sqlUpdateFechaActualizacion);
        
         
        return json_encode($subArray);
    }

    if ($value['value'] == 'LLENAR_DESCARGA_4') {
        $db = Db::getInstance();
        $usuario = trim($value['datos']);

        $datosUni = array();
        $sqlUni = "SELECT * FROM `unidadesdeconversion`;";       
        // $sqlUni = "SELECT u.* FROM `unidadesdeconversion` AS u INNER JOIN portafolio AS p ON u.CodigoArticulo=p.CodigoArticulo INNER JOIN zonaventas AS z ON p.CodigoGrupoVentas=z.CodigoGrupoVentas WHERE z.CodZonaVentas='" . $usuario . "' GROUP BY u.Id;";
        $rs_cltesUni = $db->ejecutar($sqlUni);
        if ($rs_cltesUni) {
            while ($colUni = $db->obtener_fila($rs_cltesUni, 0)) {

                $factor = str_replace(",00", "", $colUni['Factor']);
                $json = array(
                    'Id' => $colUni['Id'],
                    'CodigoArticulo' => $colUni['CodigoArticulo'],
                    'CodigoDesdeUnidad' => $colUni['CodigoDesdeUnidad'],
                    'CodigoHastaUnidad' => $colUni['CodigoHastaUnidad'],
                    'Factor' => $factor
                );
                array_push($datosUni, $json);
            }
        }

        $subArray = array('UnidaConversion' => $datosUni);

	 $sqlUpdateFechaActualizacion = "INSERT INTO `logactualizaciones`(`CodigoZonaVenta`, `FechaActualizacion`, `HoraActualizacion`, `Estado`) VALUES ('". $usuario . "',CURDATE(),CURTIME(),'4');";      
         $db->ejecutar($sqlUpdateFechaActualizacion);
        
        
        return json_encode($subArray);
    }

    if ($value['value'] == 'LLENAR_DESCARGA_5') {
        $db = Db::getInstance();
        $usuario = trim($value['datos']);

        $datosInactivos = array();
        
     /* $manejador = fopen('arrayinactivas.txt', 'a+');
       fputs($manejador, $value['datos'] . "\n");
        fputs($manejador, "SELECT v.* FROM `variantesinactivas` AS v INNER JOIN zonaventaalmacen AS z ON v.CodigoSitio=z.CodigoSitio AND v.CodigoAlmacen=z.CodigoAlmacen WHERE z.CodZonaVentas='" . $usuario . "' GROUP BY v.CodigoSitio,v.CodigoAlmacen,v.CodigoVariante ORDER BY v.Id;\n");
        fclose($manejador);
*/

         $sqlIna = "SELECT v.* FROM `variantesinactivas` AS v INNER JOIN zonaventaalmacen AS z ON v.CodigoSitio=z.CodigoSitio WHERE z.CodZonaVentas='" . $usuario . "' GROUP BY v.CodigoSitio,v.CodigoAlmacen,v.CodigoVariante ORDER BY v.Id;";
          $rsIna = $db->ejecutar($sqlIna);
          if ($rsIna) {
          while ($colina = $db->obtener_fila($rsIna, 0)) {
          $json = array(
          'Id' => $colina['Id'],
          'CodigoSitio' => $colina['CodigoSitio'],
          'CodigoAlmacen' => $colina['CodigoAlmacen'],
          'CodigoArticulo' => $colina['CodigoArticulo'],
          'CodigoVariante' => $colina['CodigoVariante'],
          'NombreVariante' => $colina['NombreVariante']
          );
          array_push($datosInactivos, $json);
          }
          } 

          $sqlIna = "SELECT * FROM `variantesinactivas` WHERE CodigoSitio = 'EMPTY' AND CodigoAlmacen = 'EMPTY'";
          $rsIna = $db->ejecutar($sqlIna);
          if ($rsIna) {
          while ($colina = $db->obtener_fila($rsIna, 0)) {
          $json = array(
          'Id' => $colina['Id'],
          'CodigoSitio' => $colina['CodigoSitio'],
          'CodigoAlmacen' => $colina['CodigoAlmacen'],
          'CodigoArticulo' => $colina['CodigoArticulo'],
          'CodigoVariante' => $colina['CodigoVariante'],
          'NombreVariante' => $colina['NombreVariante']
          );
          array_push($datosInactivos, $json);
          }
          } 

        $subArray = array('VariantesInactivas' => $datosInactivos);

	 $sqlUpdateFechaActualizacion = "INSERT INTO `logactualizaciones`(`CodigoZonaVenta`, `FechaActualizacion`, `HoraActualizacion`, `Estado`) VALUES ('". $usuario . "',CURDATE(),CURTIME(),'5');";      
         $db->ejecutar($sqlUpdateFechaActualizacion);
        
        
        return json_encode($subArray);
    }

    if ($value['value'] == 'LLENAR_DESCARGA_6') {
        $db = Db::getInstance();
        $usuario = trim($value['datos']);

        //Listas de materiales
        $datosLista = array();
        $sqlLista = "SELECT l.* FROM `listademateriales` AS l INNER JOIN portafolio AS p ON l.CodigoArticuloKit=p.CodigoArticulo AND l.CodigoTipoKit=p.CodigoTipo INNER JOIN zonaventas AS z ON z.CodigoGrupoVentas=p.CodigoGrupoVentas WHERE z.CodZonaVentas='" . $usuario . "';";
        $rsLista = $db->ejecutar($sqlLista);
        if ($rsLista) {
            while ($colLista = $db->obtener_fila($rsLista, 0)) {

                $kitValido = 0;
                $sqlDetalle = "SELECT *,(SELECT COUNT(*) FROM listadematerialesdetalle WHERE `CodigoListaMateriales`='" . $colLista['CodigoListaMateriales'] . "' AND `CodigoTipo`<>'OB') AS cuantos FROM `listadematerialesdetalle` WHERE `CodigoListaMateriales`='" . $colLista['CodigoListaMateriales'] . "' HAVING cuantos>0;";
                $rsDetalle = $db->ejecutar($sqlDetalle);
                $datosDetalle = array();
                
                while ($colDet = $db->obtener_fila($rsDetalle, 0)) {
                    
                    $sqlImpuestosDetalles="SELECT PorcentajedeIVA, ValorIMPOCONSUMO, NombreArticulo FROM portafolio WHERE `CodigoArticulo` = '" . $colDet['CodigoArticuloComponente'] . "';";
                    $rsImpuestosDetalles = $db->ejecutar($sqlImpuestosDetalles);
                    $colImpuestosDetalles =  $db->obtener_fila($rsImpuestosDetalles, 0);
                    $kitValido++;
                    $jsonDetalle = array(
                        'Id' => $colDet['Id'],
                        'CodigoListaMateriales' => $colDet['CodigoListaMateriales'],
                        'CodigoArticuloComponente' => $colDet['CodigoArticuloComponente'],
                        'CodigoCaracteristica1' => $colDet['CodigoCaracteristica1'],
                        'CodigoCaracteristica2' => $colDet['CodigoCaracteristica2'],
                        'CodigoTipo' => $colDet['CodigoTipo'],
                        'CantidadComponente' => $colDet['CantidadComponente'],
                        'CodigoUnidadMedida' => $colDet['CodigoUnidadMedida'],
                        'NombreUnidadMedida' => $colDet['NombreUnidadMedida'],
                        'Fijo' => $colDet['Fijo'],
                        'Opcional' => $colDet['Opcional'],
                        'PrecioVentaBaseVariante' => $colDet['PrecioVentaBaseVariante'],
                        'TotalPrecioVentaBaseVariante' => $colDet['TotalPrecioVentaBaseVariante'],
                        'CodigoVarianteComponente' => $colDet['CodigoVarianteComponente'],
                        'PorcentajedeIVA' => $colImpuestosDetalles['PorcentajedeIVA'],
                        'ValorIMPOCONSUMO' => $colImpuestosDetalles['ValorIMPOCONSUMO'],
                        'NombreArticulo' => $colImpuestosDetalles['NombreArticulo']
                    );
                    array_push($datosDetalle, $jsonDetalle);
                }

                if ($kitValido > 0) {
                    $json = array(
                        'Id' => $colLista['Id'],
                        'CodigoListaMateriales' => $colLista['CodigoListaMateriales'],
                        'CodigoArticuloKit' => $colLista['CodigoArticuloKit'],
                        'CodigoCaracteristica1Kit' => $colLista['CodigoCaracteristica1Kit'],
                        'CodigoCaracteristica2Kit' => $colLista['CodigoCaracteristica2Kit'],
                        'CodigoTipoKit' => $colLista['CodigoTipoKit'],
                        'Cantidad' => $colLista['Cantidad'],
                        'Sitio' => $colLista['Sitio'],
                        'Almacen' => $colLista['Almacen'],
                        'CantidadFijos' => $colLista['CantidadFijos'],
                        'CantidadOpcionales' => $colLista['CantidadOpcionales'],
                        'TotalPrecioVentaListaMateriales' => $colLista['TotalPrecioVentaListaMateriales'],

                        'Detalles' => array('Detalles' => $datosDetalle)
                        
                    );
                    array_push($datosLista, $json);
                }
            }
        }

        $subArray = array('ListaMateriales' => $datosLista);

	 $sqlUpdateFechaActualizacion = "INSERT INTO `logactualizaciones`(`CodigoZonaVenta`, `FechaActualizacion`, `HoraActualizacion`, `Estado`) VALUES ('". $usuario . "',CURDATE(),CURTIME(),'6');";      
         $db->ejecutar($sqlUpdateFechaActualizacion);
        
        
        return json_encode($subArray);
    }

    //Focalizados
    if ($value['value'] == 'LLENAR_DESCARGA_7') {
        $db = Db::getInstance();
        $usuario = trim($value['datos']);

        //PlaneacionMes
        $datosPlaneacion = array();
        $sqlLista = "SELECT c.CuentaCliente,c.NombreCliente,c.NombreBusqueda FROM cliente AS c INNER JOIN clienteruta AS cr ON c.CuentaCliente = cr.CuentaCliente WHERE cr.CodZonaVentas ='" . $usuario . "' GROUP BY c.CuentaCliente;";
        $rsLista = $db->ejecutar($sqlLista);
        if ($rsLista) {
            while ($colLista = $db->obtener_fila($rsLista, 0)) {

                $idP = "0";
                $idPlaneacionMes = "0";
                $mesP = "0";
                $anoP = "0";
                $valor = "0";
                $sqlDetalle = "SELECT pd.Id,pd.IdPlaneacionMes,p.Mes,p.Ano,pd.Valor FROM `planeacionmesdetalle` AS pd INNER JOIN planeacionmes AS p ON pd.IdPlaneacionMes = p.IdPlaneacionMes WHERE pd.CuentaCliente ='" . $colLista['CuentaCliente'] . "' AND p.Mes = MONTH(CURDATE()) AND p.Ano = YEAR(CURDATE());";
                $rsDetalle = $db->ejecutar($sqlDetalle);
                $datosDetalle = array();
                while ($colDet = $db->obtener_fila($rsDetalle, 0)) {
                    $idP = $colDet['Id'];
                    $idPlaneacionMes = $colDet['IdPlaneacionMes'];
                    $mesP = $colDet['Mes'];
                    $anoP = $colDet['Ano'];
                    $valor = $colDet['Valor'];
                }

                $jsonDetalle = array(
                    'Id' => $idP,
                    'IdPlaneacionMes' => $idPlaneacionMes,
                    'Mes' => $mesP,
                    'Ano' => $anoP,
                    'CuentaCliente' => $colLista['CuentaCliente'],
                    'Nombre' => $colLista['NombreCliente'],
                    'NombreBusqueda' => $colLista['NombreBusqueda'],
                    'Valor' => $valor
                );
                array_push($datosPlaneacion, $jsonDetalle);
            }
        }

        $subArray = array('PlaneacionMes' => $datosPlaneacion);

        return json_encode($subArray);
    }


    if ($value['value'] == 'LLENAR_DESCARGA_8') {
        $db = Db::getInstance();
        $usuario = trim($value['datos']);
        $fechaActual = date('Y-m-d');

        //EncuestaActivacion
        $titulo = array();
        $preguntas = array();
        $sqlTitulo = "SELECT `IdTitulo`, `Titulo`, `Tipo`, `FechaInicio`, `FechaFin`, `Descripcion` FROM `tituloencuesta` WHERE (`FechaInicio`<='" . $fechaActual . "' AND `FechaFin`>='" . $fechaActual . "') AND `Descripcion` ='Focalizados';";
        $rsTitulo = $db->ejecutar($sqlTitulo);
        if ($rsTitulo) {
            while ($tdTitulo = $db->obtener_fila($rsTitulo, 0)) {
                $jsonTitulo = array(
                    'id_titulo' => $tdTitulo['IdTitulo'],
                    'titulo' => $tdTitulo['Titulo'],
                    'tipo' => $tdTitulo['Tipo'],
                    'fecha_inicio' => $tdTitulo['FechaInicio'],
                    'fecha_fin' => $tdTitulo['FechaFin'],
                    'descripcion' => $tdTitulo['Descripcion']
                );
                array_push($titulo, $jsonTitulo);

                $sqlPreguntas = "SELECT `IdPregunta`, `IdBloque`, `IdTituloEncuesta`, `Pregunta`, `IdTipoCampo`, `RequiereFoto` FROM `preguntas` WHERE `IdTituloEncuesta` ='" . $tdTitulo['IdTitulo'] . "' ORDER BY IdPregunta;";
                $rsPreguntas = $db->ejecutar($sqlPreguntas);
                if ($rsPreguntas) {
                    while ($tdPreguntas = $db->obtener_fila($rsPreguntas, 0)) {
                        $jsonPreguntas = array(
                            '' => $tdPreguntas[''],
                            '' => $tdPreguntas[''],
                            '' => $tdPreguntas[''],
                            '' => $tdPreguntas[''],
                            '' => $tdPreguntas[''],
                            '' => $tdPreguntas['']
                        );
                        array_push($preguntas, $jsonPreguntas);
                    }
                }
            }
        }

        $subArray = array('PlaneacionMes' => $datosPlaneacion);

        return json_encode($subArray);
    }




    if ($value['value'] == 'DESCARGA_CLIENTES1') {
        $db = Db::getInstance();
        $zonaVentas = trim($value['zona']);
        $ruta = trim($value['ruta']);
        $fechaActual = date('Y-m-d');

        //Clientes
        $datosClientes = array();
        $sql = "SELECT 
            f.NumeroVisita,
            f.CodFrecuencia,
            f.R1,
            f.R2,
            f.R3,
            f.R4,
            cr.IdClienteRuta,
            cr.CodZonaVentas,
            cr.CuentaCliente,
            cr.Posicion,
            cr.CodigoZonaLogistica,
            zl.NombreZonaLogistica,
            cr.ValorCupo,
            cr.ValorCupoTemporal,
            cr.SaldoCupo,
            c.Identificacion,
            c.NombreCliente,
            c.NombreBusqueda,
            c.DireccionEntrega,
            c.Telefono,
            c.TelefonoMovil,
            c.CorreoElectronico,
            c.Estado,
            c.CodigoCadenaEmpresa,
            cd.Nombre AS NombreCadenaEmpresa,
            cd.ValorMinimo,
            cd.CodSubSegmento,
            sg.Nombre AS NombreSubsegmento,
            sg.CodSegmento,
            sgt.Nombre AS NombreSegmento,
            cr.CodigoCondicionPago,
            cp.Descripcion AS DescripcionCondicionPago,
            cp.Dias,
            cr.CodigoFormadePago,
            fp.Descripcion AS DescripcionFormaPago,
            fp.CuentaPuente,
            c.CodigoBarrio,
            lo.NombreBarrio AS NombreBarrio,
            lo.CodigoLocalidad AS CodigoLocalidad,
            lo.NombreLocalidad AS NombreLocalidad,
            lo.CodigoCiudad AS CodigoCiudad,
            lo.NombreCiudad AS NombreCiudad,
            lo.CodigoDepartamento AS CodigoDepartamento,
            lo.NombreDepartamento AS NombreDepartamento,
            c.CodigoPostal,
            c.Latitud,
            c.Longitud,
            cr.CodigoGrupodeImpuestos,
            gi.NombreGrupoImpuestos,
            gi.CodigoTipoContribuyente,
            gi.NombreTipoContribuyente,
            gi.CodigoDepartamento AS CodigoDepartamentoImpuesto,
            gi.NombreDepartamento AS NombreDepartamentoImpuesto,
            gi.CodigoCiudad AS CodigoCiudadImpuesto,
            gi.NombreCiudad AS NombreCiudadImpuesto,
            cr.CodigoGrupoPrecio,
            gp.NombreGrupodePrecio,
            cr.CodigoGrupoDescuentoLinea,
            'N/N',
            cr.CodigoGrupoDescuentoMultiLinea,
            'N/N',
            cr.DiasGracia,
            cr.DiasAdicionales
            FROM 
            `frecuenciavisita` f
            INNER JOIN clienteruta  cr ON cr.NumeroVisita=f.NumeroVisita            
            INNER JOIN cliente  c ON c.CuentaCliente=cr.CuentaCliente
            INNER JOIN zonaventas  z ON cr.`CodZonaVentas`=z.`CodZonaVentas`
            LEFT JOIN zonalogistica zl ON zl.CodZonaLogistica=cr.CodigoZonaLogistica
            LEFT JOIN cadenaempresa cd ON cd.CodigoCadenaEmpresa=c.CodigoCadenaEmpresa
            LEFT JOIN subsegmento sg ON sg.CodSubSegmento=cd.CodSubSegmento
            LEFT JOIN segmentos sgt ON sgt.CodSegmento=sg.CodSegmento
            LEFT JOIN condicionespago cp ON cp.CodigoCondicionPago=cr.CodigoCondicionPago       
            LEFT JOIN formaspago fp ON fp.CodigoFormadePago=cr.CodigoFormadePago
            LEFT JOIN Localizacion lo ON lo.CodigoBarrio = c.CodigoBarrio
            LEFT JOIN grupoimpuestos gi ON gi.CodigoGrupoImpuestos=cr.CodigoGrupodeImpuestos
            LEFT JOIN grupodeprecios gp ON gp.CodigoGrupoPrecio=cr.CodigoGrupoPrecio
            WHERE cr.CodZonaVentas='$zonaVentas' AND
            (`R1`='$ruta' OR `R2`='$ruta' OR `R3`='$ruta' OR `R4`='$ruta') GROUP BY cr.CuentaCliente;";
        $rs_cltes = $db->ejecutar($sql);
        if ($rs_cltes) {
            while ($col_cltes = $db->obtener_fila($rs_cltes, 0)) {

                $DescripcionFormaPago = trim($col_cltes['DescripcionFormaPago']);
                if (($DescripcionFormaPago == "NULL") || ($DescripcionFormaPago == "null")) {
                    $DescripcionFormaPago = "";
                }

                $sqlSaldoFavor = "SELECT ABS(SUM(`SaldoFactura`)) AS saldo FROM `facturasaldo` WHERE `CuentaCliente`='" . $col_cltes['CuentaCliente'] . "' AND `SaldoFactura` < 0;";
                $stFavor = $db->ejecutar($sqlSaldoFavor);
                $resu = $db->obtener_fila($stFavor, 0);
                $saldoFavor = $resu['saldo'];

                if (empty($saldoFavor) || is_null($saldoFavor)) {
                    $saldoFavor = '0';
                }

                $json = array(
                    'NumeroVisita' => $col_cltes['NumeroVisita'],
                    'CodFrecuencia' => $col_cltes['CodFrecuencia'],
                    'R1' => $col_cltes['R1'],
                    'R2' => $col_cltes['R2'],
                    'R3' => $col_cltes['R3'],
                    'R4' => $col_cltes['R4'],
                    'IdClienteRuta' => $col_cltes['IdClienteRuta'],
                    'CodZonaVentas' => $col_cltes['CodZonaVentas'],
                    'CuentaCliente' => trim($col_cltes['CuentaCliente']),
                    'Posicion' => $col_cltes['Posicion'],
                    'CodigoZonaLogistica' => $col_cltes['CodigoZonaLogistica'],
                    'NombreZonaLogistica' => $col_cltes['NombreZonaLogistica'],
                    'ValorCupo' => $col_cltes['ValorCupo'],
                    'ValorCupoTemporal' => $col_cltes['ValorCupoTemporal'],
                    'SaldoCupo' => vacio($col_cltes['SaldoCupo']),
                    'Identificacion' => $col_cltes['Identificacion'],
                    'NombreCliente' => $col_cltes['NombreCliente'],
                    'NombreBusqueda' => $col_cltes['NombreBusqueda'],
                    'DireccionEntrega' => $col_cltes['DireccionEntrega'],
                    'Telefono' => $col_cltes['Telefono'],
                    'TelefonoMovil' => vacio($col_cltes['TelefonoMovil']),
                    'CorreoElectronico' => $col_cltes['CorreoElectronico'],
                    'Estado' => $col_cltes['Estado'],
                    'CodigoCadenaEmpresa' => $col_cltes['CodigoCadenaEmpresa'],
                    'NombreCadenaEmpresa' => vacio($col_cltes['NombreCadenaEmpresa']),
                    'ValorMinimo' => $col_cltes['ValorMinimo'],
                    'CodSubSegmento' => $col_cltes['CodSubSegmento'],
                    'NombreSubsegmento' => $col_cltes['NombreSubsegmento'],
                    'CodSegmento' => $col_cltes['CodSegmento'],
                    'NombreSegmento' => $col_cltes['NombreSegmento'],
                    'CodigoCondicionPago' => $col_cltes['CodigoCondicionPago'],
                    'DescripcionCondicionPago' => $col_cltes['DescripcionCondicionPago'],
                    'Dias' => vacio($col_cltes['Dias']),
                    'CodigoFormadePago' => $col_cltes['CodigoFormadePago'],
                    'DescripcionFormaPago' => $DescripcionFormaPago,
                    'CuentaPuente' => $col_cltes['CuentaPuente'],
                    'CodigoBarrio' => $col_cltes['CodigoBarrio'],
                    'NombreBarrio' => $col_cltes['NombreBarrio'],
                    'CodigoLocalidad' => $col_cltes['CodigoLocalidad'],
                    'NombreLocalidad' => $col_cltes['NombreLocalidad'],
                    'CodigoCiudad' => $col_cltes['CodigoCiudad'],
                    'NombreCiudad' => $col_cltes['NombreCiudad'],
                    'CodigoDepartamento' => $col_cltes['CodigoDepartamento'],
                    'NombreDepartamento' => $col_cltes['NombreDepartamento'],
                    'CodigoPostal' => $col_cltes['CodigoPostal'],
                    'Latitud' => $col_cltes['Latitud'],
                    'Longitud' => $col_cltes['Longitud'],
                    'CodigoGrupodeImpuestos' => $col_cltes['CodigoGrupodeImpuestos'],
                    'NombreGrupoImpuestos' => $col_cltes['NombreGrupoImpuestos'],
                    'CodigoTipoContribuyente' => $col_cltes['CodigoTipoContribuyente'],
                    'NombreTipoContribuyente' => $col_cltes['NombreTipoContribuyente'],
                    'CodigoDepartamentoImpuesto' => $col_cltes['CodigoDepartamentoImpuesto'],
                    'NombreDepartamentoImpuesto' => $col_cltes['NombreDepartamentoImpuesto'],
                    'CodigoCiudadImpuesto' => $col_cltes['CodigoCiudadImpuesto'],
                    'NombreCiudadImpuesto' => $col_cltes['NombreCiudadImpuesto'],
                    'CodigoGrupoPrecio' => $col_cltes['CodigoGrupoPrecio'],
                    'NombreGrupodePrecio' => $col_cltes['NombreGrupodePrecio'],
                    'CodigoGrupoDescuentoLinea' => $col_cltes['CodigoGrupoDescuentoLinea'],
                    'NombreGrupoDescuentoLinea' => 'N/N',
                    'CodigoGrupoDescuentoMultiLinea' => $col_cltes['CodigoGrupoDescuentoMultiLinea'],
                    'NombreGrupoDescuentoMultiLinea' => 'N/N',
                    'SaldoFavor' => $saldoFavor,
                    'DiasGracia' => $col_cltes['DiasGracia'],
                    'DiasAdicionales' => $col_cltes['DiasAdicionales']);
                array_push($datosClientes, $json);
            }
        }


        $subArray = array('Clientes' => $datosClientes);

        return json_encode($subArray);
    }

    if ($value['value'] == 'DESCARGA_CLIENTES2') {
        $db = Db::getInstance();
        $zonaVentas = trim($value['zona']);
        $ruta = trim($value['ruta']);
        $fechaActual = date('Y-m-d');

        $nit = array();
        $squeryId = "SELECT DISTINCT(c.Identificacion) AS identificacion 
                FROM `cliente` AS c 
                INNER JOIN clienteruta AS cr ON c.CuentaCliente = cr.CuentaCliente 
                INNER JOIN frecuenciavisita AS fre ON fre.NumeroVisita=cr.NumeroVisita   
                WHERE cr.CodZonaVentas='" . $zonaVentas . "' AND (`R1`='" . $ruta . "' OR `R2`='" . $ruta . "' OR `R3`='" . $ruta . "' OR `R4`='" . $ruta . "');";
        $data = $db->ejecutar($squeryId);
        while ($rowNit = $db->obtener_fila($data, 0)) {

            array_push($nit, $rowNit['identificacion']);
        }


        $client = new nusoap_client("http://altipal.datosmovil.info/SM/WebServiceLogin.php?wsdl");
        $client->soap_defencoding = 'UTF-8';
        $err = $client->getError(); /*         * * Captura de errores ** */
        if ($err) {
            echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
            echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->getDebug(), ENT_QUOTES) . '</pre>';
            exit();
        }

        $args = array('value' => 'FACTURAS', 'datos' => $nit);
        $devolver = $client->call('facturas', array($args));

        return $devolver;
    }

    if ($value['value'] == 'DESCARGA_CLIENTES3') {
        $db = Db::getInstance();
        $zonaVentas = trim($value['zona']);
        $ruta = trim($value['ruta']);
        $fechaActual = date('Y-m-d');


        //Restrinccion Proveedor
        $restrinccion = array();
        $sqlRs = "SELECT rp.* FROM `restriccioncuentaproveedor` AS rp 
            INNER JOIN clienteruta AS cr ON cr.CuentaCliente=rp.CuentaCliente 
            INNER JOIN frecuenciavisita AS fre ON fre.NumeroVisita=cr.NumeroVisita 
            WHERE rp.CodZonaVentas='" . $zonaVentas . "' AND cr.CodZonaVentas='" . $zonaVentas . "' AND
            (`R1`='$ruta' OR `R2`='$ruta' OR `R3`='$ruta' OR `R4`='$ruta' ); ";
        $rs_cltesRs = $db->ejecutar($sqlRs);
        if ($rs_cltesRs) {
            while ($col_cltesRs = $db->obtener_fila($rs_cltesRs, 0)) {

                $json = array(
                    'Id' => $col_cltesRs['Id'],
                    'CuentaCliente' => $col_cltesRs['CuentaCliente'],
                    'CodZonaVentas' => $col_cltesRs['CodZonaVentas'],
                    'CuentaProveedor' => $col_cltesRs['CuentaProveedor'],
                    'TipoCuenta' => $col_cltesRs['TipoCuenta'],
                    'CodigoVariante' => $col_cltesRs['CodigoVariante'],
                    'CodigoArticulo' => $col_cltesRs['CodigoArticulo'],
                    'CodigoArticuloGrupoCategoria' => $col_cltesRs['CodigoArticuloGrupoCategoria'],
                    'Tipo' => $col_cltesRs['Tipo'],
                    'Caracteristica1' => $col_cltesRs['Caracteristica1'],
                    'Caracteristica2' => $col_cltesRs['Caracteristica2']
                );
                array_push($restrinccion, $json);
            }
        }


        $subArray = array('RestrinccionProveedor' => $restrinccion);

        return json_encode($subArray);
    }


    if ($value['value'] == 'DESCARGA_ACUERDOS_COMERCIAL') {
        $db = Db::getInstance();
        $zonaVentas = trim($value['zona']);
        $ruta = trim($value['ruta']);
        $inicio = trim($value['inicio']);
        $fin = trim($value['fin']);
        $posicion = $inicio;
        $fechaActual = date('Y-m-d');

        //Acuerdo Comercial
        $datosAcuerdo = array();
   /*     $sqlAc = "SELECT a.* FROM `acuerdoscomercialesprecioventa` AS a 
             INNER JOIN clienteruta AS cr ON (cr.CuentaCliente=a.CuentaCliente OR cr.CodigoGrupoPrecio = a.CodigoGrupoPrecio)
             INNER JOIN frecuenciavisita AS fre ON fre.NumeroVisita=cr.NumeroVisita
             WHERE cr.CodZonaVentas='" . $zonaVentas . "' AND
             (`R1`='$ruta' OR `R2`='$ruta' OR `R3`='$ruta' OR `R4`='$ruta') AND FechaInicio<>'0000-00-00' AND FechaInicio<='" . $fechaActual . "' AND (FechaTermina>='" . $fechaActual . "' OR FechaTermina='0000-00-00')
             GROUP BY a.Id
             ORDER BY `a`.`FechaInicio` DESC,a.PrecioVenta DESC LIMIT " . $inicio . "," . $fin . " ; ";*/
        
        $sqlAc = "SELECT a.* FROM `acuerdoscomercialesprecioventa` AS a 
             INNER JOIN clienteruta AS cr ON (cr.CuentaCliente=a.CuentaCliente OR cr.CodigoGrupoPrecio = a.CodigoGrupoPrecio)
             INNER JOIN frecuenciavisita AS fre ON fre.NumeroVisita=cr.NumeroVisita
             WHERE cr.CodZonaVentas='" . $zonaVentas . "' AND
             (`R1`='$ruta' OR `R2`='$ruta' OR `R3`='$ruta' OR `R4`='$ruta') AND FechaInicio<>'0000-00-00' AND FechaInicio<='" . $fechaActual . "' AND (FechaTermina>='" . $fechaActual . "' OR FechaTermina='0000-00-00')
             GROUP BY a.Id
             ORDER BY `a`.`FechaInicio` DESC,a.PrecioVenta DESC; ";

        $rs_cltesAc = $db->ejecutar($sqlAc);
        if ($rs_cltesAc) {
            $posicion =$inicio;
            while ($col_cltesAc = $db->obtener_fila($rs_cltesAc, 0)) {

                $json = array(
                    'Id' => $col_cltesAc['Id'],
                    'IdAcuerdoComercial' => $col_cltesAc['IdAcuerdoComercial'],
                    'TipoAcuerdo' => $col_cltesAc['TipoAcuerdo'],
                    'TipoCuentaCliente' => $col_cltesAc['TipoCuentaCliente'],
                    'CuentaCliente' => $col_cltesAc['CuentaCliente'],
                    'CodigoGrupoPrecio' => $col_cltesAc['CodigoGrupoPrecio'],
                    'CodigoVariante' => $col_cltesAc['CodigoVariante'],
                    'PrecioVenta' => $col_cltesAc['PrecioVenta'],
                    'CodigoUnidadMedida' => $col_cltesAc['CodigoUnidadMedida'],
                    'NombreUnidadMedida' => $col_cltesAc['NombreUnidadMedida'],
                    'CantidadDesde' => $col_cltesAc['CantidadDesde'],
                    'CantidadHasta' => $col_cltesAc['CantidadHasta'],
                    'FechaInicio' => $col_cltesAc['FechaInicio'],
                    'FechaTermina' => $col_cltesAc['FechaTermina'],
                    'Sitio' => $col_cltesAc['Sitio'],
                    'Almacen' => $col_cltesAc['Almacen'],
                    'Posicion' => $posicion
                );
                array_push($datosAcuerdo, $json);
                $posicion++;
            }
        }

        $subArray = array('AcuerdoComercial' => $datosAcuerdo);
        return json_encode($subArray);
    }



    if ($value['value'] == 'DESCARGA_ACUERDOS_MULTILINEA') {
        $db = Db::getInstance();
        $zonaVentas = trim($value['zona']);
        $ruta = trim($value['ruta']);
        $inicio = trim($value['inicio']);
        $fin = trim($value['fin']);
        $fechaActual = date('Y-m-d');

        //Acuerdo Comercial descuento Multi linea
        $datosAcuerdoMultiLinea = array();
        $sqlMulinea = "SELECT a.* FROM `acuerdoscomercialesdescuentomultilinea` AS a 
            INNER JOIN clienteruta AS cr ON (cr.CuentaCliente=a.CuentaCliente OR cr.CodigoGrupoDescuentoMultiLinea = a.CodigoGrupoClienteDescuentoMultilinea OR a.`TipoCuentaCliente` = '3') 
            INNER JOIN frecuenciavisita AS fre ON fre.NumeroVisita=cr.NumeroVisita 
            WHERE cr.CodZonaVentas='" . $zonaVentas . "' AND
            (`R1`='" . $ruta . "' OR `R2`='" . $ruta . "' OR `R3`='" . $ruta . "' OR `R4`='" . $ruta . "') AND FechaInicio<>'0000-00-00' AND FechaInicio<='" . $fechaActual . "' AND (FechaFinal>='" . $fechaActual . "' OR FechaFinal='0000-00-00')
                GROUP BY a.Id
            ORDER BY `a`.`FechaInicio` DESC,SUM(PorcentajeDescuentoMultilinea1+PorcentajeDescuentoMultilinea2) ASC ;";
        $rs_cltesMulinea = $db->ejecutar($sqlMulinea);
        if ($rs_cltesMulinea) {
            while ($col_cltesMulinea = $db->obtener_fila($rs_cltesMulinea, 0)) {

                $json = array(
                    'Id' => $col_cltesMulinea['Id'],
                    'IdAcuerdoComercial' => $col_cltesMulinea['IdAcuerdoComercial'],
                    'TipoAcuerdo' => $col_cltesMulinea['TipoAcuerdo'],
                    'TipoCuentaCliente' => $col_cltesMulinea['TipoCuentaCliente'],
                    'CuentaCliente' => $col_cltesMulinea['CuentaCliente'],
                    'CodigoGrupoClienteDescuentoMultilinea' => $col_cltesMulinea['CodigoGrupoClienteDescuentoMultilinea'],
                    'CodigoGrupoArticulosDescuentoMultilinea' => $col_cltesMulinea['CodigoGrupoArticulosDescuentoMultilinea'],
                    'PorcentajeDescuentoMultilinea1' => $col_cltesMulinea['PorcentajeDescuentoMultilinea1'],
                    'PorcentajeDescuentoMultilinea2' => $col_cltesMulinea['PorcentajeDescuentoMultilinea2'],
                    'CodigoUnidadMedida' => $col_cltesMulinea['CodigoUnidadMedida'],
                    'NombreUnidadMedida' => $col_cltesMulinea['NombreUnidadMedida'],
                    'CantidadDesde' => $col_cltesMulinea['CantidadDesde'],
                    'CantidadHasta' => $col_cltesMulinea['CantidadHasta'],
                    'FechaInicio' => $col_cltesMulinea['FechaInicio'],
                    'FechaFinal' => $col_cltesMulinea['FechaFinal'],
                    'Sitio' => $col_cltesMulinea['Sitio'],
                    'Almacen' => $col_cltesMulinea['Almacen']
                );
                array_push($datosAcuerdoMultiLinea, $json);
            }
        }

        $subArray = array('AcuerdoMultiLinea' => $datosAcuerdoMultiLinea);

        return json_encode($subArray);
    }

    if ($value['value'] == 'DESCARGA_CLIENTES7') {
        $db = Db::getInstance();
        $zonaVentas = trim($value['zona']);
        $ruta = trim($value['ruta']);
        $fechaActual = date('Y-m-d');

        //Localizacion
        $datosLocalizacion = array();
        $sqlLocali = "SELECT l.CodigoBarrio,l.NombreBarrio,l.CodigoLocalidad,l.NombreLocalidad,l.CodigoCiudad,l.NombreCiudad,l.CodigoDepartamento,l.NombreDepartamento,l.CodigoPais,l.NombrePais FROM `Localizacion` AS l INNER JOIN cliente AS c ON l.CodigoBarrio =c.CodigoBarrio GROUP BY c.CodigoBarrio;";
        $rsLocali = $db->ejecutar($sqlLocali);
        if ($rsLocali) {

            while ($row = $db->obtener_fila($rsLocali, 0)) {
                $json = array(
                    'CodigoBarrio' => $row['CodigoBarrio'],
                    'NombreBarrio' => $row['NombreBarrio'],
                    'CodigoLocalidad' => $row['CodigoLocalidad'],
                    'NombreLocalidad' => $row['NombreLocalidad'],
                    'CodigoCiudad' => $row['CodigoCiudad'],
                    'NombreCiudad' => $row['NombreCiudad'],
                    'CodigoDepartamento' => $row['CodigoDepartamento'],
                    'NombreDepartamento' => $row['NombreDepartamento'],
                    'CodigoPais' => $row['CodigoCiudad'],
                    'NombrePais' => $row['NombrePais']
                );
                array_push($datosLocalizacion, $json);
            }
        }



        //Preguntas Encuesta Segmentacion
        $datosPreguntasEncuesta = array();
        $sql_preguntas_encuesta = "SELECT `Id`, `IdTipoEncuesta`, `Descripcion`, `IdTipoCampo`, `IdEstado` FROM `preguntasencuesta` WHERE `IdTipoEncuesta`=1 AND  `IdEstado`=1";
        $rs_preguntas_encuesta = $db->ejecutar($sql_preguntas_encuesta);
        if ($rs_preguntas_encuesta) {

            while ($col_preguntas_encuesta = $db->obtener_fila($rs_preguntas_encuesta, 0)) {
                $json = array(
                    'Id' => $col_preguntas_encuesta['Id'],
                    'IdTipoEncuesta' => $col_preguntas_encuesta['IdTipoEncuesta'],
                    'Descripcion' => $col_preguntas_encuesta['Descripcion'],
                    'IdTipoCampo' => $col_preguntas_encuesta['IdTipoCampo'],
                    'IdEstado' => $col_preguntas_encuesta['IdEstado']
                );
                array_push($datosPreguntasEncuesta, $json);
            }
        }

        //Respuestas Encuesta Segmentacion
        $datosRespuestasEncuesta = array();
        $sql_respuestas_encuesta = "SELECT resp.`Id` as Id, `IdPreguntaEncuesta`, resp.`Descripcion` as Descripcion, `IdSiguientePregunta`, `IdCodigoSegmentacion`, TipoTexto FROM `respuestasencuesta`AS resp INNER JOIN preguntasencuesta AS preg ON resp.`IdPreguntaEncuesta`= preg.Id AND preg.IdTipoEncuesta=1";
        $rs_respuestas_encuesta = $db->ejecutar($sql_respuestas_encuesta);
        if ($rs_respuestas_encuesta) {
            while ($col_respuestas_encuesta = $db->obtener_fila($rs_respuestas_encuesta, 0)) {
                $json = array(
                    'Id' => $col_respuestas_encuesta['Id'],
                    'IdPreguntaEncuesta' => $col_respuestas_encuesta['IdPreguntaEncuesta'],
                    'Descripcion' => $col_respuestas_encuesta['Descripcion'],
                    'IdSiguientePregunta' => $col_respuestas_encuesta['IdSiguientePregunta'],
                    'IdCodigoSegmentacion' => $col_respuestas_encuesta['IdCodigoSegmentacion'],
                    'TipoTexto' => $col_respuestas_encuesta['TipoTexto']
                );
                array_push($datosRespuestasEncuesta, $json);
            }
        }

          $client = new nusoap_client("http://altipal.datosmovil.info/SM/WebServiceLogin.php?wsdl");
            $client->soap_defencoding = 'UTF-8';
            $err = $client->getError(); /*             * * Captura de errores ** */
            if ($err) {
                echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
                echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->getDebug(), ENT_QUOTES) . '</pre>';
                exit();
            }


            //Traemos los distintos clientes que tienen enrutados           
            
            $acumuladorCliente;
            $sqlclientesenrutados = "SELECT DISTINCT(CuentaCliente) as cliente FROM `clienteruta` WHERE CodZonaVentas = '$zonaVentas'";
            $rsclientesenrutados = $db->ejecutar($sqlclientesenrutados);
         
            while ($RowClientesEnrutados = $db->obtener_fila($rsclientesenrutados, 0)) {
                
                $acumuladorCliente .= $RowClientesEnrutados['cliente'].",";
            }
            
           
            $sql = "SELECT CodZonaVentas as cv,CodigoSitio,(SELECT CodigoGrupoVentas FROM `zonaventas` WHERE CodZonaVentas = cv) as CodigoGrupoVentas FROM `zonaventaalmacen` WHERE CodZonaVentas = '$zonaVentas'";
           
            $stmt = $db->ejecutar($sql);
            $resultado = $db->obtener_fila($stmt, 0);
            $CodigoSitio = $resultado['CodigoSitio'];
            $CodigoGrupoVentas = $resultado['CodigoGrupoVentas'];


            $args = array('value' => 'encuesta', 'zonaVentas' => $CodZonaVentas, 'CodigoSitio' => $CodigoSitio, 'CodigoGrupoVentas' => $CodigoGrupoVentas, 'acumuladoCliente' => $acumuladorCliente);
            $devolver = $client->call('encuesta', array($args));
            
            $datos = json_decode($devolver);          
           
            $datosPreguntasEncuestaDos = $datos->datosPreguntasEncuesta;
            $datosRespuestasEncuestaDos = $datos->datosRespuestaEncuesta;
            $tituloencuestaDos = $datos->datosEncuesta;
            $datosClientesEcuestas = $datos->datosClientesEcuestas;
            $datosClientesEcuestasAsignadas = $datos->datosClientesAsignarEcuestas;



            $client = new nusoap_client("http://altipal.datosmovil.info/SM/WebServiceLogin.php?wsdl");
            $client->soap_defencoding = 'UTF-8';
            $err = $client->getError(); /*             * * Captura de errores ** */
            if ($err) {
                echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
                echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->getDebug(), ENT_QUOTES) . '</pre>';
                exit();
            }

            $args = array('value' => 'semanafocalizados');
            $devolver = $client->call('semanafocalizados', array($args));

             $datos = json_decode($devolver);          
           
            $datosSemana = $datos->datosSemana;


        //Respuestas Encuesta Segmentacion
        $datosEncuestaSales = array();
        $sql_preguntas_sales = "SELECT * FROM `encuestaactivacionsalesdrivers` WHERE Estado = '1'";
        $rs_preguntas_sales = $db->ejecutar($sql_preguntas_sales);
        if ($rs_preguntas_sales) {
            while ($col_respuestas_encuesta = $db->obtener_fila($rs_preguntas_sales, 0)) {
                $json = array(
                    'Id' => $col_respuestas_encuesta['Id'],
                    'Pregunta' => $col_respuestas_encuesta['Descripcion']
                );
                array_push($datosEncuestaSales, $json);
            }
        }

        //preguntasevaluacion
         $rsLocali = $db->ejecutar("SET NAMES 'utf8'");
        $datospreguntasevaluacion = array();
        $sql_preguntas_sales = "SELECT * FROM `preguntasevaluacion`";
        $rs_preguntas_sales = $db->ejecutar($sql_preguntas_sales);
        if ($rs_preguntas_sales) {
            while ($col_respuestas_encuesta = $db->obtener_fila($rs_preguntas_sales, 0)) {
                $json = array(
                    'IdPregunta' => $col_respuestas_encuesta['IdPregunta'],
                    'ConsecutivoPregunta' => $col_respuestas_encuesta['ConsecutivoPregunta'],
                    'Encuesta' => $col_respuestas_encuesta['Encuesta'],
                    'Descripcion' => $col_respuestas_encuesta['Descripcion'],
                    'TipoPregunta' => $col_respuestas_encuesta['TipoPregunta'],
                    'SiguientePregunta' => $col_respuestas_encuesta['SiguientePregunta'],
                    'Tipo' => $col_respuestas_encuesta['Tipo'],
                    'Texto' => $col_respuestas_encuesta['Texto'],
                    'CampoNumerico' => $col_respuestas_encuesta['CampoNumerico'],
                    'GrupoPregunta' => $col_respuestas_encuesta['GrupoPregunta'],
                    'IdentificadorPregunta' => $col_respuestas_encuesta['IdentificadorPregunta']
                );
                array_push($datospreguntasevaluacion, $json);
            }
        }

        //planeacionsmart
         $rsLocali = $db->ejecutar("SET NAMES 'utf8'");
        $datosplaneacionsmart = array();
        $sql_preguntas_sales = "SELECT * FROM `planeacionsmart` WHERE CodZonaVentas = '$zonaVentas' AND FechaFin >= CURDATE() AND Cumplio = '0'";
      // return $sql_preguntas_sales;
        $rs_preguntas_sales = $db->ejecutar($sql_preguntas_sales);
        if ($rs_preguntas_sales) {
            while ($col_respuestas_encuesta = $db->obtener_fila($rs_preguntas_sales, 0)) {
                $json = array(
                    'IdPlaneacionSmart' => $col_respuestas_encuesta['IdPlaneacionSmart'],
                    'CuentaCliente' => $col_respuestas_encuesta['CuentaCliente'],
                    'Objetivo' => $col_respuestas_encuesta['Objetivo'],
                    'FechaInicio' => $col_respuestas_encuesta['FechaInicio'],
                    'FechaFin' => $col_respuestas_encuesta['FechaFin']
                );
                array_push($datosplaneacionsmart, $json);
            }
        }

         //planeacionsmart
        $rsLocali = $db->ejecutar("SET NAMES 'utf8'");
        $datossalesdrivers = array();
        $sql_preguntas_sales = "SELECT `Id`, `CodZonaVentas`, `CuentaCliente`, `CodigoVariante` as var, 
        `Precio`, `Inventario`, `Caras`, `Categoria`, `Fecha`, `Hora`, `Semana`, `IdPedido`, `ListaPrecio`, 
        `Sugerido`, `ValorPlan`, `Pedido`, `ValorReal`,(SELECT NombreArticulo FROM `portafolio` WHERE CodigoVariante = var LIMIT 1) as nombre,
        (SELECT CodigoMarca FROM `portafolio` WHERE CodigoVariante = var LIMIT 1) as marca FROM `salesdrivers` 
        WHERE `CodZonaVentas` = '$zonaVentas' AND MONTH(`Fecha`) = MONTH(curdate()) AND semana <> '2'";
      // return $sql_preguntas_sales;
        $rs_preguntas_sales = $db->ejecutar($sql_preguntas_sales);
        if ($rs_preguntas_sales) {
            while ($col_respuestas_encuesta = $db->obtener_fila($rs_preguntas_sales, 0)) {
                $json = array(
                    'Id' => $col_respuestas_encuesta['Id'],        
                    'CodZonaVentas' => $col_respuestas_encuesta['CodZonaVentas'],                    
                    'CuentaCliente' => $col_respuestas_encuesta['CuentaCliente'],                    
                    'CodigoVariante' => $col_respuestas_encuesta['var'],                    
                    'Precio' => $col_respuestas_encuesta['Precio'],                    
                    'Inventario' => $col_respuestas_encuesta['Inventario'],                    
                    'Caras' => $col_respuestas_encuesta['Caras'],                    
                    'Categoria' => $col_respuestas_encuesta['Categoria'],                    
                    'Fecha' => $col_respuestas_encuesta['Fecha'],                    
                    'Hora' => $col_respuestas_encuesta['Hora'],                    
                    'Semana' => $col_respuestas_encuesta['Semana'],                    
                    'IdPedido' => $col_respuestas_encuesta['IdPedido'],                    
                    'ListaPrecio' => $col_respuestas_encuesta['ListaPrecio'],                    
                    'Sugerido' => $col_respuestas_encuesta['Sugerido'],                    
                    'ValorPlan' => $col_respuestas_encuesta['ValorPlan'],                    
                    'Pedido' => $col_respuestas_encuesta['Pedido'],  
                    'ValorReal' => $col_respuestas_encuesta['ValorReal'],
                    'marca' => $col_respuestas_encuesta['marca'],
                    'nombre' => $col_respuestas_encuesta['nombre']
                );
                array_push($datossalesdrivers, $json);
            }
        }

          
        $subArray = array(
            'Localizacion' => $datosLocalizacion,
            'PreguntasEncuestaSegmentacionDos' => $datosPreguntasEncuestaDos,
            'RespuestasEncuestaSegmentacionDos' => $datosRespuestasEncuestaDos,
            'PreguntasEncuestaSegmentacion' => $datosPreguntasEncuesta,
            'RespuestasEncuestaSegmentacion' => $datosRespuestasEncuesta,
            'tituloencuestaDos' => $tituloencuestaDos,
            'datosClientesEcuestas' => $datosClientesEcuestas,
            'datosSemana' => $datosSemana,
            'datosEncuestaSales' => $datosEncuestaSales,
            'datospreguntasevaluacion' => $datospreguntasevaluacion,
            'planeacionsmart' => $datosplaneacionsmart,
            'datossalesdrivers' => $datossalesdrivers,
            'datosClientesEcuestasAsignadas' => $datosClientesEcuestasAsignadas);

        header("Content-type: application/json; charset=utf-8");
        return json_encode($subArray);
    }


    if ($value['value'] == 'DESCARGA_CLIENTES10') {
        $db = Db::getInstance();
        $zonaVentas = trim($value['zona']);
        $ruta = trim($value['ruta']);
        $inicio = trim($value['inicio']);
        $fin = trim($value['fin']);
        $posicion = $inicio;
        $fechaActual = date('Y-m-d');

        //Acuerdo Comercial descuento linea
        $datosAcuerdoLinea = array();
        /*$sqlAlinea = "SELECT a.* FROM `acuerdoscomercialesdescuentolinea` AS a 
            INNER JOIN clienteruta AS cr ON (cr.CuentaCliente=a.CuentaCliente OR cr.CodigoGrupoDescuentoLinea = a.CodigoClienteGrupoDescuentoLinea) 
            INNER JOIN frecuenciavisita AS fre ON fre.NumeroVisita=cr.NumeroVisita 
            WHERE cr.CodZonaVentas='" . $zonaVentas . "' AND
            (`R1`='$ruta' OR `R2`='$ruta' OR `R3`='$ruta' OR `R4`='$ruta') AND FechaInicio<>'0000-00-00' AND FechaInicio<='" . $fechaActual . "' AND (FechaFinal>='" . $fechaActual . "' OR FechaFinal='0000-00-00')  GROUP BY a.Id
            ORDER BY `a`.`FechaInicio` DESC,SUM(PorcentajeDescuentoLinea1+PorcentajeDescuentoLinea2) ASC; ";*/

             $sqlAlinea = "SELECT a.* FROM `acuerdoscomercialesdescuentolinea` AS a 
                       WHERE   FechaInicio<>'0000-00-00' AND FechaInicio<='" . $fechaActual . "' AND (FechaFinal>='" . $fechaActual . "' OR FechaFinal='0000-00-00')  GROUP BY a.Id
            ORDER BY `a`.`FechaInicio` DESC,SUM(PorcentajeDescuentoLinea1+PorcentajeDescuentoLinea2) ASC; ";
            
//       $sqlAlinea = "SELECT * FROM `acuerdoscomercialesdescuentolinea`  ORDER BY `Id` ASC";
        $rs_cltesAlinea = $db->ejecutar($sqlAlinea);
        if ($rs_cltesAlinea) {
            while ($col_cltesAlinea = $db->obtener_fila($rs_cltesAlinea, 0)) {

                $json = array(
                    'Id' => $col_cltesAlinea['Id'],
                    'IdAcuerdoComercial' => $col_cltesAlinea['IdAcuerdoComercial'],
                    'TipoAcuerdo' => $col_cltesAlinea['TipoAcuerdo'],
                    'TipoCuentaCliente' => $col_cltesAlinea['TipoCuentaCliente'],
                    'CuentaCliente' => trim($col_cltesAlinea['CuentaCliente']),
                    'CodigoClienteGrupoDescuentoLinea' => $col_cltesAlinea['CodigoClienteGrupoDescuentoLinea'],
                    'TipoCuentaArticulos' => $col_cltesAlinea['TipoCuentaArticulos'],
                    'CodigoVariante' => $col_cltesAlinea['CodigoVariante'],
                    'CodigoArticuloGrupoDescuentoLinea' => $col_cltesAlinea['CodigoArticuloGrupoDescuentoLinea'],
                    'PorcentajeDescuentoLinea1' => $col_cltesAlinea['PorcentajeDescuentoLinea1'],
                    'PorcentajeDescuentoLinea2' => $col_cltesAlinea['PorcentajeDescuentoLinea2'],
                    'CodigoUnidadMedida' => $col_cltesAlinea['CodigoUnidadMedida'],
                    'NombreUnidadMedida' => $col_cltesAlinea['NombreUnidadMedida'],
                    'CantidadDesde' => $col_cltesAlinea['CantidadDesde'],
                    'CantidadHasta' => $col_cltesAlinea['CantidadHasta'],
                    'FechaInicio' => $col_cltesAlinea['FechaInicio'],
                    'FechaFinal' => $col_cltesAlinea['FechaFinal'],
                    'LimiteVentas' => $col_cltesAlinea['LimiteVentas'],
                    'Saldo' => $col_cltesAlinea['Saldo'],
                    'Sitio' => $col_cltesAlinea['Sitio'],
                    'CodigoAlmacen' => $col_cltesAlinea['CodigoAlmacen'],
                    'PorcentajeAlerta' => $col_cltesAlinea['PorcentajeAlerta'],
                    'Posicion' => $posicion
                );
                array_push($datosAcuerdoLinea, $json);
                $posicion++;
            }
        }
        $subArray = array('AcuerdoLinea' => $datosAcuerdoLinea);
        return json_encode($subArray);
    }


    if ($value['value'] == 'DESCARGA_CLIENTES11') {
        $db = Db::getInstance();
        $zonaVentas = trim($value['zona']);
        $ruta = trim($value['ruta']);
        $fechaActual = date('Y-m-d');

        //PlaneacionSmart
        $datosClientes = array();
        $sql = "SELECT ps.`IdPlaneacionSmart`,ps.`CuentaCliente`,ps.`Objetivo`,ps.`FechaInicio`, ps.`FechaFin`, ps.`Cumplio`, ps.`MotivoNoCumplimiento` FROM
`frecuenciavisita` AS f
INNER JOIN clienteruta AS cr ON cr.NumeroVisita=f.NumeroVisita            
INNER JOIN planeacionsmart AS ps ON ps.CuentaCliente =  cr.CuentaCliente AND ps.CodZonaVentas = cr.CodZonaVentas 
WHERE cr.CodZonaVentas='" . $zonaVentas . "' AND MONTH(ps.FechaRegistro) = MONTH(CURDATE()) AND ps.Activas = '1' AND (`R1`='$ruta' OR `R2`='$ruta' OR `R3`='$ruta' OR `R4`='$ruta') 
GROUP BY ps.IdPlaneacionSmart;";
        $rs_cltes = $db->ejecutar($sql);
        if ($rs_cltes) {
            while ($col_cltes = $db->obtener_fila($rs_cltes, 0)) {
                $json = array(
                    'IdPlaneacion' => $col_cltes['IdPlaneacionSmart'],
                    'CuentaCliente' => $col_cltes['CuentaCliente'],
                    'Objetivo' => $col_cltes['Objetivo'],
                    'FechaInicio' => $col_cltes['FechaInicio'],
                    'FechaFin' => $col_cltes['FechaFin'],
                    'Cumplio' => $col_cltes['Cumplio'],
                    'MotivoNoCumplio' => $col_cltes['MotivoNoCumplimiento']);
                array_push($datosClientes, $json);
            }
        }
        $subArray = array('Planeacion' => $datosClientes);
        return json_encode($subArray);
    }


    if ($value['value'] == 'DESCARGA_CLIENTES12') {
        $db = Db::getInstance();
        $zonaVentas = trim($value['zona']);
        $ruta = trim($value['ruta']);
        $fechaActual = date('Y-m-d');

        //Multiplan
        $datosClientes = array();
        $sql = "SELECT m.`IdMultiplan`, m.`CuentaCliente`, m.`CodigoVariante`, m.`PrecioVentaPublico`, m.`Inventario`, m.`Caras`, m.`Categoria`, m.`Precio`, m.`Sugerido`, m.`ValorPlan`, m.`Pedido`, m.`ValorReal`, m.`Semana`, m.`IdPedido` FROM
`frecuenciavisita` AS f
INNER JOIN clienteruta AS cr ON cr.NumeroVisita=f.NumeroVisita            
INNER JOIN multiplan AS m ON cr.CuentaCliente = m.CuentaCliente
WHERE cr.CodZonaVentas='" . $zonaVentas . "' AND MONTH(m.Fecha) = MONTH(CURDATE()) AND (`R1`='$ruta' OR `R2`='$ruta' OR `R3`='$ruta' OR `R4`='$ruta') 
GROUP BY m.IdMultiplan;";
        $rs_cltes = $db->ejecutar($sql);
        if ($rs_cltes) {
            while ($col_cltes = $db->obtener_fila($rs_cltes, 0)) {

                $sql = "SELECT CodigoMarca,NombreArticulo FROM `portafolio` AS p INNER JOIN zonaventas AS z ON p.CodigoGrupoVentas=z.CodigoGrupoVentas WHERE CodigoVariante ='" . $col_cltes['CodigoVariante'] . "' AND z.CodZonaVentas ='" . $zonaVentas . "';";
                $stmt = $db->ejecutar($sql);
                $resultado = $db->obtener_fila($stmt, 0);
                $marca = $resultado['CodigoMarca'];
                $nombreArt = $resultado['NombreArticulo'];

                $json = array(
                    'IdMultiplan' => $col_cltes['IdMultiplan'],
                    'CuentaCliente' => $col_cltes['CuentaCliente'],
                    'CodigoVariante' => $col_cltes['CodigoVariante'],
                    'Marca' => $marca,
                    'Nombre' => $nombreArt,
                    'PrecioVentaPublico' => $col_cltes['PrecioVentaPublico'],
                    'Inventario' => $col_cltes['Inventario'],
                    'Caras' => $col_cltes['Caras'],
                    'Categoria' => $col_cltes['Categoria'],
                    'Precio' => $col_cltes['Precio'],
                    'Sugerido' => $col_cltes['Sugerido'],
                    'ValorPlan' => $col_cltes['ValorPlan'],
                    'Pedido' => $col_cltes['Pedido'],
                    'ValorReal' => $col_cltes['ValorReal'],
                    'Semana' => $col_cltes['Semana'],
                    'IdPedido' => $col_cltes['IdPedido']
                );
                array_push($datosClientes, $json);
            }
        }
        $subArray = array('Multiplan' => $datosClientes);
        return json_encode($subArray);
    }
}




/**
 * Metodo que me permite consumir otro servicio el cual se conecta a las bases de datos y verifica las facturas recaudadas para la fecha
 * @param String $value
 * @return Json
 * @soap
 */
function verificartransferencia($value) {

    if ($value['value'] == 'verificartransferencia') {
        try {
            $db = Db::getInstance();
           $zonaventas = $value['zonaVentas'];
            $sql = "SELECT COUNT(*) AS Conte FROM `transferenciaautoventa` WHERE CodZonaventasTransferencia = '$zonaventas' AND Estado = '0'";
                $stmt = $db->ejecutar($sql);
                $resultado = $db->obtener_fila($stmt, 0);
                $Conte = $resultado['Conte'];
               if($Conte == 0)
               {
                $devolver = "NO";
               }
               else
               {
                    $devolver = "SI";
               }

            return $devolver;
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
        }
    }



     if ($value['value'] == 'recibirtransferencia') {
        try {
            $db = Db::getInstance();
           $zonaventas = $value['zonaVentas'];
            






        $datosClientes = array();
        $sql = "SELECT * FROM `descripciontransferenciaautoventa` WHERE IdTransferenciaAutoventa In(SELECT DISTINCT(IdTransferenciaAutoventa) FROM `transferenciaautoventa` WHERE CodZonaventasTransferencia = '$zonaventas' AND Estado = '0')";
        $rs_cltes = $db->ejecutar($sql);
        if ($rs_cltes) {
            while ($col_cltes = $db->obtener_fila($rs_cltes, 0)) {

                $json = array(
                    'CodigoVariante' => $col_cltes['CodVariante'],
                    'CodigoArticulo' => $col_cltes['CodigoArticulo'],
                    'NombreArticulo' => $col_cltes['NombreArticulo'],
                    'CodigoUnidadMedida' => $col_cltes['CodigoUnidadMedida'],
                    'NombreUnidadMedida' => $col_cltes['NombreUnidadMedida'],
                    'Cantidad' => $col_cltes['Cantidad'],
                    'Lote' => $col_cltes['Lote'],
                    'PedidoMaquina' => $col_cltes['PedidoMaquina'],
                    'ValorUnitario' => $col_cltes['ValorUnitario'],
                    'TotalPrecioNeto' => $col_cltes['TotalPrecioNeto']
                );
                array_push($datosClientes, $json);
            }
        }

         $sqlAd = "UPDATE `transferenciaautoventa` SET `Estado`='1' WHERE CodZonaventasTransferencia='" . $zonaventas . "';";
                    $db->ejecutar($sqlAd);

        $subArray = array('datostransferencia' => $datosClientes);
        return json_encode($subArray);




        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
        }
    }
}



/**
 * Metodo que me permite consumir otro servicio el cual se conecta a las bases de datos y verifica las facturas recaudadas para la fecha
 * @param String $value
 * @return Json
 * @soap
 */
function facturasServer($value) {

    if ($value['value'] == 'FacturasRecaudos') {
        try {
            $manejador = fopen('Log/VN_ACTUALIZAR_RECAUDOS.txt', 'a+');
            fputs($manejador, $value['datos'] . "\n");
            fclose($manejador);


            $client = new nusoap_client("http://altipal.datosmovil.info/SM/WebServiceLogin.php?wsdl");
            $client->soap_defencoding = 'UTF-8';
            $err = $client->getError(); /*             * * Captura de errores ** */
            if ($err) {
                echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
                echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->getDebug(), ENT_QUOTES) . '</pre>';
                exit();
            }

            $args = array('value' => 'ACTUALIZAR', 'datos' => $value['datos']);
            $devolver = $client->call('actualizarRecaudos', array($args));

            return $devolver;
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
        }
    }
}

/**
 * Metodo que consultara los servicios de ax y de cifin para entregarle los datos correspondientes al cliente nuevo.
 * @param String $value
 * @return Json
 *  @soap
 */
function consultarClienteNuevo($value) {

    if ($value['value'] == 'consultarClienteNuevo') {
        try {
            $tipoDocumento = trim($value['tipoDocumento']);
            $documento = trim($value['documento']);

            $manejador = fopen('Log/CONSULTA _CLIENTE_NUEVO.txt', 'a+');
            fputs($manejador, "Tipo Documento: " . $tipoDocumento . "  DOCUMENTO: " . $documento . "\n");
            fclose($manejador);

            $client = new nusoap_client("http://altipal.datosmovil.info/SM/WebServiceLogin.php?wsdl");
            $client->soap_defencoding = 'UTF-8';
            $err = $client->getError(); /*             * * Captura de errores ** */
            if ($err) {
                echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
                echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->getDebug(), ENT_QUOTES) . '</pre>';
                exit();
            }

            $args = array('value' => 'CLIENTE_NUEVO', 'CodigoTipoDocumento' => $tipoDocumento, 'Identificador' => $documento);
            $devolver = $client->call('clienteNuevo', array($args));

            $manejador = fopen('Log/JSON_NEW.txt', 'a+');
            fputs($manejador, $devolver . "\n");
            fclose($manejador);


            return $devolver;
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
        }
    }
}

/**
 * Devuelve los datos al celular con los mensajes que tiene pendientes.
 * @param String $value
 * @return Json
 * @soap
 */
function mensajesServer($value) {
    $db = Db::getInstance();

    if ($value['value'] == 'mensajes') {
        try {
            $zonaVentas = trim($value['zonaVentas']);

            $datos = array();
            $sql = " SELECT m.`IdMensaje`, m.`IdDestinatario`,z.NombreZonadeVentas AS NombreDestinatario, m.`IdRemitente`,zn.Nombre AS NombreRemitente, m.`FechaMensaje`, m.`HoraMensaje`, m.`Mensaje` FROM `mensajes` AS m LEFT JOIN zonaventas AS z ON m.IdDestinatario=z.CodZonaVentas LEFT JOIN asesorescomerciales AS zn ON m.IdRemitente=zn.CodAsesor  WHERE m.`IdDestinatario`='" . $zonaVentas . "' AND m.`Estado` = '0'  ORDER BY m.`IdMensaje`; ";
            $rs_cltes = $db->ejecutar($sql);
            if ($rs_cltes) {

                while ($col_cltes = $db->obtener_fila($rs_cltes, 0)) {

                    $destinNombre = "N/N";
                    if ((empty($col_cltes['NombreRemitente'])) || ($col_cltes['NombreRemitente'] == null) || ($col_cltes['NombreRemitente'] == "null")) {
                        $client = new nusoap_client("http://altipal.datosmovil.info/SM/WebServiceLogin.php?wsdl");
                        $client->soap_defencoding = 'UTF-8';
                        $err = $client->getError(); /*                         * * Captura de errores ** */
                        if ($err) {
                            echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
                            echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->getDebug(), ENT_QUOTES) . '</pre>';
                            exit();
                        }

                        $args = array('value' => 'Administrador', 'cedula' => $col_cltes['IdRemitente']);
                        $destinNombre = $client->call('administrador', array($args));
                    } else {
                        $destinNombre = $col_cltes['NombreRemitente'];
                    }

                    $json = array(
                        'IdMensaje' => $col_cltes['IdMensaje'],
                        'IdDestinatario' => $col_cltes['IdDestinatario'],
                        'NombreDestinatario' => $col_cltes['NombreDestinatario'],
                        'IdRemitente' => $col_cltes['IdRemitente'],
                        'NombreRemitente' => $destinNombre,
                        'FechaMensaje' => $col_cltes['FechaMensaje'],
                        'HoraMensaje' => $col_cltes['HoraMensaje'],
                        'Mensaje' => $col_cltes['Mensaje']
                    );
                    array_push($datos, $json);
                    $update = "UPDATE  mensajes SET Estado='1' WHERE IdMensaje='" . $col_cltes['IdMensaje'] . "';";
                    $db->ejecutar($update);
                }
            }
            $subArray = array('Mensajes' => $datos);
            return json_encode($subArray);
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
        }
    }
}

/**
 * Devuelve los datos de las transacciones realizadas por cada una de las facturas.
 * @param String $value
 * @return Json
 * @soap
 */
function transaccionesFactura($value) {
    if ($value['value'] == 'DESCARGA_TRANSACCIONES') {
        try {
            $db = Db::getInstance();
            $cuentaCliente = trim($value['cuentaCliente']);
            $factura = trim($value['factura']);

            $manejador = fopen('Log/Datos Transacccion.txt', 'a+');
            fputs($manejador, "Cliente: " . $cuentaCliente . '  FACTURA:' . $factura . "\n");
            fclose($manejador);

            $datosTransaccion = array();
            //Transacciones
            $sql = "SELECT fd.NombreDocumento,fd.NumeroDocumento,fd.NombreConcepto,fd.ValorDocumento 
                    FROM `facturastransacciones` AS f 
                   INNER JOIN facturastransaccionesdetalle AS fd ON f.NumeroFactura = fd.IdFacturaTransacciones
                    WHERE f.NumeroFactura='" . $factura . "';";
            $rs_cltes = $db->ejecutar($sql);
            if ($rs_cltes) {
                while ($col_cltes = $db->obtener_fila($rs_cltes, 0)) {
                    $json = array(
                        'NombreDocumento' => $col_cltes['NombreDocumento'],
                        'NumeroDocumento' => $col_cltes['NumeroDocumento'],
                        'NombreConcepto' => $col_cltes['NombreConcepto'],
                        'ValorDocumento' => $col_cltes['ValorDocumento'],
                        'Origen' => 'ALTIPAL'
                    );
                    array_push($datosTransaccion, $json);
                }
            }

            //Recibos del dia
            $sql = "SELECT r.Id,rf.ValorAbono,IF(mo.Nombre IS NULL,'N/A',mo.Nombre) AS Nombre FROM reciboscaja AS r INNER JOIN reciboscajafacturas AS rf ON r.Id=rf.IdReciboCaja LEFT JOIN motivossaldo AS mo ON mo.CodMotivoSaldo = rf.CodMotivoSaldo WHERE rf.NumeroFactura='" . $factura . "' AND Fecha=CURDATE();";
            $rs_cltes = $db->ejecutar($sql);
            if ($rs_cltes) {
                while ($col_cltes = $db->obtener_fila($rs_cltes, 0)) {
                    $json = array(
                        'NombreDocumento' => 'Recibo Caja',
                        'NumeroDocumento' => $col_cltes['Id'],
                        'NombreConcepto' => $col_cltes['Nombre'],
                        'ValorDocumento' => $col_cltes['ValorAbono'],
                        'Origen' => 'ACTIVITY'
                    );
                    array_push($datosTransaccion, $json);
                }
            }

            //Notas Credito
            $sql = "SELECT `IdNotaCredito`,NombreConceptoNotaCredito,Valor FROM `notascredito`  AS n INNER JOIN conceptosnotacredito AS cn ON n.Concepto=cn.CodigoConceptoNotaCredito WHERE n.Factura='" . $factura . "' AND Fecha=CURDATE();";
            $rs_cltes = $db->ejecutar($sql);
            if ($rs_cltes) {
                while ($col_cltes = $db->obtener_fila($rs_cltes, 0)) {
                    $json = array(
                        'NombreDocumento' => 'Notas Credito',
                        'NumeroDocumento' => $col_cltes['IdNotaCredito'],
                        'NombreConcepto' => $col_cltes['NombreConceptoNotaCredito'],
                        'ValorDocumento' => $col_cltes['Valor'],
                        'Origen' => 'ACTIVITY'
                    );
                    array_push($datosTransaccion, $json);
                }
            }

            $subArray = array('Transaccion' => $datosTransaccion);
            return json_encode($subArray);
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
        }
    }
}

/**
 * Devuelve los asesores relacionados al cliente. 
 * @param String $value
 * @return Json
 * @soap
 */
function asesoresRelacion($value) {

    if ($value['value'] == 'ASESORES_RELACIONADOS') {
        try {
            $db = Db::getInstance();
            $zonaVentas = trim($value['zonaVentas']);
            $cuentaCliente = trim($value['cuentaCliente']);

            //Asesores
            $datosTransaccion = array();
            $sql = "SELECT cr.CodZonaVentas,a.nombre,z.NombreZonadeVentas FROM `clienteruta` AS cr 
                    INNER JOIN zonaventas AS z ON cr.CodZonaVentas=z.CodZonaVentas 
                    INNER JOIN asesorescomerciales AS a ON a.CodAsesor=z.CodAsesor 
                    WHERE cr.CuentaCliente='" . $cuentaCliente . "' GROUP BY cr.CodZonaVentas; ";
            $rs_cltes = $db->ejecutar($sql);
            if ($rs_cltes) {

                while ($col_cltes = $db->obtener_fila($rs_cltes, 0)) {
                    $json = array(
                        'zona_ventas' => $col_cltes['CodZonaVentas'],
                        'nombre' => $col_cltes['nombre'],
                        'nombre_zona' => $col_cltes['NombreZonadeVentas']
                    );
                    array_push($datosTransaccion, $json);
                }
            }
            $subArray = array('AsesoresRelacion' => $datosTransaccion);
            return json_encode($subArray);
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
        }
    }
}

/**
 * Devuelve si se actualiza o no. 
 * @param String $value
 * @return Json
 * @soap
 */
function verificarFechaActualizacion($value) {

    if ($value['value'] == 'verificarFechaActualizacion') {
        try {
            $db = Db::getInstance();
            $zonaVentas = trim($value['zonaVentas']);
            $fechaActualizacion = trim($value['fechaActualizacion']);
            $horaActualizacion = trim($value['horaActualizacion']);

            $respuesta ='OK'; 
            $sqlwes = "SELECT `FechaComparacion`,`HoraComparacion` FROM `fechaactualizaciones` WHERE `CodZonaVentas`='" . $zonaVentas . "' ORDER BY `Id` DESC;";
            $st = $db->ejecutar($sqlwes);
            $result = $db->obtener_fila($st, 0);
            $fechaActualizacionServidor = $result['FechaComparacion'];
            $horaActualizacionServidor = $result['HoraComparacion'];

            $fechaTotalActualizacion = $fechaActualizacion . " " . $horaActualizacion;
            $fechaTotalActualizacionServidor = $fechaActualizacionServidor . " " . $horaActualizacionServidor;

            if (date($fechaTotalActualizacion) >= date($fechaTotalActualizacionServidor)) {
                
                $respuesta = 'OK';
            
                
            } else {
                $respuesta = 'Actualizar';
                
            }
            return $respuesta;
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
        }
    }
}


/**
 * Verifica conexion.
 * @param string $value
 * @return string
 * @soap
 */
function conexionServer($value) {
    if ($value['value'] == 'conexion') {
        try {
            return 'OK';
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
        }
    }
}

/**
 * Metodo que me permite descargar las zonas a las cuales les aplicara la transferencia.
 * @param string $value
 * @return Json
 * @soap
 */
function relacionTranfereciaAutoventa($value) {
    if ($value['value'] == 'relacionTransferenciaAutoventa') {
        try {
            $db = Db::getInstance();
            $usuario = trim($value['datos']);
            $agencia = trim($value['agencia']);
            $grupo_ventas = trim($value['grupoVentas']);

            $sql_zonas = "SELECT a.CodZonaVentas as CodZonaVentas, `NombreZonadeVentas`,a.CodigoUbicacion, a.CupoLimiteAutoventa,(SELECT SUM(ValorPedido) AS ValorVentasDia FROM `pedidos` WHERE CodZonaVentas = a.CodZonaVentas AND HoraTerminacion = '00:00:00' AND FechaTerminacion = '0000-00-00') as ventasDia FROM zonaventas as z INNER JOIN zonaventaalmacen as a ON z.`CodZonaVentas`=a.`CodZonaVentas` AND Agencia='" . $agencia . "' AND CodigoGrupoVentas='" . $grupo_ventas . "' AND a.CodZonaVentas<>'" . $usuario . "' ; ";
            $rs_zonas = $db->ejecutar($sql_zonas);
            $datosZonasTransferenciaAutoventa = array();
            while ($colZonas = $db->obtener_fila($rs_zonas, 0)) {
                
                if($colZonas["ventasDia"] > 0)
                {
                    $cupo = 0;
                    if($colZonas["ventasDia"] > $colZonas["CupoLimiteAutoventa"])
                    {
                        $cupo = $colZonas["CupoLimiteAutoventa"];
                    }
                    else
                    {
                        $cupo = $colZonas["ventasDia"];
                    }
                    
                    $sqlSuma = "SELECT SUM(TotalTransferencia) as Suma FROM `transferenciaautoventa` WHERE CodZonaVentasTransferencia = '".$colZonas["CodZonaVentas"]."' AND FechaTerminacion = '0000-00-00' AND HoraTerminacion = '00:00:00'";
                        $sqlSuma = $db->ejecutar($sqlSuma);
                        $sqlSuma = $db->obtener_fila($sqlSuma, 0);
                        $sqlSuma = $sqlSuma['Suma'];
                        $cupo = $cupo - $sqlSuma;
                        if($cupo < 0)
                        {
                            $cupo = 0;
                        }
                    $json = array(          
                            'Codigo' => $colZonas["CodZonaVentas"],
                            'Nombre' => $colZonas["NombreZonadeVentas"],
                            'CodigoUbicacion' => $colZonas["CodigoUbicacion"],
                            'Cupo' => $cupo
                    );
                    array_push($datosZonasTransferenciaAutoventa, $json);
                }
            }

            $subArray = array('Zonas' => $datosZonasTransferenciaAutoventa);

            return json_encode($subArray);
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
        }
    }
}

/**
 * Metodo que se encargara de consultar los datos de extra ruta.
 * @param String $value
 * @return Json
 */
function downloadExtra($value) {
    $db = Db::getInstance();

    if ($value['value'] == 'ExtraRuta') {
        try {
            $zonaVentas = trim($value['zonaVentas']);
            $id = trim($value['id']);
            $parametro = trim($value['parametro']);
            $ruta = trim($value['ruta']);
            $fechaActual = date('Y-m-d');

            if ($id == "1") {
                $campo = "c.NombreCliente";
            }
            if ($id == "2") {
                $campo = "c.NombreBusqueda";
            }
            if ($id == "3") {
                $campo = "cr.CuentaCliente";
            }
            /* if ($id == "4") {
              $campo = "IdEstablecimiento";
              } */
            if ($id == "6") {
                $campo = "c.Identificacion";
            }

            //Clientes
            $datosClientes = array();
            $sql = "SELECT 
            f.NumeroVisita,
            f.CodFrecuencia,
            f.R1,
            f.R2,
            f.R3,
            f.R4,
            cr.IdClienteRuta,
            cr.CodZonaVentas,
            cr.CuentaCliente,
            cr.Posicion,
            cr.CodigoZonaLogistica,
            zl.NombreZonaLogistica,
            cr.ValorCupo,
            cr.ValorCupoTemporal,
            cr.SaldoCupo,
            c.Identificacion,
            c.NombreCliente,
            c.NombreBusqueda,
            c.DireccionEntrega,
            c.Telefono,
            c.TelefonoMovil,
            c.CorreoElectronico,
            c.Estado,
            c.CodigoCadenaEmpresa,
            cd.Nombre AS NombreCadenaEmpresa,
            cd.ValorMinimo,
            cd.CodSubSegmento,
            sg.Nombre AS NombreSubsegmento,
            sg.CodSegmento,
            sgt.Nombre AS NombreSegmento,
            cr.CodigoCondicionPago,
            cp.Descripcion AS DescripcionCondicionPago,
            cp.Dias,
            cr.CodigoFormadePago,
            fp.Descripcion AS DescripcionFormaPago,
            fp.CuentaPuente,
            c.CodigoBarrio,
            lo.NombreBarrio AS NombreBarrio,
            lo.CodigoLocalidad AS CodigoLocalidad,
            lo.NombreLocalidad AS NombreLocalidad,
            lo.CodigoCiudad AS CodigoCiudad,
            lo.NombreCiudad AS NombreCiudad,
            lo.CodigoDepartamento AS CodigoDepartamento,
            lo.NombreDepartamento AS NombreDepartamento,
            c.CodigoPostal,
            c.Latitud,
            c.Longitud,
            cr.CodigoGrupodeImpuestos,
            gi.NombreGrupoImpuestos,
            gi.CodigoTipoContribuyente,
            gi.NombreTipoContribuyente,
            gi.CodigoDepartamento AS CodigoDepartamentoImpuesto,
            gi.NombreDepartamento AS NombreDepartamentoImpuesto,
            gi.CodigoCiudad AS CodigoCiudadImpuesto,
            gi.NombreCiudad AS NombreCiudadImpuesto,
            cr.CodigoGrupoPrecio,
            gp.NombreGrupodePrecio,
            cr.CodigoGrupoDescuentoLinea,
            gdl.NombreGrupoDescuentoLinea,
            cr.CodigoGrupoDescuentoMultiLinea,
            gdml.NombreGrupoDescuentoMultiLinea,
             cr.DiasGracia,
            cr.DiasAdicionales
            FROM 
            `frecuenciavisita` f
            INNER JOIN clienteruta  cr ON cr.NumeroVisita=f.NumeroVisita            
            INNER JOIN cliente  c ON c.CuentaCliente=cr.CuentaCliente
            INNER JOIN zonaventas  z ON cr.`CodZonaVentas`=z.`CodZonaVentas`
            LEFT JOIN zonalogistica zl ON zl.CodZonaLogistica=cr.CodigoZonaLogistica
            LEFT JOIN cadenaempresa cd ON cd.CodigoCadenaEmpresa=c.CodigoCadenaEmpresa
            LEFT JOIN subsegmento sg ON sg.CodSubSegmento=cd.CodSubSegmento
            LEFT JOIN segmentos sgt ON sgt.CodSegmento=sg.CodSegmento
            LEFT JOIN condicionespago cp ON cp.CodigoCondicionPago=cr.CodigoCondicionPago
            LEFT JOIN formaspago fp ON fp.CodigoFormadePago=cr.CodigoFormadePago
            LEFT JOIN Localizacion lo ON lo.CodigoBarrio = c.CodigoBarrio
            LEFT JOIN grupoimpuestos gi ON gi.CodigoGrupoImpuestos=cr.CodigoGrupodeImpuestos
            LEFT JOIN grupodeprecios gp ON gp.CodigoGrupoPrecio=cr.CodigoGrupoPrecio
            LEFT JOIN grupodedescuentodelinea gdl ON gdl.CodigoGrupoDescuentoLinea=cr.CodigoGrupoDescuentoLinea
            LEFT JOIN grupodedescuentodemultilinea gdml ON gdml.CodigoGrupoDescuentoMultiLinea=cr.CodigoGrupoDescuentoMultiLinea
            WHERE cr.CodZonaVentas='$zonaVentas' AND $campo LIKE '%$parametro%' 
                AND (`R1`<>'$ruta' AND `R2`<>'$ruta' AND `R3`<>'$ruta' AND `R4`<>'$ruta') GROUP BY cr.CuentaCliente;";
            $rs_cltes = $db->ejecutar($sql);
            if ($rs_cltes) {
                while ($col_cltes = $db->obtener_fila($rs_cltes, 0)) {

                    $DescripcionFormaPago = trim($col_cltes['DescripcionFormaPago']);
                    if (($DescripcionFormaPago == "NULL") || ($DescripcionFormaPago == "null")) {
                        $DescripcionFormaPago = "";
                    }

                    $sqlSaldoFavor = "SELECT ABS(SUM(`SaldoFactura`)) AS saldo FROM `facturasaldo` WHERE `CuentaCliente`='" . $col_cltes['CuentaCliente'] . "' AND `SaldoFactura` < 0;";
                    $stFavor = $db->ejecutar($sqlSaldoFavor);
                    $resu = $db->obtener_fila($stFavor, 0);
                    $saldoFavor = $resu['saldo'];

                    if (empty($saldoFavor) || is_null($saldoFavor)) {
                        $saldoFavor = '0';
                    }

                    $json = array(
                        'NumeroVisita' => $col_cltes['NumeroVisita'],
                        'CodFrecuencia' => $col_cltes['CodFrecuencia'],
                        'R1' => $col_cltes['R1'],
                        'R2' => $col_cltes['R2'],
                        'R3' => $col_cltes['R3'],
                        'R4' => $col_cltes['R4'],
                        'IdClienteRuta' => $col_cltes['IdClienteRuta'],
                        'CodZonaVentas' => $col_cltes['CodZonaVentas'],
                        'CuentaCliente' => $col_cltes['CuentaCliente'],
                        'Posicion' => $col_cltes['Posicion'],
                        'CodigoZonaLogistica' => $col_cltes['CodigoZonaLogistica'],
                        'NombreZonaLogistica' => $col_cltes['NombreZonaLogistica'],
                        'ValorCupo' => $col_cltes['ValorCupo'],
                        'ValorCupoTemporal' => $col_cltes['ValorCupoTemporal'],
                        'SaldoCupo' => vacio($col_cltes['SaldoCupo']),
                        'Identificacion' => $col_cltes['Identificacion'],
                        'NombreCliente' => $col_cltes['NombreCliente'],
                        'NombreBusqueda' => $col_cltes['NombreBusqueda'],
                        'DireccionEntrega' => $col_cltes['DireccionEntrega'],
                        'Telefono' => $col_cltes['Telefono'],
                        'TelefonoMovil' => vacio($col_cltes['TelefonoMovil']),
                        'CorreoElectronico' => $col_cltes['CorreoElectronico'],
                        'Estado' => $col_cltes['Estado'],
                        'CodigoCadenaEmpresa' => $col_cltes['CodigoCadenaEmpresa'],
                        'NombreCadenaEmpresa' => vacio($col_cltes['NombreCadenaEmpresa']),
                        'ValorMinimo' => $col_cltes['ValorMinimo'],
                        'CodSubSegmento' => $col_cltes['CodSubSegmento'],
                        'NombreSubsegmento' => $col_cltes['NombreSubsegmento'],
                        'CodSegmento' => $col_cltes['CodSegmento'],
                        'NombreSegmento' => $col_cltes['NombreSegmento'],
                        'CodigoCondicionPago' => $col_cltes['CodigoCondicionPago'],
                        'DescripcionCondicionPago' => $col_cltes['DescripcionCondicionPago'],
                        'Dias' => vacio($col_cltes['Dias']),
                        'CodigoFormadePago' => $col_cltes['CodigoFormadePago'],
                        'DescripcionFormaPago' => $DescripcionFormaPago,
                        'CuentaPuente' => $col_cltes['CuentaPuente'],
                        'CodigoBarrio' => $col_cltes['CodigoBarrio'],
                        'NombreBarrio' => $col_cltes['NombreBarrio'],
                        'CodigoLocalidad' => $col_cltes['CodigoLocalidad'],
                        'NombreLocalidad' => $col_cltes['NombreLocalidad'],
                        'CodigoCiudad' => $col_cltes['CodigoCiudad'],
                        'NombreCiudad' => $col_cltes['NombreCiudad'],
                        'CodigoDepartamento' => $col_cltes['CodigoDepartamento'],
                        'NombreDepartamento' => $col_cltes['NombreDepartamento'],
                        'CodigoPostal' => $col_cltes['CodigoPostal'],
                        'Latitud' => $col_cltes['Latitud'],
                        'Longitud' => $col_cltes['Longitud'],
                        'CodigoGrupodeImpuestos' => $col_cltes['CodigoGrupodeImpuestos'],
                        'NombreGrupoImpuestos' => $col_cltes['NombreGrupoImpuestos'],
                        'CodigoTipoContribuyente' => $col_cltes['CodigoTipoContribuyente'],
                        'NombreTipoContribuyente' => $col_cltes['NombreTipoContribuyente'],
                        'CodigoDepartamentoImpuesto' => $col_cltes['CodigoDepartamentoImpuesto'],
                        'NombreDepartamentoImpuesto' => $col_cltes['NombreDepartamentoImpuesto'],
                        'CodigoCiudadImpuesto' => $col_cltes['CodigoCiudadImpuesto'],
                        'NombreCiudadImpuesto' => $col_cltes['NombreCiudadImpuesto'],
                        'CodigoGrupoPrecio' => $col_cltes['CodigoGrupoPrecio'],
                        'NombreGrupodePrecio' => $col_cltes['NombreGrupodePrecio'],
                        'CodigoGrupoDescuentoLinea' => $col_cltes['CodigoGrupoDescuentoLinea'],
                        'NombreGrupoDescuentoLinea' => $col_cltes['NombreGrupoDescuentoLinea'],
                        'CodigoGrupoDescuentoMultiLinea' => $col_cltes['CodigoGrupoDescuentoMultiLinea'],
                        'NombreGrupoDescuentoMultiLinea' => $col_cltes['NombreGrupoDescuentoMultiLinea'],
                        'SaldoFavor' => $saldoFavor,
                        'DiasGracia' => $col_cltes['DiasGracia'],
                        'DiasAdicionales' => $col_cltes['DiasAdicionales']);
                    array_push($datosClientes, $json);
                }
            }

            $subArray = array('Clientes' => $datosClientes);

            return json_encode($subArray);
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
        }
    }



    if ($value['value'] == 'ExtraRuta2') {
        try {

            $zonaVentas = trim($value['zonaVentas']);           
            $cuentaCliente = trim($value['cuentaCliente']);

            $fechaActual = date('Y-m-d');

            $datosFactura = array();
            $datosFacturaDetalle = array();
            $restrinccion = array();
            $datosAcuerdo = array();
            $datos = array();
            $datosAcuerdoMultiLinea = array();
            $datosAcuerdoLinea =  array();

            $nit = array();
            $squeryId = "SELECT DISTINCT(c.Identificacion) AS identificacion 
                FROM `cliente` AS c 
                INNER JOIN clienteruta AS cr ON c.CuentaCliente = cr.CuentaCliente 
                INNER JOIN frecuenciavisita AS fre ON fre.NumeroVisita=cr.NumeroVisita   
                WHERE cr.CuentaCliente ='" . $cuentaCliente . "';";

            $data = $db->ejecutar($squeryId);
            while ($rowNit = $db->obtener_fila($data, 0)) {

                array_push($nit, $rowNit['identificacion']);
            }

            foreach ($nit as $item) {

                //Facturas
                $sqlFacturas = "SELECT f.Id,f.NumeroFactura,f.CuentaCliente,f.FechaFactura,f.ValorNetoFactura,f.CodigoCondicionPago,cond.Dias,f.DtoProntoPagoNivel1,f.FechaDtoProntoPagoNivel1,f.DtoProntoPagoNivel2,f.FechaDtoProntoPagoNivel2,f.SaldoFactura,f.CodigoZonaVentas,f.CedulaAsesorComercial,f.FechaVencimientoFactura,
            fd.Id AS IdDetalle,fd.NumeroFactura AS NumeroFacturaDetalle,fd.CodigoVariante,fd.CodigoArticulo,fd.Caracteristica1,fd.Caracteristica2,fd.CodigoTipo,fd.CodigoUnidadMedida,fd.NombreUnidadMedida,fd.ValorNetoArticulo,fd.CuentaProveedor,fd.DescuentoPPNivel1,fd.DescuentoPPNivel2,fd.CantidadFacturada 
            FROM facturasaldo AS f 
            INNER JOIN clienteruta AS cr ON f.CuentaCliente = cr.CuentaCliente 
            INNER JOIN cliente AS c ON cr.CuentaCliente = c.CuentaCliente 
            LEFT JOIN facturasaldodetalle AS fd ON f.NumeroFactura=fd.NumeroFactura  
            LEFT JOIN condicionespago AS cond ON cond.CodigoCondicionPago=f.CodigoCondicionPago 
            WHERE c.Identificacion='" . $item . "' AND f.SaldoFactura>0 GROUP BY fd.Id ;";
                $rs_cltesFacturas = $db->ejecutar($sqlFacturas);
                if ($rs_cltesFacturas) {
                    while ($col_cltes = $db->obtener_fila($rs_cltesFacturas, 0)) {

                        $estadoVencida = '0';
                        if ($fechaActual <= $col_cltes['FechaVencimientoFactura']) {
                            $estadoVencida = '0';
                        } else {
                            $estadoVencida = '1';
                        }

                        $diasVencidos = "0";
                        $diasAVencer = "0";
                        if ($estadoVencida == '1') {
                            $diasVencidos = diff_dte($fechaActual, $col_cltes['FechaVencimientoFactura']);
                            $diasAVencer = '0';
                        } else {
                            $diasVencidos = '0';
                            $diasAVencer = diff_dte($fechaActual, $col_cltes['FechaVencimientoFactura']);
                        }

                        if ($col_cltes['FechaDtoProntoPagoNivel1'] != "0000-00-00") {
                            $diasPP1 = diff_dte($col_cltes['FechaFactura'], $col_cltes['FechaDtoProntoPagoNivel1']);
                        } else {
                            $diasPP1 = "0";
                        }

                        if ($col_cltes['FechaDtoProntoPagoNivel2'] != "0000-00-00") {
                            $diasPP2 = diff_dte($col_cltes['FechaFactura'], $col_cltes['FechaDtoProntoPagoNivel2']);
                        } else {
                            $diasPP2 = "0";
                        }

                        $sqlZona = "SELECT CONCAT( z.NombreZonadeVentas,' (',z.CodZonaVentas,')') AS zonaVentas,a.Nombre,CONCAT(g.NombreGrupoVentas,' (',z.CodigoGrupoVentas,')') AS grupoVentas,a.TelefonoMovilEmpresarial FROM `zonaventas` AS z INNER JOIN asesorescomerciales AS a ON z.CodAsesor=a.CodAsesor LEFT JOIN gruposventas AS g ON z.CodigoGrupoVentas=g.CodigoGrupoVentas WHERE z.CodZonaVentas='" . $col_cltes['CodigoZonaVentas'] . "';";
                        $stmtZona = $db->ejecutar($sqlZona);
                        $resultadoZona = $db->obtener_fila($stmtZona, 0);

                        if (!empty($resultadoZona['zonaVentas'])) {
                            $zonaVentasFa = $resultadoZona['zonaVentas'];
                            $Nombre = $resultadoZona['Nombre'];
                            $GrupoVentas = $resultadoZona['grupoVentas'];
                            $TelefonoMovilEmpresarial = $resultadoZona['TelefonoMovilEmpresarial'];
                        } else {
                            $zonaVentasFa = "Sin informacion de la zona(" . $col_cltes['CodigoZonaVentas'] . ")";
                            $Nombre = "Sin informacion de la zona";
                            $GrupoVentas = "Sin informacion de la zona";
                            $TelefonoMovilEmpresarial = "Sin informacion de la zona";
                        }

                        $json = array(
                            'Id' => $col_cltes['Id'],
                            'NumeroFactura' => $col_cltes['NumeroFactura'],
                            'CuentaCliente' => $col_cltes['CuentaCliente'],
                            'FechaFactura' => $col_cltes['FechaFactura'],
                            'ValorNetoFactura' => ceil($col_cltes['ValorNetoFactura']),
                            'CodigoCondicionPago' => $col_cltes['CodigoCondicionPago'],
                            'Dias' => $col_cltes['Dias'],
                            'DtoProntPagoNivel1' => ceil($col_cltes['DtoProntoPagoNivel1']),
                            'FechaDtoProntoPagoNivel1' => $col_cltes['FechaDtoProntoPagoNivel1'],
                            'DtoProntoPagoNivel2' => ceil($col_cltes['DtoProntoPagoNivel2']),
                            'FechaDtoProntoPagoNivel2' => $col_cltes['FechaDtoProntoPagoNivel2'],
                            'SaldoFactura' => ceil($col_cltes['SaldoFactura']),
                            'CodigoZonaVentas' => $col_cltes['CodigoZonaVentas'],
                            'CedulaAsesorComercial' => $col_cltes['CedulaAsesorComercial'],
                            'FechaVencimientoFactura' => $col_cltes['FechaVencimientoFactura'],
                            'EstadoVencida' => $estadoVencida,
                            'DiasVencido' => $diasVencidos,
                            'DiasAVencer' => $diasAVencer,
                            'DiasPP1' => $diasPP1,
                            'DiasPP2' => $diasPP2,
                            'ZonaVentas' => $zonaVentasFa,
                            'Nombre' => $Nombre,
                            'GrupoVentas' => $GrupoVentas,
                            'TelefonoMovilEmpresarial' => $TelefonoMovilEmpresarial,
                            'EstadoBloqueado' => estadoVencidoCliente($col_cltes['CuentaCliente'], $zonaVentas, $col_cltes['NumeroFactura']),
                            'FechaActual' => $fechaActual,
                            'IdentificacionCliente' => $item
                        );
                        array_push($datosFactura, $json);


                        $jsonDetalle = array(
                            'IdDetalle' => $col_cltes['IdDetalle'],
                            'NumeroFacturaDetalle' => $col_cltes['NumeroFacturaDetalle'],
                            'CodigoVariante' => $col_cltes['CodigoVariante'],
                            'CodigoArticulo' => $col_cltes['CodigoArticulo'],
                            'Caracteristica1' => $col_cltes['Caracteristica1'],
                            'Caracteristica2' => $col_cltes['Caracteristica2'],
                            'CodigoTipo' => $col_cltes['CodigoTipo'],
                            'CodigoUnidadMedida' => $col_cltes['CodigoUnidadMedida'],
                            'NombreUnidadMedida' => $col_cltes['NombreUnidadMedida'],
                            'ValorNetoArticulo' => ceil($col_cltes['ValorNetoArticulo']),
                            'CuentaProveedor' => $col_cltes['CuentaProveedor'],
                            'DescuentoPPNivel1' => $col_cltes['DescuentoPPNivel1'],
                            'DescuentoPPNivel2' => $col_cltes['DescuentoPPNivel2'],
                            'CantidadFacturada' => $col_cltes['CantidadFacturada']
                        );
                        array_push($datosFacturaDetalle, $jsonDetalle);
                    }
                }
            }

            //Restrinccion Proveedor
            $sqlRs = "SELECT rp.* FROM `restriccioncuentaproveedor` AS rp 
            INNER JOIN clienteruta AS cr ON cr.CuentaCliente=rp.CuentaCliente 
            INNER JOIN frecuenciavisita AS fre ON fre.NumeroVisita=cr.NumeroVisita 
            WHERE rp.CodZonaVentas='" . $zonaVentas . "' AND cr.CuentaCliente='" . $cuentaCliente . "'; ";
            $rs_cltesRs = $db->ejecutar($sqlRs);
            if ($rs_cltesRs) {
                while ($col_cltesRs = $db->obtener_fila($rs_cltesRs, 0)) {

                    $json = array(
                        'Id' => $col_cltesRs['Id'],
                        'CuentaCliente' => $col_cltesRs['CuentaCliente'],
                        'CodZonaVentas' => $col_cltesRs['CodZonaVentas'],
                        'CuentaProveedor' => $col_cltesRs['CuentaProveedor'],
                        'TipoCuenta' => $col_cltesRs['TipoCuenta'],
                        'CodigoVariante' => $col_cltesRs['CodigoVariante'],
                        'CodigoArticulo' => $col_cltesRs['CodigoArticulo'],
                        'CodigoArticuloGrupoCategoria' => $col_cltesRs['CodigoArticuloGrupoCategoria'],
                        'Tipo' => $col_cltesRs['Tipo'],
                        'Caracteristica1' => $col_cltesRs['Caracteristica1'],
                        'Caracteristica2' => $col_cltesRs['Caracteristica2']
                    );
                    array_push($restrinccion, $json);
                }
            }

            //Acuerdo Comercial
            $sqlAc = "SELECT a.* FROM `acuerdoscomercialesprecioventa` AS a 
            INNER JOIN clienteruta AS cr ON (cr.CuentaCliente=a.CuentaCliente OR cr.CodigoGrupoPrecio = a.CodigoGrupoPrecio) 
            INNER JOIN frecuenciavisita AS fre ON fre.NumeroVisita=cr.NumeroVisita 
            WHERE cr.CodZonaVentas='" . $zonaVentas . "' AND cr.CuentaCliente='" . $cuentaCliente . "' AND FechaInicio<='" . $fechaActual . "' AND (FechaTermina>='" . $fechaActual . "' OR FechaTermina='0000-00-00') 
            GROUP BY a.Id    
            ORDER BY `a`.`FechaInicio` DESC,a.PrecioVenta DESC; ";
            $rs_cltesAc = $db->ejecutar($sqlAc);
            if ($rs_cltesAc) {
                while ($col_cltesAc = $db->obtener_fila($rs_cltesAc, 0)) {
                    $json = array(
                        'Id' => $col_cltesAc['Id'],
                        'IdAcuerdoComercial' => $col_cltesAc['IdAcuerdoComercial'],
                        'TipoAcuerdo' => $col_cltesAc['TipoAcuerdo'],
                        'TipoCuentaCliente' => $col_cltesAc['TipoCuentaCliente'],
                        'CuentaCliente' => $col_cltesAc['CuentaCliente'],
                        'CodigoGrupoPrecio' => $col_cltesAc['CodigoGrupoPrecio'],
                        'CodigoVariante' => $col_cltesAc['CodigoVariante'],
                        'PrecioVenta' => $col_cltesAc['PrecioVenta'],
                        'CodigoUnidadMedida' => $col_cltesAc['CodigoUnidadMedida'],
                        'NombreUnidadMedida' => $col_cltesAc['NombreUnidadMedida'],
                        'CantidadDesde' => $col_cltesAc['CantidadDesde'],
                        'CantidadHasta' => $col_cltesAc['CantidadHasta'],
                        'FechaInicio' => $col_cltesAc['FechaInicio'],
                        'FechaTermina' => $col_cltesAc['FechaTermina'],
                        'Sitio' => $col_cltesAc['Sitio'],
                        'Almacen' => $col_cltesAc['Almacen']
                    );
                    array_push($datosAcuerdo, $json);
                }
            }


            //Acuerdo Comercial descuento linea
            $sqlAlinea = "SELECT a.* FROM `acuerdoscomercialesdescuentolinea` AS a 
            INNER JOIN clienteruta AS cr ON (cr.CuentaCliente=a.CuentaCliente OR cr.CodigoGrupoDescuentoLinea = a.CodigoClienteGrupoDescuentoLinea) 
            INNER JOIN frecuenciavisita AS fre ON fre.NumeroVisita=cr.NumeroVisita 
            WHERE cr.CodZonaVentas='" . $zonaVentas . "' AND cr.CuentaCliente='" . $cuentaCliente . "' AND FechaInicio<='" . $fechaActual . "' AND (FechaFinal>='" . $fechaActual . "' OR FechaFinal='0000-00-00')  GROUP BY a.Id
            ORDER BY `a`.`FechaInicio` DESC,SUM(PorcentajeDescuentoLinea1+PorcentajeDescuentoLinea2) ASC; ";
            $rs_cltesAlinea = $db->ejecutar($sqlAlinea);
            if ($rs_cltesAlinea) {
                while ($col_cltesAlinea = $db->obtener_fila($rs_cltesAlinea, 0)) {

                    $json = array(
                        'Id' => $col_cltesAlinea['Id'],
                        'IdAcuerdoComercial' => $col_cltesAlinea['IdAcuerdoComercial'],
                        'TipoAcuerdo' => $col_cltesAlinea['TipoAcuerdo'],
                        'TipoCuentaCliente' => $col_cltesAlinea['TipoCuentaCliente'],
                        'CuentaCliente' => $col_cltesAlinea['CuentaCliente'],
                        'CodigoClienteGrupoDescuentoLinea' => $col_cltesAlinea['CodigoClienteGrupoDescuentoLinea'],
                        'TipoCuentaArticulos' => $col_cltesAlinea['TipoCuentaArticulos'],
                        'CodigoVariante' => $col_cltesAlinea['CodigoVariante'],
                        'CodigoArticuloGrupoDescuentoLinea' => $col_cltesAlinea['CodigoArticuloGrupoDescuentoLinea'],
                        'PorcentajeDescuentoLinea1' => $col_cltesAlinea['PorcentajeDescuentoLinea1'],
                        'PorcentajeDescuentoLinea2' => $col_cltesAlinea['PorcentajeDescuentoLinea2'],
                        'CodigoUnidadMedida' => $col_cltesAlinea['CodigoUnidadMedida'],
                        'NombreUnidadMedida' => $col_cltesAlinea['NombreUnidadMedida'],
                        'CantidadDesde' => $col_cltesAlinea['CantidadDesde'],
                        'CantidadHasta' => $col_cltesAlinea['CantidadHasta'],
                        'FechaInicio' => $col_cltesAlinea['FechaInicio'],
                        'FechaFinal' => $col_cltesAlinea['FechaFinal'],
                        'LimiteVentas' => $col_cltesAlinea['LimiteVentas'],
                        'Saldo' => $col_cltesAlinea['Saldo'],
                        'Sitio' => $col_cltesAlinea['Sitio'],
                        'CodigoAlmacen' => $col_cltesAlinea['CodigoAlmacen'],
                        'PorcentajeAlerta' => $col_cltesAlinea['PorcentajeAlerta'],
                    );
                    array_push($datosAcuerdoLinea, $json);
                }
            }

            //Acuerdo Comercial descuento Multi linea
            $sqlMulinea = "SELECT a.* FROM `acuerdoscomercialesdescuentomultilinea` AS a 
            INNER JOIN clienteruta AS cr ON (cr.CuentaCliente=a.CuentaCliente OR cr.CodigoGrupoDescuentoMultiLinea = a.CodigoGrupoClienteDescuentoMultilinea) 
            INNER JOIN frecuenciavisita AS fre ON fre.NumeroVisita=cr.NumeroVisita 
            WHERE cr.CodZonaVentas='" . $zonaVentas . "' AND cr.CuentaCliente='" . $cuentaCliente . "' AND FechaInicio<='" . $fechaActual . "'  AND (FechaFinal>='" . $fechaActual . "' OR FechaFinal='0000-00-00')
                GROUP BY a.Id
            ORDER BY `a`.`FechaInicio` DESC,SUM(PorcentajeDescuentoMultilinea1+PorcentajeDescuentoMultilinea2) ASC;";
            $rs_cltesMulinea = $db->ejecutar($sqlMulinea);
            if ($rs_cltesMulinea) {
                while ($col_cltesMulinea = $db->obtener_fila($rs_cltesMulinea, 0)) {

                    $json = array(
                        'Id' => $col_cltesMulinea['Id'],
                        'IdAcuerdoComercial' => $col_cltesMulinea['IdAcuerdoComercial'],
                        'TipoAcuerdo' => $col_cltesMulinea['TipoAcuerdo'],
                        'TipoCuentaCliente' => $col_cltesMulinea['TipoCuentaCliente'],
                        'CuentaCliente' => $col_cltesMulinea['CuentaCliente'],
                        'CodigoGrupoClienteDescuentoMultilinea' => $col_cltesMulinea['CodigoGrupoClienteDescuentoMultilinea'],
                        'CodigoGrupoArticulosDescuentoMultilinea' => $col_cltesMulinea['CodigoGrupoArticulosDescuentoMultilinea'],
                        'PorcentajeDescuentoMultilinea1' => $col_cltesMulinea['PorcentajeDescuentoMultilinea1'],
                        'PorcentajeDescuentoMultilinea2' => $col_cltesMulinea['PorcentajeDescuentoMultilinea2'],
                        'CodigoUnidadMedida' => $col_cltesMulinea['CodigoUnidadMedida'],
                        'NombreUnidadMedida' => $col_cltesMulinea['NombreUnidadMedida'],
                        'CantidadDesde' => $col_cltesMulinea['CantidadDesde'],
                        'CantidadHasta' => $col_cltesMulinea['CantidadHasta'],
                        'FechaInicio' => $col_cltesMulinea['FechaInicio'],
                        'FechaFinal' => $col_cltesMulinea['FechaFinal'],
                        'Sitio' => $col_cltesMulinea['Sitio'],
                        'Almacen' => $col_cltesMulinea['Almacen']
                    );
                    array_push($datosAcuerdoMultiLinea, $json);
                }
            }

            $subArray = array('FacturaSaldo' => $datosFactura,
                'FacturaSaldoDetalle' => $datosFacturaDetalle,
                'RestrinccionProveedor' => $restrinccion,
                'AcuerdoComercial' => $datosAcuerdo,
                'AcuerdoLinea' => $datosAcuerdoLinea,
                'AcuerdoMultiLinea' => $datosAcuerdoMultiLinea);

            return json_encode($subArray);
        } catch (Exception $e) {
            $manejador = fopen('Log/Warning.txt', 'a+');
            fputs($manejador, $e->getMessage() . "\n");
            fclose($manejador);
        }
    }
}

/* * *************************************************************************************************************** */

//Funciones para validaciones de datos.
/**
 * 
 * @param type $date1
 * @param type $date2
 * @return type
 */
function diff_dte($date1, $date2) {
    if (!is_integer($date1))
        $date1 = strtotime($date1);
    if (!is_integer($date2))
        $date2 = strtotime($date2);
    return floor(abs($date1 - $date2) / 60 / 60 / 24);
}

/**
 * Validamos que el dato sea vacio
 * @param type $dato
 * @return type
 */
function vacio($dato) {
    $dato2 = "";
    if (empty($dato)) {
        $dato2 = "0";
    } else {
        $dato2 = trim($dato);
    }
    return $dato2;
}

/**
 * Esta funcion me permite identificar si el cliente esta vencido.
 * @param type $cliente
 * @param type $zonaVenta
 * @param type $numeroFactura
 * @return string
 */
function estadoVencidoCliente($cliente, $zonaVenta, $numeroFactura) {
    //Conexion a la base de datos.
    $db = Db::getInstance();

    $estado = "false";
    $hoy_actual = date("Y-m-d");

    $sqlwes = "SELECT `DiasGracia`,`DiasAdicionales` FROM `clienteruta` WHERE `CuentaCliente`='" . $cliente . "' ;";
    $st = $db->ejecutar($sqlwes);
    $result = $db->obtener_fila($st, 0);
    $diasGracia = $result['DiasGracia'];
    $diasAdicionales = $result['DiasAdicionales'];

    $diasSuma = $diasGracia + $diasAdicionales;

    $sqltrp = "SELECT `FechaVencimientoFactura` FROM `facturasaldo` WHERE `CuentaCliente`='" . $cliente . "' AND `NumeroFactura`='" . $numeroFactura . "' AND SaldoFactura > 0; ";
    $rs_fac = $db->ejecutar($sqltrp);
    while ($rs_fac1 = $db->obtener_fila($rs_fac, 0)) {

        $Fecha_Factura = $rs_fac1[0];

        $fec_vencimientopp = date("Y-m-d", strtotime("$Fecha_Factura + $diasSuma days"));

        if ($hoy_actual > $fec_vencimientopp) {
            $estado = "true";
            break;
        }
    }
    return $estado;
}

$HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '';

$server->service($HTTP_RAW_POST_DATA);
?>